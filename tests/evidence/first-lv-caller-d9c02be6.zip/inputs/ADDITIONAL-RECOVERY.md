# Additional bounded recovery

All four requested bodies were recovered from the same exact run18 job and matched the supplied hashes before final files were created. No additional source search was performed.

- frozen-serial-import.json: 413 bytes; ab5d5bca1d75c405dc1c00ff159151f849a0c26ae01b3c5f30c0627f9e709e83
- frozen-window.png.smoke.json: 896 bytes; 1bf26ae640e0c902b7d10c61544ec72ce9f0121edfb8d1fbe0643b960793fd0c
- native-notice-source.bin: 33,861 bytes; 62bec384df47b0328307db41455ff6ea2559e5546b394ac69148561b21703120
- native-notice-copy.bin: 33,861 bytes; 62bec384df47b0328307db41455ff6ea2559e5546b394ac69148561b21703120

Serial and GUI were reconstructed directly from their original timestamp-stripped Get-Content sections, with LF and final LF. They were not serialized from embedded manifest values. Their original checksum hashes, archive lengths and manifest values were checked.

Both notices were strict BASE64 decodes of unique original byte-retention blocks. They are byte-identical and match the retained native reference's respective source/copy lengths and hashes. They are not invented notice content and are not claimed as downloaded artifact files.

Actual COLLECT-00.toc bytes and length remain missing. Its expected hash alone does not establish original bytes or prove admission under the proposed 256 KiB cap. No actual Windows/origin execution or previous whole-package validator execution is proved by these data-only checks.

Source: https://github.com/font-weight/stm32_motortester/actions/runs/38572185383/job/115879974929

## Exact source log markers

2026-10-14T13:38:48.6163651Z BEGIN native-notice-source.bin BASE64
2026-10-14T13:38:48.9128696Z END native-notice-source.bin BASE64
2026-10-14T13:38:48.9130009Z BEGIN native-notice-copy.bin BASE64
2026-10-14T13:38:49.2048380Z END native-notice-copy.bin BASE64
2026-10-14T13:38:49.8634928Z --- frozen-serial-import.json ---
2026-10-14T13:38:49.8649387Z --- frozen-window.png.smoke.json ---
