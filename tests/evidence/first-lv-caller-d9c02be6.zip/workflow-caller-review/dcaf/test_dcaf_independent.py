"""Critic-A independent assertions over exact frozen caller, inert only.

The base on-disk fixture factory is reused from the hash-guarded author test module
and is deliberately disclosed as correlated setup. All test logic below is new.
It patches only the in-memory CPython fixture digest, never production source.
No real ZIP application, native program, network, Windows or publication occurs.
"""
from pathlib import Path, PureWindowsPath
import ast, copy, hashlib, json, ntpath, os, re, subprocess, sys, types, unittest, zipfile
from unittest import mock
import yaml
HERE=Path(__file__).absolute().parent
SUBJECT=HERE/'subject'
PINS={
 'stage_plan.py':(39812,'53f4a869c7b4991f5a238e848da552d7dc0d6611ea8d6a9a56a2a085cf2432dd'),
 'test_stage_plan.py':(32833,'0044ec29986eef3322cd3e52071d1e0a4c2ccaf2f9bd4146d412b529c1c3dc2e'),
 'host-windows.local-draft.yml':(77417,'3863f0afe4f53762579eea8bbeb6c45e20189b4e54284003033faff9a460d3f8'),
 'build_workflow_draft.py':(28320,'0338675c4aa72b6fd8758b960bcdf987334e8cfb29516f6fee86ced4695ecf63'),
 'support-manifest.json':(1795,'d3d9943abd61debbe92898af1a876245513505e37b1d52c88dcef6f28305c934')}
for name,(size,digest) in PINS.items():
 raw=(SUBJECT/name).read_bytes()
 if len(raw)!=size or hashlib.sha256(raw).hexdigest()!=digest:
  raise SystemExit('Frozen review input drift: '+name)
f=types.ModuleType('fixture_factory'); f.__file__=str(SUBJECT/'test_stage_plan.py')
exec(compile((SUBJECT/'test_stage_plan.py').read_bytes(),f.__file__,'exec'),f.__dict__)
s=f.s
DOC=yaml.load((SUBJECT/'host-windows.local-draft.yml').read_text(),Loader=yaml.BaseLoader)
JOB=DOC['jobs']['verify']; STEPS={x['id']:x for x in JOB['steps'] if 'id' in x}

class Review(unittest.TestCase):
 setUp=f.CallerTests.setUp
 put=f.CallerTests.put
 save_context=f.CallerTests.save_context
 save_support=f.CallerTests.save_support
 save_reports=f.CallerTests.save_reports
 args=f.CallerTests.args
 call=f.CallerTests.call
 update_inventory=f.CallerTests.update_inventory
 def fail_call(self,code=None):
  self._serial=getattr(self,'_serial',0)+1
  out=self.root/('independent-failure-'+str(self._serial))
  with self.assertRaises(Exception) as caught:
   self.call(output_root=str(out))
  if code: self.assertIn(code,str(caught.exception))
  self.assertFalse((out/'caller-terminal.json').exists())
 def payload_faults(self,values,code=None):
  original=copy.deepcopy(self.checker)
  for name,change in values:
   with self.subTest(case=name):
    self.checker=copy.deepcopy(original); change(self.checker)
    self.put(self.root/'reduced-payload-123-1.json',s.encoded(self.checker))
    self.fail_call(code)
  self.checker=original; self.save_reports()
 def test_01_exact_buckets_and_original_receipts(self):
  inputs={'archive-verification.json':self.build/'archive-verification.json',
    'provenance.json':self.root/'provenance-123-1.json',
    'reduced-payload.json':self.root/'reduced-payload-123-1.json',
    'cpython-notice.json':self.root/'cpython-notice-123-1.json',
    'license-inventory.json':self.build/'dist/Motortester/licenses/inventory.json'}
  originals={name:path.read_bytes() for name,path in inputs.items()}
  r=self.call(); plan=json.loads((self.work/'expected-manifest.json').read_bytes())
  self.assertEqual({x['path'] for x in plan['build_files']},set(self.payload))
  self.assertEqual(len(plan['build_files']),11)
  with zipfile.ZipFile(self.work/'kit.zip') as z:
   for name,raw in originals.items(): self.assertEqual(z.read('evidence/'+name),raw)
   self.assertEqual(z.read('build/build.log'),self.payload['build.log'])
   self.assertEqual({n.split('/')[0] for n in z.namelist()},{'build','evidence','OUTER_MANIFEST.json','EXPECTED_MANIFEST.json'})
   observed=json.loads(z.read('evidence/runtime-selection.json'))
   self.assertEqual(observed['actual_removed_count'],0)
   self.assertFalse(observed['final_absence_used_to_infer_removal'])
  self.assertEqual(r['zip'],f.info((self.work/'kit.zip').read_bytes()))
  self.assertEqual(r['outer_manifest'],f.info((self.work/'kit/OUTER_MANIFEST.json').read_bytes()))
  self.assertTrue(all(r[k] is False for k in ['windows_10_verified','physical_verified','public_binary_publication_authorized']))
 def test_02_all_thirteen_gates_all_non_success(self):
  self.assertEqual(len(s.REQUIRED_STEPS),13)
  for name in s.REQUIRED_STEPS:
   for bad in ['failure','cancelled','skipped','',None,True,1]:
    run=copy.deepcopy(self.context);run['steps'][name]=bad
    with self.subTest(step=name,value=bad),self.assertRaises(Exception):
     s.context(self.h,s.encoded(run),'accepted',self.review)
 def test_03_context_exact_keys_and_all_pins(self):
  for name in self.context:
   run=copy.deepcopy(self.context);del run[name]
   with self.subTest(missing=name),self.assertRaises(Exception):
    s.context(self.h,s.encoded(run),'accepted',self.review)
  for name in ['repository','application_commit','application_tree','inspector_commit','inspector_sha256','payload_checker_sha256']:
   run=copy.deepcopy(self.context);run[name]='wrong'
   with self.subTest(pin=name),self.assertRaises(Exception):s.context(self.h,s.encoded(run),'accepted',self.review)
 def test_04_checker_identity_fields(self):
  fields={'schema_version':True,'status':'passed','scope':'native-verified','application_commit':'244b0786'+('0'*32),
   'application_tree':'0'*40,'actual_checker':{'bytes':24424,'sha256':'0'*64},'actual_source_inputs':{}}
  self.payload_faults([(k,lambda p,k=k,v=v:p.__setitem__(k,v)) for k,v in fields.items()],'payload-identity')
 def test_05_checker_all_qualification_flags(self):
  flags=['native_code_executed','candidate_python_executed','payload_modified','authenticated_origins','tls_capability_verified',
   'hardware_verified','physical_stop_verified','windows_10_verified','legal_clearance','bytes_delivered']
  self.payload_faults([(k,lambda p,k=k:p.__setitem__(k,True)) for k in flags]+[(k+' missing',lambda p,k=k:p.pop(k)) for k in flags], 'payload-qualifications')
 def test_06_original_validator_required_flags(self):
  self.payload_faults([(k+str(v),lambda p,k=k,v=v:p.__setitem__(k,v)) for k in ['archive_validator_required','archive_validator_pass_report_bound'] for v in [False,1,None]],'payload-qualifications')
 def test_07_policy_count_types(self):
  cases=[]
  for view in ['onedir_policy','zip_policy']:
   for key in ['excluded_absent_count','required_present_count']:
    for value in [True,0,46,7.0,None]:
     cases.append((view+key+str(value),lambda p,v=view,k=key,x=value:p[v].__setitem__(k,x)))
  self.payload_faults(cases,'payload-policy')
 def test_08_policy_exact_exclusions(self):
  def reorder(p): p['onedir_policy']['excluded_absent'].reverse()
  def duplicate(p):p['onedir_policy']['excluded_absent'][-1]=p['onedir_policy']['excluded_absent'][0]
  def rename(p):p['onedir_policy']['excluded_absent'][0]='unreviewed.dll'
  self.payload_faults([('reorder',reorder),('duplicate',duplicate),('rename',rename)],'payload-exclusion-list')
 def test_09_keeper_identity_and_empty_bounds(self):
  cases=[]
  for key,value in [('bytes',0),('bytes',True),('bytes',-1),('bytes',256*s.MIB+1),('sha256','A'*64),('sha256','0'*63)]:
   def change(p,k=key,v=value):p['onedir_policy']['required_present'][0][k]=v
   cases.append((key+str(value),change))
  self.payload_faults(cases)
 def test_10_payload_current_bytes_all_joins(self):
  fields=['actual_source_zip','actual_candidate_zip','actual_build_manifest','actual_checksums','actual_archive_verification_report']
  self.payload_faults([(k,lambda p,k=k:p[k].__setitem__('sha256','0'*64)) for k in fields])
 def test_11_original_eight_artifact_set(self):
  self.payload_faults([('missing',lambda p:p['actual_artifacts'].pop(next(iter(p['actual_artifacts'])))),
   ('extra',lambda p:p['actual_artifacts'].__setitem__('unapproved.txt',f.info(b'x'))),
   ('size',lambda p:p['actual_artifacts'][next(iter(p['actual_artifacts']))].__setitem__('bytes',9999))],'payload-archive-join')
 def test_12_archive_source_count_integer_and_pins(self):
  original=copy.deepcopy(self.archive)
  for key,value in [('source_files',305),('source_files',306.0),('recording_source_zip_hashes_verified',22),('recording_required',1),('status','FAIL'),('source_sha','0'*40)]:
   with self.subTest(key=key,value=value):
    self.archive=copy.deepcopy(original);self.archive[key]=value;self.save_reports();self.fail_call('original-archive-incomplete')
 def test_13_original_recording_summary_exact_join(self):
  self.provenance['recording_smoke']={'different':'summary'};self.save_reports();self.fail_call('original-recording-inspector-join')
 def test_14_notice_context_each_identity(self):
  original=copy.deepcopy(self.native)
  for key in original['context']:
   with self.subTest(key=key):
    self.native=copy.deepcopy(original);self.native['context'][key]='wrong';self.save_reports();self.fail_call('notice-context')
 def test_15_notice_sidecar_byte_and_integer_claims(self):
  original=copy.deepcopy(self.native)
  for side in ['source','copy']:
   for key,value in [('bytes',1.0),('sha256','0'*64),('status','synthesized')]:
    with self.subTest(side=side,key=key):
     self.native=copy.deepcopy(original);self.native['cpython_notice'][side][key]=value;self.save_reports();self.fail_call('notice-byte-join')
 def test_16_toc_independent_original_hash_binding(self):
  p=self.build/'pyinstaller/motortester/COLLECT-00.toc';p.write_bytes(b'[] # DIFFERENT ORIGINAL TOC\n')
  self.fail_call('collect-toc-join')
 def test_17_cpython_wrapper_cannot_run_on_linux(self):
  with self.assertRaisesRegex(Exception,'notice-runtime'):s.capture_cpython_notices(build_root=str(self.build),reports_root=str(self.root),run_id='123',attempt='1',workflow_sha='a'*40,helper_root=str(self.helpers))
 def test_18_selector_all_48_possible_removal_counts(self):
  names=list(f.POLICY['EXCLUDED_DESTINATIONS'])
  for n in range(48):
   body=('before\nWindows 10 1809+ x64 runtime selection: '+str(n)+' of 47 approved destinations removed\n'+''.join('  omitted: '+name+'\n' for name in names[:n])+'after\n').encode()
   with self.subTest(n=n):
    r=s.selection_observation(self.h,body,names);self.assertEqual(r['actual_removed'],names[:n]);self.assertEqual(r['actual_removed_count'],n);self.assertEqual(r['build_log'],f.info(body))
 def test_19_selector_invalid_ambiguous_or_noncontiguous(self):
  names=list(f.POLICY['EXCLUDED_DESTINATIONS']);head=b'Windows 10 1809+ x64 runtime selection: '
  cases=[b'',head+b'48 of 47 approved destinations removed\n',head+b'1 of 47 approved destinations removed\n',head+b'0 of 47 approved destinations removed\n'+head+b'0 of 47 approved destinations removed\n',
    head+b'2 of 47 approved destinations removed\n'+('  omitted: '+names[0]+'\n') .encode()*2,
    head+b'1 of 47 approved destinations removed\ninterrupted\n'+('  omitted: '+names[0]+'\n').encode(),
    head+b'1 of 47 approved destinations removed\n  omitted: unapproved.dll\n',
    head+b'1 of 47 approved destinations removed\n  omitted: \xff\n',b'x'*(16*s.MIB+1)]
  for i,raw in enumerate(cases):
   with self.subTest(case=i),self.assertRaises(Exception):s.selection_observation(self.h,raw,names)
 def test_20_nonzero_actual_subset_retained_unchanged(self):
  names=list(f.POLICY['EXCLUDED_DESTINATIONS'])[::10]
  raw=('Windows 10 1809+ x64 runtime selection: '+str(len(names))+' of 47 approved destinations removed\n'+''.join('  omitted: '+name+'\n' for name in names)).encode()
  self.put(self.build/'build.log',raw);self.call()
  r=json.loads((self.work/'kit/evidence/runtime-selection.json').read_bytes())
  self.assertEqual(r['actual_removed'],names);self.assertEqual(r['build_log'],f.info(raw))
 def test_21_diagnostics_complete_absence_is_incomplete(self):
  self.context['steps']['build_candidate']='failure';self.save_context()
  result=self.call(mode='diagnostics',build_root=str(self.root/'missing-build'),reports_root=str(self.support))
  self.assertEqual(result['status'],'INCOMPLETE_DIAGNOSTICS_ONLY')
  p=json.loads((self.work/'expected-manifest.json').read_bytes());self.assertEqual(p['build_files'],[])
  d=json.loads((self.work/'kit/evidence/diagnostic-outcome.json').read_bytes())
  self.assertTrue(all(x['status']=='unavailable' for x in d['attempted_explicit_files']))
  self.assertFalse(d['source_notice_acceptance_established'])
 def test_22_diagnostics_unlisted_binary_never_retained(self):
  for name in s.DIAGNOSTIC_BUILD:self.put(self.build/name,b'\xff\x00INERT BINARY')
  for name in ['provenance-123-1.json','reduced-payload-123-1.json','cpython-notice-123-1.json']:self.put(self.root/name,b'{}\x00')
  self.context['steps']['build_candidate']='failure';self.save_context();self.call(mode='diagnostics')
  with zipfile.ZipFile(self.work/'kit.zip') as z:
   self.assertEqual(set(z.namelist()),{'OUTER_MANIFEST.json','EXPECTED_MANIFEST.json','evidence/workflow-run.json','evidence/diagnostic-outcome.json'})
 def test_23_late_toc_mutation_blocks_terminal(self):
  invoke=s.invoke
  def changed(*args,**kwargs):
   result=invoke(*args,**kwargs)
   if args[3]=='zip_kit.py':(self.build/'pyinstaller/motortester/COLLECT-00.toc').write_bytes(b'late mutation')
   return result
  with mock.patch.object(s,'invoke',changed):self.fail_call('caller-source-changed')
 def test_24_late_packaged_notice_mutation_blocks_terminal(self):
  invoke=s.invoke;p=self.build/'dist/Motortester/licenses/dependency-6.12.0'/next(k for k in self.dependency_files if k.startswith('notices/'))
  def changed(*args,**kwargs):
   result=invoke(*args,**kwargs)
   if args[3]=='zip_kit.py':p.write_bytes(b'late mutation')
   return result
  with mock.patch.object(s,'invoke',changed):self.fail_call('caller-source-changed')
 def test_25_parent_root_overlap_rejected(self):
  with self.assertRaises(Exception):self.call(output_root=str(self.build/'out'))
  with self.assertRaises(Exception):self.call(output_root=str(self.helpers/'out'))
 def test_26_windows_canonical_argument_matrix(self):
  for temp in [r'D:\a\_temp',r'C:\runner space\_temp']:
   for mode in ['accepted','diagnostics']:
    run=STEPS['stage_'+mode]['run']
    for name in ['callerScript','helperRoot','buildRoot','reportsRoot','supportRoot','outputRoot','workflowRun']:
     self.assertRegex(run,r'\$'+name+r' = \[IO.Path\]::GetFullPath\(')
    root=ntpath.abspath(ntpath.join(temp,'first-test-123-1'))
    paths=[root,ntpath.join(root,'helpers'),ntpath.join(temp,'motortester-123-1'),temp,ntpath.join(root,'support'),ntpath.join(root,mode),ntpath.join(root,'workflow-run-'+mode+'.json')]
    with mock.patch.object(self.h,'Path',PureWindowsPath):
     for p in paths:self.assertEqual(str(self.h.absolute(p)),p)
 def test_27_disabled_exact_outcome_wiring(self):
  self.assertTrue(JOB['if'].startswith('false &&'))
  self.assertEqual(DOC['permissions'],{'contents':'read'})
  self.assertEqual({key for key in s.REQUIRED_STEPS}-set(STEPS),set())
  accepted=STEPS['stage_accepted']['run']
  for name in s.REQUIRED_STEPS:self.assertIn("'"+name+"'",accepted)
  self.assertTrue(any('toJSON(steps)' in value for value in STEPS['stage_accepted']['env'].values()))
  self.assertFalse(any('upload-artifact@' in step.get('uses','') for step in JOB['steps']))
 def test_28_production_support_inventory_exact_cardinality(self):
  rows=json.loads((SUBJECT/'support-manifest.json').read_bytes())
  self.assertEqual(len(rows),11);self.assertEqual(sum(x['bytes'] for x in rows),81748837)
  self.assertEqual(sum(x['path'].startswith('sources/') for x in rows),5)
  self.assertEqual(JOB['env']['SUPPORT_MANIFEST_SHA256'],PINS['support-manifest.json'][1])
  self.assertEqual(JOB['env']['SUPPORT_SOURCE_SHA'],s.APP_COMMIT)
  self.assertEqual(JOB['env']['SOURCE_NOTICE_REVIEW'],'https://github.com/font-weight/stm32_motortester/issues/33#issuecomment-6233217133')
 def test_29_bound_launcher_has_no_pyc_lookup(self):
  self.assertIn("exec(compile(raw",s.LAUNCHER);self.assertNotIn('importlib',s.LAUNCHER)
  self.assertIn('dont_inherit=True',s.LAUNCHER)
  self.assertEqual(s.HELPERS['retain.py'],(20066,'3ab02204cf20771c1ff67ca0ec05c8d8c6cb639a93ed56a653ba487fc856b08c'))
  self.assertEqual(s.PAYLOAD_CHECKER,(24424,'b6264f445d9c7abf3170e3072d25632f3bb6e9b3980c0af5bfa8e206bf0dd8e7'))
 def test_30_production_notice_digest_unchanged(self):
  tree=ast.parse((SUBJECT/'stage_plan.py').read_bytes())
  value=next(ast.literal_eval(x.value) for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NOTICE_HASH' for t in x.targets))
  self.assertEqual(value,'62bec384df47b0328307db41455ff6ea2559e5546b394ac69148561b21703120')
  self.assertNotEqual(value,f.info(self.notice)['sha256'])

 def prepare_historical_notice(self):
  source=(HERE/'historical-notice/native-notice-source.bin').read_bytes()
  copied=(HERE/'historical-notice/native-notice-copy.bin').read_bytes()
  expected={'bytes':33861,'sha256':'62bec384df47b0328307db41455ff6ea2559e5546b394ac69148561b21703120'}
  self.assertEqual(f.info(source),expected);self.assertEqual(copied,source)
  self.put(self.build/'dist/Motortester/licenses/CPython-LICENSE.txt',source)
  for side,raw in [('source',source),('copy',copied)]:
   self.put(self.root/('native-notice-'+side+'-123-1.bin'),raw)
   self.native['cpython_notice'][side]={'status':'retained_original',**expected}
  manifest=json.loads(self.payload[self.h.BUILD_MANIFEST]);manifest['files']['licenses/CPython-LICENSE.txt']=expected['sha256']
  raw=s.encoded(manifest);self.payload[self.h.BUILD_MANIFEST]=raw;self.put(self.build/self.h.BUILD_MANIFEST,raw)
  for receipt in [self.archive,self.provenance]:receipt['build_manifest_sha256']=f.info(raw)['sha256']
  self.native['input_hashes']['manifest']=f.info(raw)['sha256'];self.save_reports()
 def real_cli(self):
  command=[sys.executable,'-I','-S','-B']+(['-O'] if sys.flags.optimize else [])+[str(SUBJECT/'stage_plan.py')]
  command += [part for key,value in self.args().items() for part in ('--'+key.replace('_','-'),value)]
  return subprocess.run(command,capture_output=True,timeout=30)
 def test_31_unmodified_real_cli_accepts_historical_notice_fixture(self):
  self.prepare_historical_notice();r=self.real_cli()
  self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(r.stderr,b'')
  result=json.loads(r.stdout);self.assertEqual(result['status'],'LOCAL_KIT_BYTES_VERIFIED_ONLY')
  self.assertFalse(result['windows_10_verified']);self.assertFalse(result['physical_verified'])
  with zipfile.ZipFile(self.work/'kit.zip') as z:
   for side in ['source','copy']:
    self.assertEqual(z.read('evidence/native-notice-'+side+'.bin'),(HERE/'historical-notice'/('native-notice-'+side+'.bin')).read_bytes())
  summary={'scope':'inert synthetic candidate and receipts; genuine recovered historical notice bytes only',
   'production_source_modified':False,'production_notice_hash_override':False,'native_application_executed':False,
   'actual_windows_executed':False,'returncode':r.returncode,'caller_terminal':result}
  (HERE/('historical-notice-cli-'+('optimized' if sys.flags.optimize else 'normal')+'.json')).write_bytes(s.encoded(summary))
 def test_32_unmodified_real_cli_rejects_changed_historical_notice(self):
  self.prepare_historical_notice();p=self.root/'native-notice-copy-123-1.bin';raw=p.read_bytes();p.write_bytes(bytes([raw[0]^1])+raw[1:])
  r=self.real_cli();self.assertEqual(r.returncode,1);self.assertEqual(json.loads(r.stderr)['status'],'CALLER_REJECTED')
  self.assertFalse((self.work/'caller-terminal.json').exists())

if __name__=='__main__':unittest.main(verbosity=2)
