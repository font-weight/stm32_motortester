# Critic-A: dcaf evaluated-workflow caller, exact disabled composition

## Verdict and scope

**PASS, 9.60/10 for the frozen local source/inert composition. No open P0/P1.** One P2 hardening advisory is recorded below: retained collector attribution/review metadata is not independently semantically validated. This conclusion is independently earned for this caller; prior helper 9.73/checker 10/baseline caller 9.5 scores were not inherited.

The reviewed result is the smallest disabled evaluated-workflow integration: immutable dcaf application source, unchanged original build/archive/provenance/smoke validators, the separately reviewed v2 payload checker, bounded exact support materialization, retained original CPython notices, actual selector-removal observation, explicit notice body/inventory correspondence, and exact local retention/ZIP packaging. The caller was not enabled, run on Windows, dispatched, uploaded, or used to launch an application/device. No `host/**` implementation files were changed by this review.

Owner public-binary permission is already present per root. This review does not reevaluate that permission. Third-party distribution disposition, actual Windows execution, live input acquisition, real final candidate receipts and any delivery remain separate unresolved gates. The helper's `public_binary_publication_authorized:false` describes its lack of authority to grant permission, not an assertion that owner permission is missing. A source-level PASS cannot close those gates.

Author is the implementation worker; reviewer is independent Critic-A `/root/review_workflow_retention_caller`, with separate focused input/notice/materializer review. Reviewers authored only tests, input snapshots and reports under `workflow-caller-review/`, no production fixes. The quality rubric is immutable appdcaf `docs/quality-gate.md` revision1.0, with all five weights preserved. Actual Windows execution was outside this assigned source/inert scope from the outset, not removed after a failing test.

## Exact identity

Local source: `resume-lv-20261017/workflow-caller-dcaf/`. Final author manifest is 5,992 bytes, SHA-256 `bbfe65fd383b84467fba87ad8d760deff58aed8dccd311d2ef586bfabce76ddd`. All 20 listed files were independently checked against it, copied to this review's `subject/`, and checked again after tests. Generator reproduction was run only in that review copy; the original source tree was not used as a writable test fixture.

| Input | Bytes | SHA-256 |
|---|---:|---|
| stage_plan.py | 39812 | 53f4a869c7b4991f5a238e848da552d7dc0d6611ea8d6a9a56a2a085cf2432dd |
| host-windows.local-draft.yml | 77417 | 3863f0afe4f53762579eea8bbeb6c45e20189b4e54284003033faff9a460d3f8 |
| build_workflow_draft.py | 28320 | 0338675c4aa72b6fd8758b960bcdf987334e8cfb29516f6fee86ced4695ecf63 |
| support-manifest.json | 1795 | d3d9943abd61debbe92898af1a876245513505e37b1d52c88dcef6f28305c934 |
| retain.py | 20066 | 3ab02204cf20771c1ff67ca0ec05c8d8c6cb639a93ed56a653ba487fc856b08c |
| zip_kit.py | 8419 | 1270725f73afe9c947e7ce5835779eee28c7604d429a30f244aff06684fe40b6 |
| check_reduced_payload.py v2 | 24424 | b6264f445d9c7abf3170e3072d25632f3bb6e9b3980c0af5bfa8e206bf0dd8e7 |
| Original workflow | 49772 | 7341772216fa98fc98946e466cf36038a66dfec15977b3118d76e28109a998b6 |

Application head `dcafc5638bc6c3ddef6cba25a7a55016fe8e8933`, tree `61a9bd025081acec80997dff950d947eeceb3f4b`. Retention head `49c271104939a9c6ca6027ec239a904cac11a1a3`, tree `b8b3fb3d4644f00cb7bd3e8d2d149d8cd6c4d549`. Original inspector commit `54d63be3fdd8eba858bafafbf6cec33c4ed989b8`, SHA-256 `fa017e8ab7a348d45c74c86bb877968bac9aef77f963642cc7af396a5f2c8c53`.

The earlier notified generator `7647708…` changed only by adding `import os` and making original workflow input explicit through `CALLER_BASE_WORKFLOW`; its exact baseline digest guard remains. Author test input paths similarly became explicit environment inputs. README clarified existing owner permission. Production caller/YAML/support/both patch bytes did not change. Final hashes, rather than superseded manifest claims, govern this report.

Preserved app244b/r2 review is untouched: `../REPORT_RU.md` SHA-256 `14d53ee98528512b7925a334c3a0818aa1744f8bf2b270a2268bd62873879068`; `../REVIEW_MANIFEST.json` SHA-256 `dfb23bc277e3d1ae3996a6a9c5a60baa7e080ab7fa1c5a46a946133ecfa0dfc1`. That earlier Windows mixed-separator P1-C1 remains fixed through canonical trusted PowerShell argument construction; no retainer path rejection was weakened.

## What was checked

1. **Evaluated-source binding and original validators.** YAML remains literally `false &&`, `contents: read`, without upload. Immutable Git checkout/raw-blob validation pins all 1,501 tracked application files and exact new spec/selector blob IDs. Original archive validator and inspector run bodies stay unchanged; fresh source.zip still binds all 306 host Git bodies and 23 recording-source assertions. Original build recipe still owns all build/smoke outputs. The old fixed-baseline native observer is removed rather than misrepresented as compatible with reduced output. Source spec applies the pure selector before PYZ/EXE/COLLECT. No post-smoke trimming occurs.
2. **Binding of executed helper bytes.** Stage and workflow bootstrap perform bounded size/hash/type/link/stability checks and compile the same bytes. No sourceless PYC/import cache substitutes helper/checker code. Retention is pinned to49c271, checker to exact v2b6264f, caller/support/evaluated workflow are sourced from the actual evaluated workflow commit. Canonical `Join-Path`/`GetFullPath` arguments cover accepted and diagnostics modes, including spaces. PureWindowsPath checks exercise the original strict helper; these are models/static checks, not actual PowerShell execution.
3. **Mandatory outcomes and receipts.** Thirteen named step outcomes must all be success before accepted staging. Context requires exact repository/app/tree/inspector/checker identity and run/attempt/workflow. Original archive receipt is copied from BUILD_DIR, not synthesized. Archive, provenance, recording summary, exact 8 payload checksums and identities, manifest, executable, reduced-payload receipt, CPython receipt and actual COLLECT hash are cross-joined. Original inspector remains the actual COLLECT/PYZ parser; the new caller does not pretend to reimplement that parser. Failed diagnostics exit nonzero even when their local text ZIP is valid.
4. **47/7 and actual removals are separate evidence.** Checker is the required final onedir+ZIP correspondence authority, with exact47 exclusions and seven nonempty keepers. Caller binds checker identity and current source/candidate ZIP, manifest, checksums, eight artifact identities and original archive receipt. It rejects false claimed qualifications. Selector observation uses one exact build-log block and a unique approved subset, accepts true removal counts0 through47, rejects duplicates/orphans/ambiguous blocks, and binds exact build.log bytes. It does not infer an actual removal count from final absence. The pure independent matrix tested all48 possible counts and retained a nonzero subset end-to-end.
5. **Original CPython and notice joins.** Public capture wrapper requires real Windows CPython3.13.16 x64 at the exact toolcache root. Source LICENSE and package copy must be byte-identical with historical digest `62bec384df47b0328307db41455ff6ea2559e5546b394ac69148561b21703120`, joined to manifest/archive/provenance/COLLECT and run metadata. Both sidecars retain original bytes. The exact51 literal dependency bodies/176,605 bytes and manifest+guide form53 actual packaged files. Both distribution inventory records reference the complete53 path/size/hash set; original collector inventory is hash-joined and retained. Package guidance, MIT-containing project-license, dependency guide and LICENSE-REVIEW are joined to exact support copies. Candidate ZIP correspondence composes through original validator/checker; full source ZIP correspondence through raw Git bodies.
6. **Finite exact support.** B's issue33 comment6233217133 defines five archives and five guides; the integration adds exact dcaf windows-smoke instructions. Eleven files total81,748,837 bytes; five archives total81,483,468 bytes, largest51,220,268, inside64MiB/file,128MiB aggregate,16-row caller limits. Original official URLs plus exact predeclared mirror URLs are the only redirect destinations; count/repeat/final URL/HTTP200/identity encoding/optional length/actual size/hash/readback are checked. No archive extraction or execution. Chunk reads at most1MiB, socket timeout15s, checked deadline240s, workflow step cap5min. A checked deadline cannot interrupt an already blocked read; enclosing step timeout is the hard total bound. No live network behavior was tested.
7. **Retention boundary.** Exact11 build entries and bounded independent evidence rows remain separate, with no wildcard sweep. Unknown files are ignored, not silently added. Failed branch keeps only explicit bounded valid UTF-8/JSON diagnostic text; no EXE/ZIP/PNG/bin/recording/support bodies. Helpers must exit0 with expected terminal status, matching outer manifest and local ZIP size/hash. Late original TOC, notice and receipt mutation prevents caller terminal success. Expected and outer manifests are intentionally additional ZIP root metadata, not extra build entries. Final terminal does not claim Windows, physical, legal or delivery acceptance.

## Independent evidence and reproduction

Environment: Linux, CPython3.12.14, no native application or Windows/Actions execution. All executable work was pinned Python review/retention/checker source with inert data, or exact inline materializer under in-memory HTTP/process/socket guards. No original application/native payload was run.

| Suite | Normal | `-O` | Evidence |
|---|---:|---:|---|
| Author caller |50/50|50/50|author-stage_plan-*.log|
| Author Windows-path models |9/9|9/9|author-windows_paths-*.log|
| Author static YAML/patch/generator |17/17|17/17|author-workflow_static-*.log|
| Author in-memory materializer |12/12|12/12|author-support_materializer-*.log|
| Independently authored caller matrix |32/32|32/32|independent-*.log; test_dcaf_independent.py|
| Independent notice/support/materializer |48 expected/48|48 expected/48|../dcaf-support-research/ logs and JSON results|

The32 added methods contain larger subcase matrices, including all13 gates/non-success outcomes, all payload qualifications, each identity join, exact policy/count/type faults, all48 selector counts, diagnostics-all-missing/all-binary, original-receipt retention, late mutations, canonical Windows path construction and production support pins. The base filesystem fixture factory is explicitly reused from the hash-bound author test module; assertions/fault scenarios are independently authored. This correlated setup is not claimed to be a second independently built end-to-end candidate. The focused notice/support reviewer used independent fixtures and48 outcomes, including11 deliberately accepted metadata mutations illustrating P2 below.

Most positive local fixtures use inert CPython notice bytes and a test-only in-memory NOTICE_HASH override. Production source retains the historical digest. The author suite separately demonstrates real CLI rejection of the inert notice and Windows wrapper rejection on Linux. During review root located the genuine recovered run18 notice source/copy in `literal-gate-design/`: both33,861 bytes with the exact production62bec384… digest. Their recovery document identifies original job115879974929 and unique BASE64 log blocks. This pair and recovery document are preserved here under `historical-notice/`. Two new independent tests run the unmodified production CLI in a fresh isolated process, with no NOTICE_HASH override: the genuine historical pair succeeds and a one-byte altered copy rejects, normal and -O. `historical-notice-cli-*.json` preserve qualified terminal summaries. The surrounding candidate and receipts remain inert/synthetic; this verifies production CLI composition with genuine historical notice bytes, not a fresh Windows runtime capture, actual candidate or original validator execution. The author README claim that the notice was locally unavailable is now a stale historical observation; root plans a separate documentation correction. Frozen author evidence was not rewritten.

`run_review.sh` documents repeat commands with six explicit immutable input environment variables. `subject/` retains exact tested caller/test/generator/YAML/support bytes; its manifest records all source identities. The static generator test writes only the review copy, then asserts all three generated outputs match frozen bytes. Exact production source/copy identities were checked again after replay.

An early reviewer-harness run expected only OUTER_MANIFEST instead of both EXPECTED_MANIFEST and OUTER_MANIFEST and used the wrong environment key spelling. That log is kept as `harness-development-normal.log`, excluded from verdict evidence. Assertions were corrected to the actual documented contract, not production code. Final normal/optimized reruns both pass. The ledger separates this development log from accepted evidence.

Focused report: `../dcaf-support-research/FROZEN_NOTICE_SUPPORT_REVIEW.md`, SHA-256 `ef4d3b0306ac0e2f978d749c44039b052bb743c03bc656953a2b750a1be33bb3`. Earlier input audit independently rehashed all306 host bodies and51 notices; exact input disposition is retained as source data. No old source-support ZIP or duplicated51 evidence rows was substituted.

## Finding P2-DC1: inventory semantic attribution/review fields

Location: `stage_plan.py`256–275 (`notice_coverage`). The code verifies normalized distribution names and exact dependency notice paths/sizes/hashes/copy membership, but not distribution version, `manual_review_required`, per-row `scope`, `reason`, `source_url`, version, reference wheel or reference wheel SHA.

Reproduction: start with complete synthetic53-entry inventory for both distributions, change only `manual_review_required` to false, recompute its synthetic build-manifest identity and invoke the exact frozen notice coverage function. It accepts and emits its explicitly limited byte-correspondence receipt. Missing/wrong version, wheel/source metadata and stripped attribution also accept. Eleven such acceptance cases are preserved in `FROZEN_NOTICE_RESULTS.json`; six malformed membership/body/guidance controls reject.

Severity/scope: **nonblocking P2 advisory**, not a demonstrated full trusted-workflow bypass. B's required contract is actual body membership/hashes and preservation of original inventory. The unchanged immutable collector and lock generate the metadata; the original inventory is retained and joined, and pinned manifest/guide preserve unresolved qualifications. The emitted receipt always says legal/native-source-completeness/replacement false. Author explicitly confirms no original validator independently revalidates every semantic field; this report does not imply otherwise.

If exact semantic provenance/qualification validation becomes a requirement, add explicit known-value joins and negative tests before claiming that expanded scope. Until then describe the caller as byte correspondence plus original inventory retention, never a semantic/legal inventory verifier. No production edit was made by the reviewer.

## Rubric and acceptance limits

| Criterion | Weight | Score | Evidence/rationale |
|---|---:|---:|---|
| C1 correctness/requirements |0.30|9.6|Complete requested disabled composition, exact source/original receipt/notice and47/7 joins; P2 metadata scope stays visible.|
| C2 reliability/failure behavior |0.20|9.7|Bounded inputs, strict type/hash/path checks, explicit outcomes, incomplete diagnostics, subprocess exit and final readback, negative/mutation tests. Frozen-input trust limit and read-versus-step timeout distinction retained.|
| C3 evidence/verification |0.25|9.6|Pinned source review, all applicable inert suites normal/-O, exact generator reproduction and independent focused fixtures. Main added caller tests reuse the author fixture factory; no claim of real Windows/HTTP execution.|
| C4 clarity/maintainability |0.15|9.4|Limited composition preserving original validators, explicit semantic boundary. Large generated workflow and repeated bootstrap/receipt wiring need exact static comparison; metadata coverage is intentionally partial.|
| C5 reproducibility/documentation |0.10|9.7|Final explicit input paths, full manifest/snapshots/logs, preserved previous review, exact support comment and qualifications. Replay needs the separately identified historical/source inputs, not just a bare PR checkout.|

Unrounded weighted result:0.30×9.6+0.20×9.7+0.25×9.6+0.15×9.4+0.10×9.7 = **9.60**. This is reviewer judgment under the rubric, not a test-pass percentage, safety probability or guarantee. All mandatory checks for this declared local source/inert scope were completed; no missing required source/inert evidence is hidden by the score.

Remote PR181 binding is a separate finite read-only addendum. Production bytes matching this exact reviewed set may carry this scoped conclusion after commit/tree/parent/diff verification; new production bytes or materially changed base require re-review. Actual workflow execution/publication/delivery readiness remains blocked on its distinct evidence and disposition gates, regardless of this score.
