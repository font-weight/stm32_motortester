#!/usr/bin/env bash
# Local inert review only. Supply immutable external inputs explicitly.
set -eu
: "${CALLER_BASE_WORKFLOW:?exact original workflow file required}"
: "${CALLER_TEST_HELPERS:?exact 49c271 helper directory required}"
: "${CALLER_TEST_APP_SOURCE:?exact dcaf source checkout required}"
: "${CALLER_TEST_BASELINE:?preserved app244b r2 evidence bundle required}"
: "${CALLER_TEST_OLD_RETAINER:?exact old a26bd helper source required}"
: "${CALLER_TEST_CHECKER:?exact b6264f v2 checker source required}"
export PYTHONDONTWRITEBYTECODE=1
REVIEW="$(cd -- "$(dirname -- "$0")" && pwd)"
for mode in normal optimized; do
  flag=''; if [ "$mode" = optimized ]; then flag=-O; fi
  for suite in stage_plan windows_paths workflow_static support_materializer; do
    python $flag -B "$REVIEW/subject/test_$suite.py" > "$REVIEW/author-$suite-$mode.log" 2>&1
  done
  python $flag -B "$REVIEW/test_dcaf_independent.py" > "$REVIEW/independent-$mode.log" 2>&1
done
