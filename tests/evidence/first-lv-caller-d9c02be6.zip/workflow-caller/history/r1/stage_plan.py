"""Local evaluated-workflow caller. Byte retention only; never upload or run the app.

The reviewed workflow, not this program, establishes source/notice sufficiency
and permission. Support paths come only from its hash-pinned explicit inventory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import types

APP_COMMIT = "244b0786a18fed19a9e708bb815150475ddd193f"
APP_TREE = "0c0e61fb8aadd4a4380e2d7e0b8818e4c9da0d5e"
INSPECTOR_COMMIT = "54d63be3fdd8eba858bafafbf6cec33c4ed989b8"
INSPECTOR_HASH = "fa017e8ab7a348d45c74c86bb877968bac9aef77f963642cc7af396a5f2c8c53"
RETENTION_COMMIT = "a26bd0072fd375038e0e4c9c54005cf37e440b65"
HELPERS = {
    "retain.py": (20063, "9e51a4bc9d8cde8ad52c3f286dfff1f262eeb322d96b10f7f0263fc811c11dd7"),
    "zip_kit.py": (8419, "b4fbc166d5ed6d1cb6525c313ac1f45e384127e9563e27f6399785ede330912e"),
}
REQUIRED_STEPS = (
    "verify_source", "verify_raw_blobs", "bind_inspector", "bind_native_observer",
    "build_candidate", "verify_archives", "inspect_candidate", "observe_native",
    "retain_native_logs", "retain_job_logs", "retain_recording_logs",
)
MIB = 1024 * 1024
# Actual original report names are selected from verified run/attempt, never globs.
DIAGNOSTIC_BUILD = (
    "build.log", "frozen-serial-import.json", "frozen-window.png.smoke.json",
    "frozen-recording.json", "SHA256SUMS.txt", "dist/Motortester/build-manifest.json",
    "archive-verification.json", "dist/Motortester/licenses/inventory.json",
)
MAX_SUPPORT_FILES = 16
MAX_SUPPORT_TOTAL = 128 * MIB

# Hash and execute exactly these source bytes; no importlib/pyc path is involved.
# Used both in this process and in isolated helper child processes.
BOOTSTRAP = r'''
import hashlib, os, stat
from pathlib import Path
def bound_raw(path, size, digest):
    path = Path(path)
    def checked():
        for part in (*reversed(path.parents), path):
            info = part.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                raise ValueError('helper-redirected')
            if part != path and not stat.S_ISDIR(info.st_mode):
                raise ValueError('helper-ancestor')
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size != size:
            raise ValueError('helper-type-size')
        return info
    before = checked()
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read(size + 1)
        after = os.fstat(stream.fileno())
    final = checked()
    shared = lambda x: (x.st_dev, x.st_ino, x.st_size, x.st_mtime_ns, stat.S_IFMT(x.st_mode))
    stable = lambda x: shared(x) + (x.st_ctime_ns, x.st_nlink)
    if (len(raw) != size or hashlib.sha256(raw).hexdigest() != digest
            or shared(before) != shared(opened) or shared(after) != shared(final)
            or stable(before) != stable(final) or stable(opened) != stable(after)
            or opened.st_nlink != 1 or getattr(opened, 'st_file_attributes', 0) & 0x400):
        raise ValueError('helper-body-identity')
    return raw
'''
exec(compile(BOOTSTRAP, "<bound-bootstrap>", "exec", dont_inherit=True))
LAUNCHER = BOOTSTRAP + r'''
import sys
path, size, digest = sys.argv[1:4]
raw = bound_raw(path, int(size), digest)
sys.argv = [path] + sys.argv[4:]
exec(compile(raw, path, 'exec', dont_inherit=True),
     {'__name__': '__main__', '__file__': path, '__package__': None})
'''


def helpers(root):
    root = Path(root)
    loaded = {}
    for name, (size, digest) in HELPERS.items():
        raw = bound_raw(root / name, size, digest)
        module = types.ModuleType("_bound_" + name[:-3])
        module.__file__ = str(root / name)
        exec(compile(raw, module.__file__, "exec", dont_inherit=True), module.__dict__)
        loaded[name] = module
    h = loaded["retain.py"]
    h.checked(h.absolute(root), "directory")
    h.require(h.APP_COMMIT == APP_COMMIT, "retainer-application-pin")
    return h


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("ascii")


def context(h, raw, mode, review_reference):
    value = h.parse_json(raw)
    h.keys(value, ("schema_version", "repository", "run_id", "attempt", "workflow_sha",
                   "application_commit", "application_tree", "inspector_commit",
                   "inspector_sha256", "source_notice_review", "steps"))
    h.require(type(value["schema_version"]) is int and value["schema_version"] == 1,
              "context-schema")
    h.require(value["repository"] == "font-weight/stm32_motortester"
              and value["application_commit"] == APP_COMMIT and value["application_tree"] == APP_TREE
              and value["inspector_commit"] == INSPECTOR_COMMIT
              and value["inspector_sha256"] == INSPECTOR_HASH, "context-pins")
    for key, pattern in (("run_id", r"[0-9]{1,20}"), ("attempt", r"[0-9]{1,4}"),
                         ("workflow_sha", r"[0-9a-f]{40}")):
        h.require(type(value[key]) is str and re.fullmatch(pattern, value[key]), "context-identity")
    h.keys(value["steps"], REQUIRED_STEPS)
    h.require(all(v in ("success", "failure", "cancelled", "skipped")
                  for v in value["steps"].values()), "context-outcome")
    if mode == "accepted":
        h.require(all(v == "success" for v in value["steps"].values()), "original-checks-incomplete")
        # This is a reference to external review, not an approval inferred from JSON.
        h.require(type(review_reference) is str and 0 < len(review_reference) <= 500
                  and review_reference.startswith("https://github.com/font-weight/stm32_motortester/")
                  and value["source_notice_review"] == review_reference, "external-review-binding")
    return value


def support_inventory(h, raw):
    value = h.parse_json(raw)
    h.require(type(value) is list and 1 <= len(value) <= MAX_SUPPORT_FILES, "support-count")
    seen, total = set(), 0
    for row in value:
        h.keys(row, ("path", "bytes", "sha256"))
        h.relative("support/" + row["path"])
        key = row["path"].casefold()
        h.require(key not in seen and not any(key.startswith(p + "/") or p.startswith(key + "/")
                                             for p in seen), "support-alias")
        seen.add(key)
        h.info_value({"bytes": row["bytes"], "sha256": row["sha256"]}, 64 * MIB)
        total += row["bytes"]
    h.require(total <= MAX_SUPPORT_TOTAL, "support-total")
    return value


def invoke(h, io, helper_root, name, arguments, work):
    size, digest = HELPERS[name]
    bound_raw(helper_root / name, size, digest)
    stdout, stderr = work / (name + ".stdout"), work / (name + ".stderr")
    h.no_alias(work, stdout.name, absent=True)
    h.no_alias(work, stderr.name, absent=True)
    command = [sys.executable, "-I", "-S", "-B", "-c", LAUNCHER,
               str(helper_root / name), str(size), digest, *arguments]
    with stdout.open("xb") as out, stderr.open("xb") as err:
        completed = subprocess.run(command, stdout=out, stderr=err, timeout=180, check=False)
    h.new_file(work / (name + ".exit.json"), io, data=encoded({"exit_code": completed.returncode}))
    h.require(completed.returncode == 0, "helper-terminal-nonzero")
    h.require(h.checked(stderr, "file").st_size == 0, "helper-unexpected-stderr")
    _, raw, _ = io.read(stdout, maximum=h.MAX_PLAN, collect=True)
    result = h.parse_json(raw)
    h.require(type(result) is dict, "helper-terminal-object")
    return result


def stage(*, helper_root, build_root, reports_root, support_root, output_root, workflow_run,
          mode, support_manifest_sha256=None, source_notice_review=None):
    h = helpers(helper_root)
    helper_root, build, reports, support, work, workflow = map(h.absolute,
        (helper_root, build_root, reports_root, support_root, output_root, workflow_run))
    h.disjoint((build, support, work, helper_root))
    h.require(work not in reports.parents and reports != work and work not in workflow.parents,
              "input-inside-output")
    h.checked(work.parent, "directory")
    h.checked(reports, "directory")
    h.no_alias(work.parent, work.name, absent=True)
    h.require(mode in ("accepted", "diagnostics"), "invalid-mode")
    io = h.IO()
    # Covers stage input scans/copies plus final ZIP readback; helpers have separate budgets.
    io.read_limit = 3 * h.MAX_TOTAL + 520 * MIB
    io.write_limit = MAX_SUPPORT_TOTAL + 32 * MIB
    context_info, context_raw, _ = io.read(workflow, maximum=h.MAX_PLAN, collect=True)
    run = context(h, context_raw, mode, source_notice_review)
    if mode == "accepted":
        h.checked(build, "directory")
        h.checked(support, "directory")
        h.require(type(support_manifest_sha256) is str and h.HEX.fullmatch(support_manifest_sha256),
                  "support-manifest-pin-required")
        support_info, support_raw, _ = io.read(support / "support-manifest.json", maximum=h.MAX_PLAN, collect=True)
        h.require(support_info["sha256"] == support_manifest_sha256, "support-manifest-pin")
        support_rows = support_inventory(h, support_raw)
    work.mkdir()
    evidence = work / "evidence"
    evidence.mkdir()
    snapshots, evidence_rows = {}, []

    def copy(source, target, cap, expected=None):
        identity, _, snapshot = io.read(source, expected, cap)
        h.mkdirs(evidence, h.relative(target)[:-1])
        destination = evidence.joinpath(*h.relative(target))
        h.new_file(destination, io, source=source, expected=identity)
        io.read(destination, identity)
        snapshots[source] = snapshot
        evidence_rows.append({"path": target, **identity})
        return identity

    copy(workflow, "workflow-run.json", h.MAX_PLAN, context_info)
    suffix = run["run_id"] + "-" + run["attempt"]
    original_reports = (
        (reports / ("provenance-" + suffix + ".json"), "provenance.json", 8 * MIB),
        (reports / ("native-observation-" + suffix + ".json"), "native-observation.json", 2 * MIB),
    )
    if mode == "accepted":
        copy(helper_root.parent / "evaluated-workflow.yml", "evaluated-workflow.yml", 128 * 1024)
        # This source is deliberately BUILD_DIR, not the evidence directory.
        copy(build / "archive-verification.json", "archive-verification.json", MIB)
        for source, target, cap in original_reports:
            copy(source, target, cap)
        for side in ("source", "copy"):
            copy(reports / ("native-notice-" + side + "-" + suffix + ".bin"),
                 "native-notice-" + side + ".bin", MIB)
        copy(support / "support-manifest.json", "support-manifest.json", h.MAX_PLAN, support_info)
        for row in support_rows:
            copy(support.joinpath(*h.relative(row["path"])), "support/" + row["path"], 64 * MIB,
                 {"bytes": row["bytes"], "sha256": row["sha256"]})
        reports_json = {}
        for name, cap in (("archive-verification.json", MIB), ("provenance.json", 8 * MIB),
                          ("native-observation.json", 2 * MIB)):
            _, raw, _ = io.read(evidence / name, maximum=cap, collect=True)
            reports_json[name] = h.parse_json(raw)
        h.require(all(type(v) is dict for v in reports_json.values()), "original-report-object")
        archive, provenance, native = (reports_json[k] for k in
            ("archive-verification.json", "provenance.json", "native-observation.json"))
        h.require(archive.get("status") == "PASS" and archive.get("source_sha") == APP_COMMIT
                  and archive.get("recording_required") is True
                  and type(archive.get("recording_source_zip_hashes_verified")) is int
                  and archive["recording_source_zip_hashes_verified"] == 23, "original-archive-incomplete")
        h.require(provenance.get("source_commit") == APP_COMMIT
                  and provenance.get("inspector_commit") == INSPECTOR_COMMIT
                  and provenance.get("inspector_sha256") == INSPECTOR_HASH
                  and provenance.get("inventory_status") in ("complete", "complete_with_unknown_origins")
                  and all(provenance.get(k) is False for k in
                          ("legal_clearance", "corresponding_source_verified", "replacement_verified")),
                  "provenance-identity")
        h.require(type(archive.get("expected_inspector_recording")) is dict
                  and encoded(archive["expected_inspector_recording"]) == encoded(provenance.get("recording_smoke")),
                  "original-recording-inspector-join")
        h.require(native.get("status") == "observed_with_unresolved_origins"
                  and type(native.get("context")) is dict, "native-incomplete")
        for key, expected in {"run_id": run["run_id"], "attempt": run["attempt"],
                              "workflow_sha": run["workflow_sha"], "source_commit": APP_COMMIT,
                              "inspector_commit": INSPECTOR_COMMIT,
                              "inspector_sha256": INSPECTOR_HASH, "prior_job_status": "success"}.items():
            h.require(native["context"].get(key) == expected, "native-context")
        _, raw, _ = io.read(build / h.RECORDING, maximum=65536, collect=True)
        receipt = h.parse_json(raw)
        h.keys(receipt.get("artifacts"), ("archive", "spool"))
        names = set(h.FIXED_PAYLOAD | h.BUILD_METADATA)
        for kind, entry in receipt["artifacts"].items():
            h.keys(entry, ("name", "bytes", "sha256"))
            name = entry["name"]
            h.require(type(name) is str and (name == "recording.mtrec" if kind == "archive" else
                      re.fullmatch(r"recording-[0-9a-f]{32}\.mtspool", name)), "recording-artifact-name")
            names.add(h.WORK + "/" + name)
        h.require(len(names) == 11, "build-inventory")
        build_rows = []
        for name in sorted(names):
            identity, _, snapshot = io.read(build.joinpath(*h.relative(name)), maximum=h.build_cap(name))
            snapshots[build / name] = snapshot
            build_rows.append({"path": name, **identity})
        executable, _, snapshot = io.read(build / h.EXE, maximum=64 * MIB)
        snapshots[build / h.EXE] = snapshot
        manifest_identity = next(row for row in build_rows if row["path"] == h.BUILD_MANIFEST)
        h.require(archive.get("build_manifest_sha256") == manifest_identity["sha256"]
                  and provenance.get("build_manifest_sha256") == manifest_identity["sha256"], "manifest-join")
        h.require(provenance.get("executable_sha256") == executable["sha256"]
                  and type(provenance.get("executable_bytes")) is int
                  and provenance["executable_bytes"] == executable["bytes"], "provenance-executable-join")
        build_index = {row["path"]: row for row in build_rows}
        payload = set(names) - h.BUILD_METADATA
        h.require(archive.get("artifacts_sha256") == {k: build_index[k]["sha256"] for k in payload}
                  and encoded(archive.get("artifact_bytes")) == encoded({k: build_index[k]["bytes"] for k in payload})
                  and archive.get("checksum_file_sha256") == build_index["SHA256SUMS.txt"]["sha256"],
                  "archive-build-join")
        evidence_index = {row["path"]: row for row in evidence_rows}
        h.require(type(native.get("input_hashes")) is dict, "native-input-joins")
        for key, expected in {"manifest": manifest_identity["sha256"],
                              "archive": evidence_index["archive-verification.json"]["sha256"],
                              "provenance": evidence_index["provenance.json"]["sha256"]}.items():
            h.require(native["input_hashes"].get(key) == expected, "native-input-joins")
        notices = native.get("cpython_notice")
        h.require(type(notices) is dict and notices.get("source_copy_equal") is True, "native-notice-join")
        h.require(evidence_index["native-notice-source.bin"]["sha256"] ==
                  evidence_index["native-notice-copy.bin"]["sha256"], "native-notice-copy-equality")
        for side in ("source", "copy"):
            entry = notices.get(side)
            expected = evidence_index["native-notice-" + side + ".bin"]
            h.require(type(entry) is dict and entry.get("status") == "retained_original"
                      and type(entry.get("bytes")) is int and entry["bytes"] == expected["bytes"]
                      and entry.get("sha256") == expected["sha256"], "native-notice-join")
    else:
        # Text diagnostics are a separate, always-incomplete branch. No archive,
        # EXE, PNG, notice .bin, recording payload, support body or wildcard.
        attempts = []
        candidates = [(build / name, "build-diagnostics/" + name, MIB) for name in DIAGNOSTIC_BUILD]
        candidates += [(source, target, MIB) for source, target, _ in original_reports]
        for source, target, cap in candidates:
            outcome = {"path": target}
            try:
                identity, raw, _ = io.read(source, maximum=cap, collect=True)
                text = raw.decode("utf-8")
                h.require(not any(ord(c) < 32 and c not in "\r\n\t" for c in text), "diagnostic-nontext")
                if source.suffix == ".json":
                    h.parse_json(raw)
                copy(source, target, cap, identity)
                outcome["status"] = "retained-original-text"
            except (OSError, ValueError, UnicodeError) as error:
                outcome.update(status="unavailable", reason=type(error).__name__)
            attempts.append(outcome)
        diagnostic = encoded({"status": "INCOMPLETE_DIAGNOSTICS_ONLY", "original_steps": run["steps"],
                              "attempted_explicit_files": attempts, "binary_files_retained": False,
                              "source_notice_acceptance_established": False})
        h.require(len(diagnostic) <= h.MAX_PLAN, "diagnostic-outcome-limit")
        h.new_file(evidence / "diagnostic-outcome.json", io, data=diagnostic)
        evidence_rows.append({"path": "diagnostic-outcome.json", "bytes": len(diagnostic),
                              "sha256": hashlib.sha256(diagnostic).hexdigest()})
        build_rows, executable = [], None
        build = work / "empty-build"
        build.mkdir()
    plan = encoded({"schema_version": 1, "mode": mode, "application_commit": APP_COMMIT,
                    "build_files": build_rows, "evidence_files": evidence_rows, "executable": executable})
    h.require(len(plan) <= h.MAX_PLAN, "expected-manifest-limit")
    h.load_plan(plan, mode)
    plan_path, kit, archive_path = work / "expected-manifest.json", work / "kit", work / "kit.zip"
    h.new_file(plan_path, io, data=plan)
    terminal = invoke(h, io, helper_root, "retain.py", [
        "--build-root", str(build), "--evidence-root", str(evidence), "--output", str(kit),
        "--expected-manifest", str(plan_path), "--expected-manifest-sha256", hashlib.sha256(plan).hexdigest(),
        "--mode", mode], work)
    wanted = "BYTES_RETAINED_ONLY" if mode == "accepted" else "INCOMPLETE_DIAGNOSTICS_ONLY"
    h.require(terminal.get("status") == wanted, "retention-terminal-status")
    outer = h.info_value(terminal.get("outer_manifest"), h.MAX_PLAN)
    io.read(kit / "OUTER_MANIFEST.json", outer)
    zipped = invoke(h, io, helper_root, "zip_kit.py", [
        "--kit", str(kit), "--output", str(archive_path), "--outer-manifest-sha256", outer["sha256"],
        "--mode", mode], work)
    h.require(zipped.get("status") == "KIT_ZIP_BYTES_VERIFIED_ONLY" and zipped.get("mode") == mode
              and zipped.get("outer_manifest") == outer and zipped.get("upload_download") == "not-performed"
              and zipped.get("distribution_authorized_by_this_helper") is False, "zip-terminal-status")
    zip_info = h.info_value(zipped.get("zip"), 514 * MIB)
    io.read(archive_path, zip_info)
    for path, snapshot in snapshots.items():
        h.require(h.stable(h.checked(path, "file")) == snapshot, "caller-source-changed")
    result = {"status": "LOCAL_KIT_BYTES_VERIFIED_ONLY" if mode == "accepted" else wanted,
              "mode": mode, "retention_exit_code": 0, "zip_exit_code": 0, "zip": zip_info,
              "outer_manifest": outer, "application_commit": APP_COMMIT, "retention_commit": RETENTION_COMMIT,
              "source_notice_review": run["source_notice_review"], "original_steps": run["steps"],
              "upload_download": "not-performed", "public_binary_publication_authorized": False,
              "windows_10_verified": False, "physical_verified": False}
    h.new_file(work / "caller-terminal.json", io, data=encoded(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("helper-root", "build-root", "reports-root", "support-root", "output-root", "workflow-run"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--mode", choices=("accepted", "diagnostics"), required=True)
    parser.add_argument("--support-manifest-sha256")
    parser.add_argument("--source-notice-review")
    args = vars(parser.parse_args())
    try:
        result = stage(**args)
    except Exception as error:
        print(json.dumps({"status": "CALLER_REJECTED", "error_type": type(error).__name__,
                          "partial_output_must_not_be_consumed": True}), file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    # A successful diagnostics copy must never turn the failed job green.
    return 0 if args["mode"] == "accepted" else 1


if __name__ == "__main__":
    raise SystemExit(main())
