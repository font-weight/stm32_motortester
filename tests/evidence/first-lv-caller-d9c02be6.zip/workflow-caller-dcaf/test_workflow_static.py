"""Static local YAML/inline-Python checks; never invoke PowerShell or Actions."""
import ast
import hashlib
import os
from pathlib import Path
import re
import tempfile
import subprocess
import unittest
import yaml

HERE = Path(__file__).absolute().parent
BASE = Path(os.environ["CALLER_BASE_WORKFLOW"]).absolute()
DRAFT = HERE / "host-windows.local-draft.yml"


class UniqueLoader(yaml.BaseLoader):
    pass


def mapping(loader, node):
    pairs = loader.construct_pairs(node)
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate YAML key: " + str(key))
        result[key] = value
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, mapping)


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = yaml.load(BASE.read_text(), Loader=UniqueLoader)
        cls.draft = yaml.load(DRAFT.read_text(), Loader=UniqueLoader)
        cls.job = cls.draft["jobs"]["verify"]
        cls.steps = cls.job["steps"]
        cls.by_id = {row["id"]: row for row in cls.steps if "id" in row}

    def test_01_baseline_unchanged(self):
        self.assertEqual(hashlib.sha256(BASE.read_bytes()).hexdigest(),
                         "7341772216fa98fc98946e466cf36038a66dfec15977b3118d76e28109a998b6")

    def test_02_unrelated_original_steps_preserved_and_ordered(self):
        replaced = {"Bind separate metadata-only supplement from evaluated workflow",
                    "Observe bounded native metadata and original CPython notice"}
        names = [step["name"] for step in self.steps]
        originals = [row for row in self.base["jobs"]["verify"]["steps"] if row["name"] not in replaced]
        renamed = {"Preserve bounded supplemental receipt independently": "Preserve original CPython notice receipt independently"}
        indexes = [names.index(renamed.get(step["name"], step["name"])) for step in originals]
        self.assertEqual(indexes, sorted(indexes))
        for step in originals:
            actual = self.steps[names.index(renamed.get(step["name"], step["name"]))]
            if step["name"] in {"Prepare temporary output location", "Preserve evidence in job logs only",
                               "Verify clean source and record provenance", "Verify every tracked worktree file against its raw Git blob"}:
                continue  # Separate exact checks cover each bounded delta below.
            expected = dict(step)
            if step["name"] == "Checkout immutable host candidate":
                expected["with"] = {**step["with"], "ref": "dcafc5638bc6c3ddef6cba25a7a55016fe8e8933"}
            if step["name"] in renamed:
                expected["name"] = renamed[step["name"]]
                expected["run"] = (step["run"].replace("'native-observation-'", "'cpython-notice-'")
                    .replace("'native-observation.json'", "'cpython-notice.json'")
                    .replace("os.environ['OBSERVER_REPORT']", "os.environ['NOTICE_REPORT']")
                    .replace("print('NATIVE_EVIDENCE ", "print('CPYTHON_NOTICE_EVIDENCE "))
            for key, value in expected.items():
                self.assertEqual(actual[key], value, (step["name"], key))
        self.assertTrue(replaced.isdisjoint(names))

    def test_03_original_logs_modified_only_for_truthful_summary(self):
        def pick(doc):
            return next(x["run"] for x in doc["jobs"]["verify"]["steps"] if x["name"] == "Preserve evidence in job logs only")
        before, after = pick(self.base), pick(self.draft)
        self.assertEqual(before.split('@"', 1)[0], after.split('@"', 1)[0])
        self.assertIn("This step uses no Actions artifact storage", after)

    def test_04_draft_disabled_and_external_scope_bound_without_approval_flag(self):
        self.assertTrue(self.job["if"].startswith("false &&"))
        env = self.job["env"]
        self.assertEqual(env["SUPPORT_SOURCE_SHA"], env["SOURCE_SHA"])
        self.assertEqual(env["SUPPORT_MANIFEST_GIT_PATH"], "scripts/ci/windows-first-test/support-manifest.json")
        self.assertEqual(env["SUPPORT_MANIFEST_SHA256"], hashlib.sha256((HERE / "support-manifest.json").read_bytes()).hexdigest())
        self.assertEqual(env["SOURCE_NOTICE_REVIEW"], "https://github.com/font-weight/stm32_motortester/issues/33#issuecomment-6233217133")

    def test_05_caller_body_pin_matches(self):
        raw = (HERE / "stage_plan.py").read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        self.assertEqual(self.job["env"]["CALLER_FILE_SHA256"], digest)
        for mode in ("accepted", "diagnostics"):
            self.assertIn("'" + str(len(raw)) + "' $env:CALLER_FILE_SHA256", self.by_id["stage_" + mode]["run"])

    def test_06_exact_original_outcome_ids(self):
        required = ("verify_source", "verify_raw_blobs", "bind_inspector", "bind_retention_caller", "prepare_required_support",
                    "build_candidate", "verify_archives", "inspect_candidate", "verify_reduced_payload",
                    "verify_cpython_notices", "retain_notice_logs", "retain_job_logs", "retain_recording_logs")
        self.assertTrue(set(required) <= set(self.by_id))
        accepted = self.by_id["stage_accepted"]
        self.assertIn("success()", accepted["if"])
        self.assertGreater(self.steps.index(accepted), max(self.steps.index(self.by_id[k]) for k in required))
        for key in required:
            self.assertIn(repr(key), accepted["run"])
        self.assertIn("steps[key]['outcome']", accepted["run"])

    def test_07_failure_cannot_be_made_green(self):
        step = self.by_id["stage_diagnostics"]
        self.assertIn("always()", step["if"])
        self.assertIn("steps.stage_accepted.outcome != 'success'", step["if"])
        self.assertIn("throw 'INCOMPLETE_DIAGNOSTICS_ONLY", step["run"])
        self.assertFalse(any("continue-on-error" in row for row in self.steps))

    def test_08_final_terminal_and_whole_zip_hash_checked(self):
        code = self.by_id["stage_accepted"]["run"]
        self.assertIn("$LASTEXITCODE -ne 0", code)
        self.assertIn("$terminal.retention_exit_code -ne 0", code)
        self.assertIn("$terminal.zip_exit_code -ne 0", code)
        self.assertIn("Get-FileHash -LiteralPath $zip.FullName -Algorithm SHA256", code)
        self.assertIn("538968064", code)

    def test_09_no_upload_or_write_permission_in_base_patch(self):
        self.assertEqual(self.draft["permissions"], {"contents": "read"})
        self.assertFalse(any("upload-artifact" in row.get("uses", "") for row in self.steps))
        self.assertNotIn("secrets.", DRAFT.read_text())

    def test_10_inline_python_syntax_only(self):
        text = DRAFT.read_text()
        codes = re.findall(r"          \$[A-Za-z]+ = @'\n(.*?)          '@", text, re.S)
        self.assertGreaterEqual(len(codes), 12)
        for index, body in enumerate(codes):
            code = "\n".join(line[10:] if line.startswith("          ") else line for line in body.splitlines())
            ast.parse(code, filename="inline-python-" + str(index))

    def test_11_local_patch_applies_and_optional_upload_stays_disabled(self):
        with tempfile.TemporaryDirectory(prefix="patch-check-", dir=HERE) as tmp:
            root = Path(tmp)
            target = root / ".github/workflows/host-windows.yml"
            target.parent.mkdir(parents=True)
            target.write_bytes(BASE.read_bytes())
            for name in ("host-windows.local-draft.patch", "host-windows.upload-optional.patch"):
                result = subprocess.run(["patch", "--batch", "-p1", "-i", str(HERE / name)], cwd=root,
                                        capture_output=True, timeout=10)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                if name == "host-windows.local-draft.patch":
                    self.assertEqual(target.read_bytes(), DRAFT.read_bytes())
            full = yaml.load(target.read_text(), Loader=UniqueLoader)
            job = full["jobs"]["verify"]
            self.assertEqual(job["env"]["PUBLIC_BINARY_UPLOAD_AUTHORIZED"], "false")
            upload = job["steps"][-1]
            self.assertEqual(upload["uses"], "actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9")
            self.assertEqual(upload["with"], {"name": "windows-first-test-${{ github.run_id }}-${{ github.run_attempt }}",
                "path": "${{ env.CALLER_ZIP }}", "archive": "true", "retention-days": "1",
                "overwrite": "false", "include-hidden-files": "false", "if-no-files-found": "error"})
            self.assertIn("env.PUBLIC_BINARY_UPLOAD_AUTHORIZED == 'true'", upload["if"])
            self.assertEqual(full["permissions"], {"contents": "read"})

    def test_12_all_actions_immutable(self):
        for row in self.steps:
            if "uses" in row:
                self.assertRegex(row["uses"], r"^[a-zA-Z0-9_/-]+@[a-f0-9]{40}$")

    def test_13_new_app_tree_helpers_and_checker_bound_exactly(self):
        env = self.job["env"]
        self.assertEqual(env["SOURCE_SHA"], "dcafc5638bc6c3ddef6cba25a7a55016fe8e8933")
        self.assertEqual(env["SOURCE_TREE"], "61a9bd025081acec80997dff950d947eeceb3f4b")
        self.assertEqual(env["RETENTION_SHA"], "49c271104939a9c6ca6027ec239a904cac11a1a3")
        checker = Path(os.environ["CALLER_TEST_CHECKER"]).read_bytes()
        self.assertEqual(len(checker), 24424)
        self.assertEqual(env["PAYLOAD_CHECKER_SHA256"], hashlib.sha256(checker).hexdigest())
        self.assertEqual(env["EVALUATED_WORKFLOW_SHA"], "${{ github.workflow_sha }}")
        raw = DRAFT.read_text()
        for old in ("244b0786a18fed19a9e708bb815150475ddd193f", "OBSERVER_", "bind_native_observer",
                    "native-observation", "run17-native-baseline", "observe_native_origins"):
            self.assertNotIn(old, raw)
        binder = self.by_id["bind_retention_caller"]["run"]
        self.assertIn("3ab02204cf20771c1ff67ca0ec05c8d8c6cb639a93ed56a653ba487fc856b08c", binder)
        self.assertIn("1270725f73afe9c947e7ce5835779eee28c7604d429a30f244aff06684fe40b6", binder)
        self.assertIn("exec(compile(raw", binder)
        self.assertIn("raw = process.stdout.read(cap + 1)", binder)

    def test_14_support_materializer_has_explicit_bounds_and_no_archive_execution(self):
        code = self.by_id["prepare_required_support"]["run"]
        self.assertIn("SUPPORT_DOWNLOADS =", code)
        self.assertIn("h.require(len(rows) == 11", code)
        self.assertIn("response.read(min(1048576, row['bytes'] - total + 1))", code)
        self.assertIn("deadline = time.monotonic() + 240", code)
        self.assertIn("max_redirections, max_repeats = 3, 1", code)
        self.assertIn("newurl in self.allowed", code)
        self.assertIn("opener.open(request, timeout=15)", code)
        self.assertIn("digest.hexdigest() == row['sha256']", code)
        self.assertNotIn("extract", code)
        self.assertNotIn("subprocess", code)
        self.assertNotIn("SUPPORT_FILE_PREFIX", self.job["env"])
        self.assertNotIn("SOURCE_NOTICE_APPROVED", DRAFT.read_text())

    def test_15_original_source_guards_kept_plus_exact_new_delta(self):
        before = next(row["run"] for row in self.base["jobs"]["verify"]["steps"] if row["name"] == "Verify clean source and record provenance")
        after = self.by_id["verify_source"]["run"]
        lines = after.splitlines(True)
        filtered = ''.join(line for line in lines if not line.startswith(("$spec =", "$selector =", "if ($LASTEXITCODE -ne 0 -or $spec", "if ($LASTEXITCODE -ne 0 -or $selector")))
        self.assertEqual(filtered, before)
        self.assertIn("a4ef30566e9f6ed8bfad2db322cc8ba7f8bace94", after)
        self.assertIn("4455b92a3fd1937bbbec94b820640418e13e24c0", after)
        before = next(row["run"] for row in self.base["jobs"]["verify"]["steps"] if row["name"] == "Verify every tracked worktree file against its raw Git blob")
        after = self.by_id["verify_raw_blobs"]["run"]
        self.assertEqual(after.replace("if checked != 1501:\n    raise RuntimeError('Unexpected dcaf source file count')\n", ""), before)

    def test_16_checker_and_notice_after_original_successes_before_retention(self):
        order = [self.steps.index(self.by_id[key]) for key in ("build_candidate", "verify_archives", "inspect_candidate",
                 "verify_reduced_payload", "verify_cpython_notices", "retain_notice_logs", "stage_accepted")]
        self.assertEqual(order, sorted(order))
        payload = self.by_id["verify_reduced_payload"]["run"]
        self.assertIn("raw = caller.bound_raw(path, *caller.PAYLOAD_CHECKER)", payload)
        self.assertIn("'--expected-archive-report-sha256', archive_info['sha256']", payload)
        self.assertIn("'--expected-manifest-sha256', manifest_info['sha256']", payload)
        self.assertIn("exec(compile(raw", payload)
        self.assertNotIn("__pycache__", payload)
        notice = self.by_id["verify_cpython_notices"]["run"]
        self.assertIn("caller.capture_cpython_notices", notice)
        self.assertNotIn("always()", self.by_id["verify_cpython_notices"].get("if", ""))

    def test_17_generator_reproduces_exact_frozen_outputs(self):
        names = ("host-windows.local-draft.yml", "host-windows.local-draft.patch", "host-windows.upload-optional.patch")
        before = {name: (HERE / name).read_bytes() for name in names}
        result = subprocess.run(["python", "-B", str(HERE / "build_workflow_draft.py")], capture_output=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(before, {name: (HERE / name).read_bytes() for name in names})


if __name__ == "__main__":
    unittest.main(verbosity=2)
