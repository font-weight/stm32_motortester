"""Inert local fixtures; no native program, Windows build, upload or dispatch."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import py_compile
import subprocess
import sys
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).absolute().parent
HELPER_SOURCE = Path(os.environ["CALLER_TEST_HELPERS"]).absolute()
s = types.ModuleType("stage_plan")
s.__file__ = str(HERE / "stage_plan.py")
exec(compile((HERE / "stage_plan.py").read_bytes(), s.__file__, "exec"), s.__dict__)


# These are inert fixtures. The historical Windows installer notice body is not
# locally available; only tests patch NOTICE_HASH to the fixture digest. Production
# source constants are never edited, and a real CLI negative test proves rejection.
APP_SOURCE = Path(os.environ["CALLER_TEST_APP_SOURCE"]).absolute()
POLICY_PATH = APP_SOURCE / "host/packaging/select_windows_runtime.py"
policy_raw = POLICY_PATH.read_bytes()
if hashlib.sha256(policy_raw).hexdigest() != s.SOURCE_PINS["host/packaging/select_windows_runtime.py"]["sha256"]:
    raise RuntimeError("fixture policy source drift")
POLICY = {node.targets[0].id: ast.literal_eval(node.value) for node in ast.parse(policy_raw).body
          if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
          and node.targets[0].id in ("EXCLUDED_DESTINATIONS", "REQUIRED_DESTINATIONS")}


def info(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


class CallerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="inert-caller-", dir=HERE)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.helpers, self.build, self.support = (self.root / p for p in ("helpers", "build", "support"))
        self.work = self.root / "result"
        for path in (self.helpers, self.build, self.support):
            path.mkdir()
        for name in s.HELPERS:
            self.put(self.helpers / name, (HELPER_SOURCE / name).read_bytes())
        self.h = s.helpers(self.helpers)
        self.notice = b"INERT LICENSE TEXT; NOT LEGAL ACCEPTANCE\n"
        patcher = mock.patch.object(s, "NOTICE_HASH", info(self.notice)["sha256"])
        patcher.start()
        self.addCleanup(patcher.stop)
        self.exe = b"INERT TEXT ONLY; THIS IS NOT A PE EXECUTABLE\n"
        self.payload = {name: ("INERT " + name + "\n").encode() for name in self.h.FIXED_PAYLOAD}
        archive, spool = "recording.mtrec", "recording-" + "a" * 32 + ".mtspool"
        self.payload[self.h.WORK + "/" + archive] = b"NOT A RECORDING\n"
        self.payload[self.h.WORK + "/" + spool] = b"NOT A SPOOL\n"
        receipt = {"status": "passed", "phase": "complete", "error": None,
                   "output": self.h.RECORDING, "workdir": self.h.WORK, "executable": info(self.exe),
                   "artifacts": {"archive": {"name": archive, **info(self.payload[self.h.WORK + "/" + archive])},
                                 "spool": {"name": spool, **info(self.payload[self.h.WORK + "/" + spool])}}}
        self.payload[self.h.RECORDING] = s.encoded(receipt)
        self.sums = {name: info(raw)["sha256"] for name, raw in self.payload.items()}
        self.payload["SHA256SUMS.txt"] = "".join(digest + "  " + name + "\n" for name, digest in sorted(self.sums.items())).encode()
        self.payload["build.log"] = b"INERT; NO BUILD RAN\nWindows 10 1809+ x64 runtime selection: 0 of 47 approved destinations removed\n"
        app = APP_SOURCE
        dep_root = app / "host/packaging/licenses/dependency-6.12.0"
        dep_raw = (dep_root / "manifest.json").read_bytes()
        guide_raw = (app / "host/docs/dependency-sources.md").read_bytes()
        self.dependency_files = {"manifest.json": dep_raw, "dependency-sources.md": guide_raw,
            **{row["path"]: (dep_root / row["path"]).read_bytes() for row in json.loads(dep_raw)["input_files"]}}
        license_files = {}
        for name, raw in self.dependency_files.items():
            path = "licenses/dependency-6.12.0/" + name
            self.put(self.build / "dist/Motortester" / path, raw)
            license_files[path] = info(raw)["sha256"]
        project_raw = (app / "host/docs/project-license.md").read_bytes()
        review_raw = (app / "host/packaging/LICENSE-REVIEW.md").read_bytes()
        for name, raw in (("_internal/docs/project-license.md", project_raw),
                          ("_internal/docs/dependency-sources.md", guide_raw), ("LICENSE-REVIEW.md", review_raw)):
            self.put(self.build / "dist/Motortester" / name, raw)
            license_files[name] = info(raw)["sha256"]
        notices = [{"path": "dependency-6.12.0/" + name, **info(raw)} for name, raw in self.dependency_files.items()]
        self.inventory = [{"name": name, "vendored_notices": copy.deepcopy(notices),
                           "copied_notices": [row["path"] for row in notices]} for name in ("PySide6_Essentials", "shiboken6")]
        self.inventory_raw = s.encoded(self.inventory)
        self.put(self.build / "dist/Motortester/licenses/inventory.json", self.inventory_raw)
        license_files["licenses/inventory.json"] = info(self.inventory_raw)["sha256"]
        self.payload[self.h.BUILD_MANIFEST] = s.encoded({"source_commit": s.APP_COMMIT,
            "status": "candidate-not-release-approved", "usb_verified": False,
            "windows_10_manual_acceptance": "not performed by this script",
            "license_review": "required; see LICENSE-REVIEW.md", "python": "3.13.16",
            "files": {"Motortester.exe": info(self.exe)["sha256"], "licenses/CPython-LICENSE.txt": s.NOTICE_HASH, **license_files}})
        for name, raw in self.payload.items():
            self.put(self.build / name, raw)
        self.put(self.build / self.h.EXE, self.exe)
        self.review = "https://github.com/font-weight/stm32_motortester/issues/33#inert-example-not-approval"
        self.context = {"schema_version": 1, "repository": "font-weight/stm32_motortester",
            "run_id": "123", "attempt": "1", "workflow_sha": "a" * 40,
            "application_commit": s.APP_COMMIT, "application_tree": s.APP_TREE,
            "inspector_commit": s.INSPECTOR_COMMIT, "inspector_sha256": s.INSPECTOR_HASH,
            "payload_checker_sha256": s.PAYLOAD_CHECKER[1],
            "source_notice_review": self.review, "steps": {key: "success" for key in s.REQUIRED_STEPS}}
        self.workflow = self.root / "workflow-run.json"
        self.save_context()
        self.put(self.root / "evaluated-workflow.yml", b"# INERT EVALUATED WORKFLOW FIXTURE\n")
        summary = {"fixture": "INERT summary; not a validator result"}
        manifest_hash = info(self.payload[self.h.BUILD_MANIFEST])["sha256"]
        self.archive = {"status": "PASS", "source_sha": s.APP_COMMIT, "recording_required": True,
            "source_files": 306, "recording_source_zip_hashes_verified": 23, "expected_inspector_recording": summary,
            "build_manifest_sha256": manifest_hash, "artifacts_sha256": self.sums,
            "artifact_bytes": {name: len(self.payload[name]) for name in self.sums},
            "checksum_file_sha256": info(self.payload["SHA256SUMS.txt"])["sha256"]}
        self.toc = b"[] # INERT COLLECT TOC\n"
        self.put(self.build / "pyinstaller/motortester/COLLECT-00.toc", self.toc)
        self.provenance = {"source_commit": s.APP_COMMIT, "inspector_commit": s.INSPECTOR_COMMIT,
            "inspector_sha256": s.INSPECTOR_HASH, "build_manifest_sha256": manifest_hash,
            "collect_toc_sha256": info(self.toc)["sha256"], "pyinstaller_version": "6.22.3",
            "inventory_status": "complete_with_unknown_origins", "legal_clearance": False,
            "corresponding_source_verified": False, "replacement_verified": False,
            "recording_smoke": summary, "executable_sha256": info(self.exe)["sha256"], "executable_bytes": len(self.exe)}
        self.native = {"schema_version": 1, "status": "PASS", "scope": "original-cpython-notice-byte-correspondence", "context": {
            "run_id": "123", "attempt": "1", "workflow_sha": "a" * 40, "source_commit": s.APP_COMMIT,
            "source_tree": s.APP_TREE},
            "input_hashes": {"manifest": manifest_hash, "toc": info(self.toc)["sha256"]},
            "cpython_notice": {"source_copy_equal": True, "matches_run17_hash": True,
                **{side: {"status": "retained_original", **info(self.notice)} for side in ("source", "copy")}}}
        policy = {"excluded_absent_count": 47, "required_present_count": 7,
                  "excluded_absent": list(POLICY["EXCLUDED_DESTINATIONS"]),
                  "required_present": [{"destination": name, "actual_path": "_internal/" + name,
                                        **info(b"inert keeper")} for name in POLICY["REQUIRED_DESTINATIONS"]]}
        self.checker = {"schema_version": 1, "status": "PASS", "scope": "data-only-final-reduced-payload-correspondence",
            "application_commit": s.APP_COMMIT, "application_tree": s.APP_TREE,
            "actual_checker": {"bytes": s.PAYLOAD_CHECKER[0], "sha256": s.PAYLOAD_CHECKER[1]},
            "actual_source_inputs": s.SOURCE_PINS, "onedir_policy": copy.deepcopy(policy), "zip_policy": copy.deepcopy(policy),
            "archive_validator_required": True, "archive_validator_pass_report_bound": True,
            **{key: False for key in ("native_code_executed", "candidate_python_executed", "payload_modified",
                "authenticated_origins", "tls_capability_verified", "hardware_verified", "physical_stop_verified",
                "windows_10_verified", "legal_clearance", "bytes_delivered")}}
        self.put(self.build / "dist/Motortester/licenses/CPython-LICENSE.txt", self.notice)
        for side in ("source", "copy"):
            self.put(self.root / ("native-notice-" + side + "-123-1.bin"), self.notice)
        self.save_reports()
        self.support_rows = []
        for name, raw in {"required-source.zip": b"INERT NON-ZIP SOURCE SUPPORT\n",
                          "NOTICES.txt": b"INERT NOTICES\n", "FIRST-TEST-CHECKLIST.md": b"INERT CHECKLIST\n",
                          "host/packaging/licenses/dependency-6.12.0/manifest.json": dep_raw,
                          "host/docs/dependency-sources.md": guide_raw,
                          "host/docs/project-license.md": project_raw,
                          "host/packaging/LICENSE-REVIEW.md": review_raw}.items():
            self.put(self.support / name, raw)
            self.support_rows.append({"path": name, **info(raw)})
        self.save_support()

    def put(self, path, raw):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def save_context(self):
        self.put(self.workflow, s.encoded(self.context))

    def save_support(self):
        raw = s.encoded(self.support_rows)
        self.put(self.support / "support-manifest.json", raw)
        self.support_hash = info(raw)["sha256"]

    def save_reports(self):
        a, p = s.encoded(self.archive), s.encoded(self.provenance)
        self.put(self.build / "archive-verification.json", a)
        self.put(self.root / "provenance-123-1.json", p)
        self.native["input_hashes"].update(archive=info(a)["sha256"], provenance=info(p)["sha256"])
        self.put(self.root / "cpython-notice-123-1.json", s.encoded(self.native))
        for key, name in (("actual_source_zip", "source.zip"), ("actual_candidate_zip", "Motortester-windows-x64-candidate.zip"),
                          ("actual_build_manifest", self.h.BUILD_MANIFEST), ("actual_checksums", "SHA256SUMS.txt")):
            self.checker[key] = info(self.payload[name])
        self.checker["actual_archive_verification_report"] = info(a)
        self.checker["actual_artifacts"] = {name: info(self.payload[name]) for name in self.sums}
        self.put(self.root / "reduced-payload-123-1.json", s.encoded(self.checker))

    def args(self, **kw):
        value = dict(helper_root=str(self.helpers), build_root=str(self.build), reports_root=str(self.root),
            support_root=str(self.support), output_root=str(self.work), workflow_run=str(self.workflow), mode="accepted",
            support_manifest_sha256=self.support_hash, source_notice_review=self.review)
        value.update(kw)
        return value

    def call(self, **kw):
        return s.stage(**self.args(**kw))

    def reject(self, code=None, **kw):
        with self.assertRaises(Exception) as caught:
            self.call(**kw)
        if code:
            self.assertIn(code, str(caught.exception))
        return caught.exception

    def test_01_exact_plan_and_original_archive_copy(self):
        original = (self.build / "archive-verification.json").read_bytes()
        result = self.call()
        self.assertEqual(result["status"], "LOCAL_KIT_BYTES_VERIFIED_ONLY")
        self.assertEqual(result["zip"], info((self.work / "kit.zip").read_bytes()))
        plan = json.loads((self.work / "expected-manifest.json").read_bytes())
        self.assertEqual(len(plan["build_files"]), 11)
        self.assertEqual(len(plan["evidence_files"]), 19)
        self.assertEqual((self.work / "kit/evidence/archive-verification.json").read_bytes(), original)
        self.assertEqual((self.build / "archive-verification.json").read_bytes(), original)
        self.assertEqual((self.work / "kit/build/SHA256SUMS.txt").read_bytes(), self.payload["SHA256SUMS.txt"])
        self.assertEqual(json.loads((self.work / "retain.py.exit.json").read_bytes()), {"exit_code": 0})
        self.assertFalse(result["public_binary_publication_authorized"])
        self.assertEqual(result["upload_download"], "not-performed")

    def test_02_each_original_failure_blocks_accepted_before_output(self):
        for step in s.REQUIRED_STEPS:
            self.context["steps"][step] = "failure"
            self.save_context()
            self.reject("original-checks-incomplete")
            self.assertFalse(self.work.exists())
            self.context["steps"][step] = "success"

    def test_03_support_manifest_pin_required(self):
        for pin in (None, "PENDING", "0" * 64):
            self.reject("support-manifest", support_manifest_sha256=pin)
            self.assertFalse(self.work.exists())

    def test_04_external_review_reference_required(self):
        self.reject("external-review-binding", source_notice_review="PENDING")
        self.assertFalse(self.work.exists())

    def test_05_support_changed(self):
        self.put(self.support / self.support_rows[-1]["path"], b"changed")
        self.reject("input-")
        self.assertFalse((self.work / "kit.zip").exists())

    def test_06_support_inventory_malformed_or_empty(self):
        cases = [[], [self.support_rows[0], self.support_rows[0]],
                 [{**self.support_rows[0], "path": "../escape"}], self.support_rows * 6]
        for rows in cases:
            self.support_rows = rows
            self.save_support()
            self.reject()
            self.assertFalse(self.work.exists())

    def test_07_missing_required_archive_never_substituted(self):
        (self.build / "archive-verification.json").unlink()
        self.reject()
        self.assertFalse((self.work / "kit").exists())

    def test_08_archive_failure_rejected(self):
        self.archive["status"] = "FAILED"
        self.save_reports()
        self.reject("original-archive-incomplete")

    def test_09_provenance_join_rejected(self):
        self.provenance["recording_smoke"] = {"different": True}
        self.save_reports()
        self.reject("original-recording-inspector-join")

    def test_10_wrong_native_run_rejected(self):
        self.native["context"]["attempt"] = "2"
        self.save_reports()
        self.reject("notice-context")

    def test_11_original_notice_changed_rejected(self):
        self.put(self.root / "native-notice-copy-123-1.bin", b"changed")
        self.reject("notice-copy-equality")

    def test_12_unlisted_files_not_copied(self):
        self.put(self.support / "secret.txt", b"SECRET MUST NOT COPY")
        self.put(self.build / "venv/secret.txt", b"SECRET MUST NOT COPY")
        self.call()
        self.assertFalse((self.work / "kit/evidence/support/secret.txt").exists())
        self.assertFalse((self.work / "kit/build/venv").exists())

    def test_13_changed_helper_rejected_before_output(self):
        path = self.helpers / "retain.py"
        raw = path.read_bytes()
        path.write_bytes(raw.replace(b"import argparse", b"import argparsE", 1))
        self.reject("helper-body-identity")
        self.assertFalse(self.work.exists())

    def test_14_sourceless_pyc_cache_is_never_consumed(self):
        path = self.helpers / "retain.py"
        raw = path.read_bytes()
        saved = path.stat()
        marker = self.root / "PYC_WAS_EXECUTED"
        evil = ("from pathlib import Path\nPath(" + repr(str(marker)) + ").write_text('bad')\n").encode()
        path.write_bytes(evil + b"#" * (len(raw) - len(evil)))
        os.utime(path, ns=(saved.st_atime_ns, saved.st_mtime_ns))
        py_compile.compile(str(path), doraise=True)
        path.write_bytes(raw)
        os.utime(path, ns=(saved.st_atime_ns, saved.st_mtime_ns))
        self.call()
        self.assertFalse(marker.exists())

    def test_15_diagnostics_whitelist_text_only_incomplete(self):
        self.context["steps"]["build_candidate"] = "failure"
        self.save_context()
        self.put(self.build / "build.log", b"MZ\x00binary")
        self.put(self.build / "surprise.stderr", b"not allowlisted")
        result = self.call(mode="diagnostics", support_manifest_sha256=None, source_notice_review=None)
        self.assertEqual(result["status"], "INCOMPLETE_DIAGNOSTICS_ONLY")
        plan = json.loads((self.work / "expected-manifest.json").read_bytes())
        self.assertEqual(plan["build_files"], [])
        self.assertIsNone(plan["executable"])
        names = [row["path"] for row in plan["evidence_files"]]
        self.assertNotIn("build-diagnostics/build.log", names)
        self.assertFalse(any(name.endswith((".zip", ".exe", ".png", ".bin", ".mtrec", ".mtspool")) for name in names))
        self.assertNotIn("surprise.stderr", names)
        self.assertFalse((self.work / "kit/evidence/support").exists())
        outcome = json.loads((self.work / "kit/evidence/diagnostic-outcome.json").read_bytes())
        row = next(row for row in outcome["attempted_explicit_files"] if row["path"] == "build-diagnostics/build.log")
        self.assertEqual(row["status"], "unavailable")
        self.assertEqual(outcome["original_steps"]["build_candidate"], "failure")

    def test_16_diagnostics_missing_build_still_retains_outcomes(self):
        result = self.call(mode="diagnostics", build_root=str(self.root / "absent"))
        self.assertEqual(result["status"], "INCOMPLETE_DIAGNOSTICS_ONLY")

    def test_17_diagnostics_oversize_not_silently_truncated(self):
        self.put(self.build / "build.log", b"a" * (s.MIB + 1))
        self.call(mode="diagnostics")
        self.assertFalse((self.work / "kit/evidence/build-diagnostics/build.log").exists())
        self.assertEqual((self.build / "build.log").stat().st_size, s.MIB + 1)

    def test_18_existing_output_preserved(self):
        self.work.mkdir()
        self.put(self.work / "keep", b"preserve")
        self.reject("case-alias")
        self.assertEqual((self.work / "keep").read_bytes(), b"preserve")

    def test_19_symlink_support_rejected(self):
        path = self.support / "NOTICES.txt"
        path.unlink()
        path.symlink_to(self.root / "native-notice-source-123-1.bin")
        self.reject("symlink-or-reparse")

    def test_20_retainer_nonzero_never_calls_zip(self):
        actual = s.invoke
        calls = []
        def failed(h, io, root, name, args, work):
            calls.append(name)
            if name == "retain.py":
                raise h.Reject("helper-terminal-nonzero")
            return actual(h, io, root, name, args, work)
        with mock.patch.object(s, "invoke", side_effect=failed):
            self.reject("helper-terminal-nonzero")
        self.assertEqual(calls, ["retain.py"])
        self.assertFalse((self.work / "kit.zip").exists())

    def test_21_wrong_terminal_outer_hash_blocks_zip(self):
        actual = s.invoke
        def corrupt(*args):
            result = actual(*args)
            if args[3] == "retain.py":
                result["outer_manifest"]["sha256"] = "0" * 64
            return result
        with mock.patch.object(s, "invoke", side_effect=corrupt):
            self.reject("input-digest-mismatch")
        self.assertFalse((self.work / "kit.zip").exists())

    def test_22_final_zip_readback_rejects_changed_bytes(self):
        actual = s.invoke
        def corrupt(*args):
            result = actual(*args)
            if args[3] == "zip_kit.py":
                with (self.work / "kit.zip").open("ab") as out:
                    out.write(b"extra")
            return result
        with mock.patch.object(s, "invoke", side_effect=corrupt):
            self.reject("input-size-mismatch")
        self.assertFalse((self.work / "caller-terminal.json").exists())

    def test_23_cli_diagnostics_is_nonzero_and_incomplete(self):
        args = self.args(mode="diagnostics")
        command = [sys.executable, "-I", "-S", "-B"] + (["-O"] if sys.flags.optimize else [])
        command += [str(HERE / "stage_plan.py")]
        command += [part for key, value in args.items() for part in ("--" + key.replace("_", "-"), value)]
        result = subprocess.run(command, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "INCOMPLETE_DIAGNOSTICS_ONLY")

    def test_24_missing_workflow_source_rejected(self):
        (self.root / "evaluated-workflow.yml").unlink()
        self.reject()
        self.assertFalse((self.work / "kit").exists())

    def test_25_late_original_receipt_mutation_rejected(self):
        actual = s.invoke
        def mutate(*args):
            result = actual(*args)
            if args[3] == "zip_kit.py":
                self.put(self.build / "archive-verification.json", b"changed after packaging")
            return result
        with mock.patch.object(s, "invoke", side_effect=mutate):
            self.reject("caller-source-changed")
        self.assertFalse((self.work / "caller-terminal.json").exists())

    def test_26_duplicate_json_support_rejected(self):
        raw = b'[{"path":"one","path":"two","bytes":1,"sha256":"' + b'a'*64 + b'"}]'
        self.put(self.support / "support-manifest.json", raw)
        self.support_hash = info(raw)["sha256"]
        self.reject("duplicate-json-key")
        self.assertFalse(self.work.exists())

    def test_27_build_candidate_pin_not_silently_rebound(self):
        self.context["application_commit"] = "244b0786a18fed19a9e708bb815150475ddd193f"
        self.save_context()
        self.reject("context-pins")
        self.assertFalse(self.work.exists())

    def test_28_failed_zip_terminal_is_not_a_success(self):
        actual = s.invoke
        def fail(*args):
            if args[3] == "zip_kit.py":
                raise args[0].Reject("helper-terminal-nonzero")
            return actual(*args)
        with mock.patch.object(s, "invoke", side_effect=fail):
            self.reject("helper-terminal-nonzero")
        self.assertFalse((self.work / "caller-terminal.json").exists())

    def test_29_test_only_notice_digest_cli_accepted_success(self):
        # Exercise main and real isolated helpers with a plainly inert notice.
        harness = ("import types, sys; from pathlib import Path; p = sys.argv.pop(1); "
                   "m = types.ModuleType('fixture_only'); m.__file__ = p; "
                   "exec(compile(Path(p).read_bytes(), p, 'exec'), m.__dict__); "
                   "m.NOTICE_HASH = " + repr(s.NOTICE_HASH) + "; raise SystemExit(m.main())")
        command = [sys.executable, "-I", "-S", "-B"] + (["-O"] if sys.flags.optimize else [])
        command += ["-c", harness, str(HERE / "stage_plan.py")]
        command += [part for key, value in self.args().items() for part in ("--" + key.replace("_", "-"), value)]
        result = subprocess.run(command, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "LOCAL_KIT_BYTES_VERIFIED_ONLY")

    def test_30_real_cli_rejects_inert_notice_digest(self):
        command = [sys.executable, "-I", "-S", "-B", str(HERE / "stage_plan.py")]
        command += [part for key, value in self.args().items() for part in ("--" + key.replace("_", "-"), value)]
        result = subprocess.run(command, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr)["status"], "CALLER_REJECTED")
        self.assertFalse((self.work / "kit.zip").exists())

    def test_31_old_retainer_bytes_rejected_before_output(self):
        old = Path(os.environ["CALLER_TEST_OLD_RETAINER"]).absolute()
        old_raw = old.read_bytes()
        self.assertEqual(hashlib.sha256(old_raw).hexdigest(),
            "9e51a4bc9d8cde8ad52c3f286dfff1f262eeb322d96b10f7f0263fc811c11dd7")
        self.put(self.helpers / "retain.py", old_raw)
        self.reject()
        self.assertFalse(self.work.exists())

    def test_32_superseded_checker_rejected(self):
        self.context["payload_checker_sha256"] = "0637e5016f72cb2f8463cf51fa5d75728ec482aa2ce33153e92bf8be68529b6b"
        self.save_context()
        self.reject("context-pins")
        self.assertFalse(self.work.exists())

    def test_33_legacy_native_report_cannot_substitute(self):
        (self.root / "reduced-payload-123-1.json").unlink()
        self.put(self.root / "native-observation-123-1.json", s.encoded(self.native))
        self.reject()
        self.assertFalse((self.work / "kit.zip").exists())

    def test_34_false_payload_qualification_rejected(self):
        self.checker["legal_clearance"] = True
        self.save_reports()
        self.reject("payload-qualifications")

    def test_35_empty_keeper_rejected(self):
        for view in ("onedir_policy", "zip_policy"):
            self.checker[view]["required_present"][0]["bytes"] = 0
        self.save_reports()
        self.reject("payload-empty-keeper")

    def test_36_policy_join_rejected(self):
        self.checker["zip_policy"]["required_present"][0]["sha256"] = "0" * 64
        self.save_reports()
        self.reject("payload-policy-join")

    def test_37_collect_toc_join_rejected(self):
        self.put(self.build / "pyinstaller/motortester/COLLECT-00.toc", b"changed")
        self.reject("collect-toc-join")

    def test_38_notice_core_original_bytes_and_hash_joins(self):
        # The private byte-only core uses the same explicit fixture-only hash.
        reports = self.root / "notice-reports"
        reports.mkdir()
        self.put(reports / "provenance-123-1.json", s.encoded(self.provenance))
        source = self.root / "fixture-notice.txt"
        self.put(source, self.notice)
        result = s._capture_notice_inputs(self.h, build=str(self.build), reports=str(reports),
            source_notice=str(source), run_id="123", attempt="1", workflow_sha="a" * 40)
        self.assertEqual(result["status"], "PASS")
        for side in ("source", "copy"):
            self.assertEqual((reports / ("native-notice-" + side + "-123-1.bin")).read_bytes(), self.notice)
        self.assertFalse(result["legal_clearance"])

    def test_39_public_notice_wrapper_requires_windows_runtime(self):
        if os.name == "nt":
            self.skipTest("Linux-only negative runtime assertion")
        with self.assertRaisesRegex(self.h.Reject.__bases__[0], "notice-runtime"):
            s.capture_cpython_notices(helper_root=self.helpers, build_root=str(self.build),
                reports_root=str(self.root), run_id="123", attempt="1", workflow_sha="a" * 40)

    def test_40_selector_log_zero_and_actual_subset(self):
        approved = list(POLICY["EXCLUDED_DESTINATIONS"])
        for count in (0, 1, 47):
            raw = ("Windows 10 1809+ x64 runtime selection: " + str(count)
                   + " of 47 approved destinations removed\n"
                   + "".join("  omitted: " + name + "\n" for name in approved[:count])).encode()
            result = s.selection_observation(self.h, raw, approved)
            self.assertEqual(result["actual_removed"], approved[:count])
            self.assertEqual(result["actual_removed_count"], count)
            self.assertEqual(result["build_log"], info(raw))
            self.assertFalse(result["final_absence_used_to_infer_removal"])

    def test_41_selector_log_malformed_or_ambiguous_rejected(self):
        header = b"Windows 10 1809+ x64 runtime selection: 0 of 47 approved destinations removed\n"
        approved = list(POLICY["EXCLUDED_DESTINATIONS"])
        for raw in (b"", header * 2, header.replace(b": 0 ", b": 48 "),
                    header + b"  omitted: unknown.dll\n", header.replace(b": 0 ", b": 1 "),
                    b"  omitted: " + approved[0].encode() + b"\n" + header,
                    header + b"another line\n  omitted: " + approved[0].encode() + b"\n"):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                s.selection_observation(self.h, raw, approved)

    def test_42_build_log_observation_retained_and_hash_bound(self):
        self.call()
        observed = json.loads((self.work / "kit/evidence/runtime-selection.json").read_bytes())
        self.assertEqual(observed["build_log"], info(self.payload["build.log"]))
        self.assertEqual(observed["actual_removed_count"], 0)

    def test_43_payload_report_artifact_join_rejected(self):
        self.save_reports()
        self.checker["actual_candidate_zip"]["sha256"] = "0" * 64
        self.put(self.root / "reduced-payload-123-1.json", s.encoded(self.checker))
        self.reject("payload-build-join")

    def test_44_source_archive_count_old_pin_rejected(self):
        self.archive["source_files"] = 305
        self.save_reports()
        self.reject("original-archive-incomplete")

    def test_45_original_inventory_and_literal_coverage_retained(self):
        self.call()
        root = self.work / "kit/evidence"
        self.assertEqual((root / "license-inventory.json").read_bytes(), self.inventory_raw)
        coverage = json.loads((root / "notice-coverage.json").read_bytes())
        self.assertEqual(coverage["literal_files"], 51)
        self.assertEqual(coverage["literal_bytes"], 176605)
        self.assertEqual(coverage["packaged_dependency_files"], 53)
        self.assertFalse(coverage["legal_clearance"])
        self.assertEqual(coverage["inventory_distributions"], ["pyside6-essentials", "shiboken6"])

    def test_46_changed_literal_body_rejected(self):
        relative = next(name for name in self.dependency_files if name.startswith("notices/"))
        self.put(self.build / "dist/Motortester/licenses/dependency-6.12.0" / relative, b"changed")
        self.reject("input-")

    def test_47_missing_notice_inventory_distribution_rejected(self):
        self.inventory.pop()
        self.update_inventory()
        self.reject("notice-inventory-distributions")

    def update_inventory(self):
        raw = s.encoded(self.inventory)
        self.put(self.build / "dist/Motortester/licenses/inventory.json", raw)
        manifest = json.loads(self.payload[self.h.BUILD_MANIFEST])
        manifest["files"]["licenses/inventory.json"] = info(raw)["sha256"]
        self.payload[self.h.BUILD_MANIFEST] = s.encoded(manifest)
        self.put(self.build / self.h.BUILD_MANIFEST, self.payload[self.h.BUILD_MANIFEST])
        digest = info(self.payload[self.h.BUILD_MANIFEST])["sha256"]
        self.archive["build_manifest_sha256"] = digest
        self.provenance["build_manifest_sha256"] = digest
        self.native["input_hashes"]["manifest"] = digest
        self.save_reports()

    def test_48_inventory_missing_copied_notice_rejected(self):
        self.inventory[0]["copied_notices"].pop()
        self.update_inventory()
        self.reject("notice-copied-membership")

    def test_49_inventory_wrong_literal_hash_rejected(self):
        self.inventory[0]["vendored_notices"][-1]["sha256"] = "0" * 64
        self.update_inventory()
        self.reject("notice-inventory-body-hash")

    def test_50_changed_packaged_dependency_guide_rejected(self):
        self.put(self.build / "dist/Motortester/licenses/dependency-6.12.0/dependency-sources.md", b"wrong")
        self.reject("input-")


if __name__ == "__main__":
    unittest.main(verbosity=2)
