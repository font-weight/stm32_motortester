"""Execute actual generated inline materializer with in-memory HTTPS responses.

No network, archive extraction, native software, Windows or Actions execution.
Archive fixture bytes and their expected hashes exist only in test-owned manifests;
static tests separately bind the production inventory to all five B source pins.
"""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import unittest
from unittest import mock
import urllib.request
import yaml

HERE = Path(__file__).absolute().parent
APP = Path(os.environ["CALLER_TEST_APP_SOURCE"]).absolute()
HELPERS = Path(os.environ["CALLER_TEST_HELPERS"]).absolute()


class Response:
    status = 200
    def __init__(self, data, url, headers):
        self.stream, self.url, self.headers = io.BytesIO(data), url, headers
        self.reads = []
    def geturl(self):
        return self.url
    def read(self, size):
        if not 0 < size <= 1048576:
            raise AssertionError("unbounded response read")
        self.reads.append(size)
        return self.stream.read(size)
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.stream.close()


class MaterializerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="inert-support-", dir=HERE)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.helpers, self.support = self.root / "helpers", self.root / "support"
        self.helpers.mkdir(); self.support.mkdir()
        for name in ("retain.py", "zip_kit.py"):
            (self.helpers / name).write_bytes((HELPERS / name).read_bytes())
        caller = (HERE / "stage_plan.py").read_bytes()
        (self.helpers / "stage_plan.py").write_bytes(caller)
        doc = yaml.load((HERE / "host-windows.local-draft.yml").read_text(), Loader=yaml.BaseLoader)
        job = doc["jobs"]["verify"]
        step = next(row for row in job["steps"] if row.get("id") == "prepare_required_support")
        self.code = re.search(r"\$support = @'\n(.*?)\n'@", step["run"], re.S)[1]
        self.production_rows = json.loads((HERE / "support-manifest.json").read_bytes())
        self.rows, self.data = [], {}
        for row in self.production_rows:
            row = dict(row)
            if row["path"].startswith("sources/"):
                raw = ("INERT NOT AN ARCHIVE " + row["path"] + "\n").encode()
                self.data[row["path"]] = raw
                row.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            self.rows.append(row)
        raw = (json.dumps(self.rows, sort_keys=True, indent=2) + "\n").encode()
        (self.support / "support-manifest.json").write_bytes(raw)
        self.env = {**job["env"], "CALLER_ROOT": str(self.root),
                    "CALLER_FILE_SHA256": hashlib.sha256(caller).hexdigest(),
                    "SUPPORT_MANIFEST_SHA256": hashlib.sha256(raw).hexdigest()}
        self.calls, self.handlers, self.responses = [], [], []
        self.extra, self.wrong, self.no_length = b"", False, False
        self.status, self.encoding, self.response_url = 200, "identity", None
        self.fail_open = False

    def fake_opener(self, *handlers):
        self.handlers.append(handlers[-1])
        parent = self
        class Opener:
            def open(self, request, timeout):
                parent.assertEqual(timeout, 15)
                parent.assertEqual(request.headers["Accept-encoding"], "identity")
                url = request.full_url
                parent.calls.append(url)
                if parent.fail_open:
                    raise OSError("inert download unavailable")
                path = "sources/" + url.rsplit("/", 1)[-1]
                raw = parent.data[path]
                body = (b"X" * len(raw) if parent.wrong else raw) + parent.extra
                headers = {"Content-Encoding": parent.encoding}
                if not parent.no_length:
                    headers["Content-Length"] = str(len(raw))
                response = Response(body, parent.response_url or url, headers)
                response.status = parent.status
                parent.responses.append(response)
                return response
        return Opener()

    def run_code(self):
        cwd = Path.cwd()
        try:
            os.chdir(APP)
            with mock.patch.dict(os.environ, self.env), \
                 mock.patch.object(urllib.request, "build_opener", side_effect=self.fake_opener), \
                 mock.patch.object(socket, "socket", side_effect=AssertionError("network forbidden")), \
                 mock.patch.object(subprocess, "run", side_effect=AssertionError("process forbidden")), \
                 contextlib.redirect_stdout(io.StringIO()):
                exec(compile(self.code, "<generated-support-materializer>", "exec"), {})
        finally:
            os.chdir(cwd)

    def test_01_all_eleven_exact_bodies_streamed_and_guidance_copied(self):
        self.run_code()
        self.assertEqual(len(self.calls), 5)
        for row in self.rows:
            raw = (self.support / row["path"]).read_bytes()
            self.assertEqual(len(raw), row["bytes"])
            self.assertEqual(hashlib.sha256(raw).hexdigest(), row["sha256"])
        self.assertTrue(all(response.reads and response.stream.closed for response in self.responses))
        self.assertFalse((self.root / "kit.zip").exists())

    def test_02_wrong_body_hash_rejected(self):
        self.wrong = True
        with self.assertRaisesRegex(ValueError, "support-download-identity"):
            self.run_code()
        self.assertEqual(len(self.calls), 1)

    def test_03_oversize_response_bounded_and_rejected(self):
        self.extra, self.no_length = b"UNAUTHORIZED EXTRA", True
        with self.assertRaisesRegex(ValueError, "support-response-oversize"):
            self.run_code()
        self.assertEqual(len(self.calls), 1)

    def test_04_content_encoding_rejected(self):
        self.encoding = "gzip"
        with self.assertRaisesRegex(ValueError, "support-content-encoding"):
            self.run_code()
        self.assertEqual(self.responses[0].reads, [])

    def test_05_wrong_status_or_unpinned_final_url_rejected(self):
        self.response_url = "https://unreviewed.example/redirect"
        with self.assertRaisesRegex(ValueError, "support-response"):
            self.run_code()
        self.assertEqual(self.responses[0].reads, [])

    def test_06_existing_body_never_overwritten(self):
        first = next(row for row in self.rows if row["path"].startswith("sources/"))
        path = self.support / first["path"]
        path.parent.mkdir()
        path.write_bytes(b"PRESERVE")
        with self.assertRaisesRegex(ValueError, "case-alias-or-existing-path"):
            self.run_code()
        self.assertEqual(path.read_bytes(), b"PRESERVE")
        self.assertEqual(self.calls, [])

    def test_07_unavailable_download_never_substituted(self):
        self.fail_open = True
        with self.assertRaises(OSError):
            self.run_code()
        self.assertFalse((self.support / "host").exists())

    def test_08_manifest_pin_mismatch_prevents_all_downloads(self):
        self.env["SUPPORT_MANIFEST_SHA256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "support-inventory-pin"):
            self.run_code()
        self.assertEqual(self.calls, [])

    def test_09_old_app_pin_prevents_all_downloads(self):
        self.env["SUPPORT_SOURCE_SHA"] = "244b0786a18fed19a9e708bb815150475ddd193f"
        with self.assertRaisesRegex(ValueError, "support-source-pin"):
            self.run_code()
        self.assertEqual(self.calls, [])

    def test_10_redirect_handler_only_allows_exact_pinned_https_urls(self):
        self.run_code()
        handler = self.handlers[0]
        self.assertEqual(handler.max_redirections, 3)
        self.assertEqual(handler.max_repeats, 1)
        request = urllib.request.Request(handler.allowed[0])
        for url in ("http://" + handler.allowed[1][8:], "https://127.0.0.1/secret",
                    handler.allowed[1] + "?new=1"):
            with self.assertRaisesRegex(ValueError, "support-redirect-not-pinned"):
                handler.redirect_request(request, None, 302, "inert", {}, url)
        self.assertEqual(handler.redirect_request(request, None, 302, "inert", {}, handler.allowed[1]).full_url,
                         handler.allowed[1])

    def test_11_production_inventory_exact_pin_scope_and_caps(self):
        archive_rows = [row for row in self.production_rows if row["path"].startswith("sources/")]
        self.assertEqual(len(archive_rows), 5)
        self.assertEqual(sum(row["bytes"] for row in archive_rows), 81483468)
        self.assertEqual(max(row["bytes"] for row in archive_rows), 51220268)
        self.assertEqual(len(self.production_rows), 11)
        self.assertTrue(all(row["bytes"] <= 64 * 1024 * 1024 for row in self.production_rows))
        self.assertLess(sum(row["bytes"] for row in self.production_rows), 128 * 1024 * 1024)
        for row in self.production_rows:
            if row["path"].startswith("host/"):
                raw = (APP / row["path"]).read_bytes()
                self.assertEqual(len(raw), row["bytes"])
                self.assertEqual(hashlib.sha256(raw).hexdigest(), row["sha256"])

    def test_12_production_downloads_match_B_inventory_and_pinned_manifest_mirrors(self):
        body = (HERE / "SUPPORT_INPUTS_B.md").read_text()
        published = re.findall(r"\| \[([^]]+)\]\((https://[^)]+)\) \| ([0-9]+) \| ([0-9a-f]{64}) \|", body)
        self.assertEqual(len(published), 5)
        by_path = {row["path"]: row for row in self.production_rows}
        for name, url, size, digest in published:
            self.assertEqual(by_path["sources/" + name], {"path": "sources/" + name, "bytes": int(size), "sha256": digest})
            self.assertIn(repr(url), self.code)
        declared = json.loads((APP / "host/packaging/licenses/dependency-6.12.0/manifest.json").read_bytes())
        for row in declared["source_archives"]:
            self.assertIn(repr(row["resolved_url"]), self.code)


if __name__ == "__main__":
    unittest.main(verbosity=2)
