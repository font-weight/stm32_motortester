"""Inert Windows-path contract regression; no Windows or PowerShell execution.

The actual reviewed absolute() is exercised with PureWindowsPath. ntpath models
trusted Join-Path/GetFullPath results. Static checks bind that construction to
the generated PowerShell; they do not claim a Windows runtime test.
"""
import hashlib
import ntpath
import os
from pathlib import Path, PureWindowsPath
import re
import types
import unittest
from unittest import mock

HERE = Path(__file__).absolute().parent
BASELINE = Path(os.environ["CALLER_TEST_BASELINE"]).absolute()
RETAINER = Path(os.environ["CALLER_TEST_HELPERS"]).absolute() / "retain.py"
raw = RETAINER.read_bytes()
if hashlib.sha256(raw).hexdigest() != "3ab02204cf20771c1ff67ca0ec05c8d8c6cb639a93ed56a653ba487fc856b08c":
    raise RuntimeError("retainer bytes changed")
h = types.ModuleType("reviewed_retainer")
h.__file__ = str(RETAINER)
exec(compile(raw, h.__file__, "exec"), h.__dict__)


def generated(temp, mode):
    """Exact trusted path components used by the PowerShell workflow."""
    root = ntpath.abspath(ntpath.join(temp, "first-test-123-1"))
    helper = ntpath.abspath(ntpath.join(root, "helpers"))
    return {
        "callerScript": ntpath.abspath(ntpath.join(helper, "stage_plan.py")),
        "helperRoot": helper,
        "buildRoot": ntpath.abspath(ntpath.join(temp, "motortester-123-1")),
        "reportsRoot": ntpath.abspath(temp),
        "supportRoot": ntpath.abspath(ntpath.join(root, "support")),
        "outputRoot": ntpath.abspath(ntpath.join(root, mode)),
        "workflowRun": ntpath.abspath(ntpath.join(root, "workflow-run-" + mode + ".json")),
    }


class WindowsPathRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.workflow = (HERE / "host-windows.local-draft.yml").read_text()
        cls.original = (BASELINE / "history/r1/host-windows.local-draft.yml").read_text()

    def original_paths(self, mode):
        temp = r"D:\a\_temp"
        root = temp + "/first-test-123-1"
        return [root + "/helpers", temp + "/motortester-123-1", root + "/support",
                root + "/" + mode, root + "/workflow-run-" + mode + ".json"]

    def test_01_reproduce_r1_accepted_mixed_separator_rejection(self):
        self.assertIn('--helper-root "$env:CALLER_ROOT/helpers"', self.original)
        with mock.patch.object(h, "Path", PureWindowsPath):
            for path in self.original_paths("accepted"):
                with self.subTest(path=path), self.assertRaisesRegex(h.Reject, "noncanonical-absolute-path"):
                    h.absolute(path)

    def test_02_reproduce_r1_diagnostics_mixed_separator_rejection(self):
        self.assertIn('--output-root $env:CALLER_DIAGNOSTICS', self.original)
        with mock.patch.object(h, "Path", PureWindowsPath):
            for path in self.original_paths("diagnostics"):
                with self.subTest(path=path), self.assertRaisesRegex(h.Reject, "noncanonical-absolute-path"):
                    h.absolute(path)

    def test_03_constructed_accepted_paths_pass_unchanged_guard(self):
        with mock.patch.object(h, "Path", PureWindowsPath):
            for temp in (r"D:\a\_temp", "D:/a/_temp", r"C:\Users\runner user\AppData\Local\Temp"):
                for key, path in generated(temp, "accepted").items():
                    with self.subTest(root=temp, argument=key):
                        self.assertEqual(str(h.absolute(path)), path)
                        self.assertNotIn("/", path)

    def test_04_constructed_diagnostics_paths_pass_unchanged_guard(self):
        with mock.patch.object(h, "Path", PureWindowsPath):
            for temp in (r"D:\a\_temp", "D:/a/_temp", r"C:\Users\runner user\AppData\Local\Temp"):
                for key, path in generated(temp, "diagnostics").items():
                    with self.subTest(root=temp, argument=key):
                        self.assertEqual(str(h.absolute(path)), path)
                        self.assertNotIn("/", path)

    def step_run(self, ident):
        body = self.workflow.split("        id: " + ident + "\n", 1)[1]
        return body.split("      - name:", 1)[0]

    def test_05_both_branches_construct_every_path_argument_explicitly(self):
        common = (
            "$helperRoot = [IO.Path]::GetFullPath((Join-Path -Path $env:CALLER_ROOT -ChildPath 'helpers'))",
            "$callerScript = [IO.Path]::GetFullPath((Join-Path -Path $helperRoot -ChildPath 'stage_plan.py'))",
            "$buildRoot = [IO.Path]::GetFullPath($env:BUILD_DIR)",
            "$reportsRoot = [IO.Path]::GetFullPath($env:RUNNER_TEMP)",
            "$supportRoot = [IO.Path]::GetFullPath((Join-Path -Path $env:CALLER_ROOT -ChildPath 'support'))",
        )
        for mode, output in (("accepted", "CALLER_OUTPUT"), ("diagnostics", "CALLER_DIAGNOSTICS")):
            code = self.step_run("stage_" + mode)
            for statement in common:
                self.assertIn(statement, code)
            self.assertIn("$outputRoot = [IO.Path]::GetFullPath($env:" + output + ")", code)
            self.assertIn("$workflowRun = [IO.Path]::GetFullPath((Join-Path -Path $env:CALLER_ROOT -ChildPath 'workflow-run-" + mode + ".json'))", code)
            command = next(line for line in code.splitlines() if "python -I -S -B -c $launch" in line)
            for flag, variable in (("helper-root", "helperRoot"), ("build-root", "buildRoot"),
                                   ("reports-root", "reportsRoot"), ("support-root", "supportRoot"),
                                   ("output-root", "outputRoot"), ("workflow-run", "workflowRun")):
                self.assertIn('--' + flag + ' "$' + variable + '"', command)
            self.assertIn('-c $launch "$callerScript"', command)
            self.assertNotIn("$env:CALLER_ROOT/", command)
            self.assertNotIn("--build-root $env:BUILD_DIR", command)

    def test_06_original_temp_env_locations_are_canonicalized(self):
        code = self.workflow.split("      - name: Prepare temporary output location\n", 1)[1].split("      - name:", 1)[0]
        for key, leaf in (
            ("BUILD_DIR", "motortester"), ("INSPECTOR_PATH", "inspector"),
            ("PROVENANCE_PATH", "provenance"), ("PAYLOAD_REPORT", "reduced-payload"),
            ("NOTICE_REPORT", "cpython-notice")):
            self.assertIn('$generatedPath = [IO.Path]::GetFullPath((Join-Path -Path $env:RUNNER_TEMP -ChildPath "' + leaf + '-', code)
            self.assertIn('"' + key + '=$generatedPath"', code)
            self.assertNotIn('"' + key + '=$env:RUNNER_TEMP/', code)
        self.assertIn('$callerRoot = [IO.Path]::GetFullPath((Join-Path -Path $env:RUNNER_TEMP', code)
        for name, parent, child in (("callerOutput", "callerRoot", "accepted"),
                                    ("callerDiagnostics", "callerRoot", "diagnostics"),
                                    ("callerZip", "callerOutput", "kit.zip")):
            self.assertIn('$' + name + " = [IO.Path]::GetFullPath((Join-Path -Path $" + parent + " -ChildPath '" + child + "'))", code)
        self.assertIn('"CALLER_ZIP=$callerZip"', code)

    def test_07_terminal_zip_and_optional_upload_use_canonical_path(self):
        accepted = self.step_run("stage_accepted")
        self.assertIn("$terminalPath = [IO.Path]::GetFullPath((Join-Path -Path $outputRoot -ChildPath 'caller-terminal.json'))", accepted)
        self.assertIn("$zip = Get-Item -LiteralPath $env:CALLER_ZIP", accepted)
        self.assertIn("+          path: ${{ env.CALLER_ZIP }}", (HERE / "host-windows.upload-optional.patch").read_text())

    def test_08_direct_untrusted_path_rejections_are_not_weakened(self):
        bad = (r"D:\a\_temp/mixed", r"D:\a\..\outside", r"D:\a\.\leaf", "D:\\a\\\\leaf",
               r"\\server\share\file", r"\\?\D:\file", "relative", "D:relative", r"D:\a\NUL")
        with mock.patch.object(h, "Path", PureWindowsPath):
            for path in bad:
                with self.subTest(path=path), self.assertRaises(h.Reject):
                    h.absolute(path)

    def test_09_r1_evidence_and_caller_source_remain_frozen(self):
        self.assertEqual(hashlib.sha256((BASELINE / "history/r1/stage_plan.py").read_bytes()).hexdigest(),
                         "6b0cb1e1e1664f435cf5e135ff7e495d29c8d381c8de293185cd336cc81ea3a3")
        self.assertEqual(hashlib.sha256((BASELINE / "stage_plan.py").read_bytes()).hexdigest(),
                         "6b0cb1e1e1664f435cf5e135ff7e495d29c8d381c8de293185cd336cc81ea3a3")
        self.assertEqual(hashlib.sha256((BASELINE / "host-windows.local-draft.yml").read_bytes()).hexdigest(),
                         "37e89527f882382ca2de25afa5b1a15cfadf6fd329d071f7ea11d1073100f968")
        self.assertIn("Ran 29 tests", (BASELINE / "history/r1/tests-normal.log").read_text())
        self.assertEqual(hashlib.sha256((BASELINE / "history/r1/host-windows.local-draft.yml").read_bytes()).hexdigest(),
                         "ca6a445181cc7714ce6a5945037477ca588d69b667c2782b8656cfa8867aca22")


if __name__ == "__main__":
    unittest.main(verbosity=2)
