"""Generate only a local, deliberately disabled draft and reviewable patch."""
import difflib
import hashlib
import os
import re
from pathlib import Path
import types

HERE = Path(__file__).absolute().parent
BASE = Path(os.environ["CALLER_BASE_WORKFLOW"]).absolute()
raw = BASE.read_bytes()
if hashlib.sha256(raw).hexdigest() != "7341772216fa98fc98946e466cf36038a66dfec15977b3118d76e28109a998b6":
    raise SystemExit("baseline changed")
base = raw.decode()
# The literal46 observer is inapplicable to the selected dcaf payload. Preserve
# source/build/archive/inspector checks, and replace only that bounded experiment.
baseline = base
base = base.replace("244b0786a18fed19a9e708bb815150475ddd193f", "dcafc5638bc6c3ddef6cba25a7a55016fe8e8933")
base = base.replace("0c0e61fb8aadd4a4380e2d7e0b8818e4c9da0d5e", "61a9bd025081acec80997dff950d947eeceb3f4b")
def remove_step(text, name):
    start = text.index('      - name: ' + name + '\n')
    end = text.index('      - name:', start + 10)
    return text[:start] + text[end:]
base = remove_step(base, 'Bind separate metadata-only supplement from evaluated workflow')
base = remove_step(base, 'Observe bounded native metadata and original CPython notice')
base = re.sub(r'^.*OBSERVER_FILE_SHA256:.*\n', '', base, flags=re.M)
base = re.sub(r'^.*"OBSERVER_(?:PATH|BASELINE|REPORT)=.*\n', '', base, flags=re.M)
base = base.replace('OBSERVER_WORKFLOW_SHA', 'EVALUATED_WORKFLOW_SHA')
base = base.replace('Preserve bounded supplemental receipt independently', 'Preserve original CPython notice receipt independently')
base = base.replace("'native-observation-'", "'cpython-notice-'").replace("'native-observation.json'", "'cpython-notice.json'")
base = base.replace("os.environ['OBSERVER_REPORT']", "os.environ['NOTICE_REPORT']")
base = base.replace("print('NATIVE_EVIDENCE ", "print('CPYTHON_NOTICE_EVIDENCE ")
# New source pins supplement, rather than replace, unchanged recipe/lock/collector guards.
source_guards = """          $spec = (git rev-parse HEAD:host/packaging/motortester.spec).Trim()
          if ($LASTEXITCODE -ne 0 -or $spec -cne 'a4ef30566e9f6ed8bfad2db322cc8ba7f8bace94') { throw 'Unexpected selected runtime spec' }
          $selector = (git rev-parse HEAD:host/packaging/select_windows_runtime.py).Trim()
          if ($LASTEXITCODE -ne 0 -or $selector -cne '4455b92a3fd1937bbbec94b820640418e13e24c0') { throw 'Unexpected selected runtime policy' }
"""
base = base.replace('          Write-Output "source=$head', source_guards + '          Write-Output "source=$head', 1)
base = base.replace('          sys.exit(bool(mismatches))', "          if checked != 1501:\n              raise RuntimeError('Unexpected dcaf source file count')\n          sys.exit(bool(mismatches))", 1)
stage_raw = (HERE / "stage_plan.py").read_bytes()
stage_hash = hashlib.sha256(stage_raw).hexdigest()
s = types.ModuleType("stage")
s.__file__ = str(HERE / "stage_plan.py")
exec(compile(stage_raw, s.__file__, "exec"), s.__dict__)
support_raw = (HERE / 'support-manifest.json').read_bytes()
support_hash = hashlib.sha256(support_raw).hexdigest()
SUPPORT_DOWNLOADS = (('sources/qtbase-everywhere-src-6.12.0.tar.xz', 'https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtbase-everywhere-src-6.12.0.tar.xz', 'https://mirrors.20i.com/pub/qt.io/archive/qt/6.12/6.12.0/submodules/qtbase-everywhere-src-6.12.0.tar.xz'), ('sources/qtsvg-everywhere-src-6.12.0.tar.xz', 'https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtsvg-everywhere-src-6.12.0.tar.xz', 'https://mirrors.20i.com/pub/qt.io/archive/qt/6.12/6.12.0/submodules/qtsvg-everywhere-src-6.12.0.tar.xz'), ('sources/qtimageformats-everywhere-src-6.12.0.tar.xz', 'https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtimageformats-everywhere-src-6.12.0.tar.xz', 'https://mirrors.20i.com/pub/qt.io/archive/qt/6.12/6.12.0/submodules/qtimageformats-everywhere-src-6.12.0.tar.xz'), ('sources/pyside-setup-everywhere-src-6.12.0.tar.xz', 'https://download.qt.io/official_releases/QtForPython/pyside6/PySide6-6.12.0-src/pyside-setup-everywhere-src-6.12.0.tar.xz', 'https://www.mirrorservice.org/sites/download.qt-project.org/official_releases/QtForPython/pyside6/PySide6-6.12.0-src/pyside-setup-everywhere-src-6.12.0.tar.xz'), ('sources/mesa-11.2.2.tar.xz', 'https://archive.mesa3d.org/older-versions/11.x/11.2.2/mesa-11.2.2.tar.xz', 'https://archive.mesa3d.org/older-versions/11.x/11.2.2/mesa-11.2.2.tar.xz'))

modified = base.replace("    # Standard public-repository runner only. No artifact/cache upload or purchase.",
    "    # LOCAL DRAFT ONLY: disabled until final bindings and independent review.\n"
    "    # No upload in this patch; optional transport patch requires separate approval.")
modified = modified.replace("    if: >-\n      github.repository", "    if: >-\n      false &&\n      github.repository", 1)
modified = modified.replace("      PYTHONNOUSERSITE:", f'''      RETENTION_SHA: '{s.RETENTION_COMMIT}'
      CALLER_FILE_SHA256: '{stage_hash}'
      PAYLOAD_CHECKER_SHA256: '{s.PAYLOAD_CHECKER[1]}'
      # External source-input disposition; does not grant distribution clearance.
      SUPPORT_SOURCE_SHA: '{s.APP_COMMIT}'
      SUPPORT_MANIFEST_GIT_PATH: 'scripts/ci/windows-first-test/support-manifest.json'
      SUPPORT_MANIFEST_SHA256: '{support_hash}'
      SOURCE_NOTICE_REVIEW: 'https://github.com/font-weight/stm32_motortester/issues/33#issuecomment-6233217133'
      PYTHONNOUSERSITE:''', 1)
# Canonicalize only paths constructed by this trusted workflow. Do not loosen
# retainer.absolute() or normalize arbitrary caller CLI inputs.
original_locations = {
    "BUILD_DIR": "motortester-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT",
    "INSPECTOR_PATH": "inspector-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT.py",
    "PROVENANCE_PATH": "provenance-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT.json",
}
for key, leaf in original_locations.items():
    old = f'          "{key}=$env:RUNNER_TEMP/{leaf}" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append\n'
    new = f'          $generatedPath = [IO.Path]::GetFullPath((Join-Path -Path $env:RUNNER_TEMP -ChildPath "{leaf}"))\n'
    new += f'          "{key}=$generatedPath" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append\n'
    if modified.count(old) != 1:
        raise SystemExit("unexpected original temporary path")
    modified = modified.replace(old, new, 1)
prepare = '''          $generatedPath = [IO.Path]::GetFullPath((Join-Path -Path $env:RUNNER_TEMP -ChildPath "reduced-payload-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT.json"))
          "PAYLOAD_REPORT=$generatedPath" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
          $generatedPath = [IO.Path]::GetFullPath((Join-Path -Path $env:RUNNER_TEMP -ChildPath "cpython-notice-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT.json"))
          "NOTICE_REPORT=$generatedPath" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
          $callerRoot = [IO.Path]::GetFullPath((Join-Path -Path $env:RUNNER_TEMP -ChildPath "first-test-$env:GITHUB_RUN_ID-$env:GITHUB_RUN_ATTEMPT"))
          $callerOutput = [IO.Path]::GetFullPath((Join-Path -Path $callerRoot -ChildPath 'accepted'))
          $callerDiagnostics = [IO.Path]::GetFullPath((Join-Path -Path $callerRoot -ChildPath 'diagnostics'))
          $callerZip = [IO.Path]::GetFullPath((Join-Path -Path $callerOutput -ChildPath 'kit.zip'))
          "CALLER_ROOT=$callerRoot" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
          "CALLER_OUTPUT=$callerOutput" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
          "CALLER_DIAGNOSTICS=$callerDiagnostics" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
          "CALLER_ZIP=$callerZip" | Out-File -FilePath $env:GITHUB_ENV -Encoding utf8 -Append
'''
marker = '      - name: Preserve Git blob line endings in hosted checkout\n'
modified = modified.replace(marker, prepare + marker, 1)
ids = {
    "Verify clean source and record provenance": "verify_source",
    "Verify every tracked worktree file against its raw Git blob": "verify_raw_blobs",
    "Bind separate reviewed inspector without changing application": "bind_inspector",
    "Build and exercise unchanged host recipe": "build_candidate",
    "Verify completed archives against source and manifest": "verify_archives",
    "Inspect completed candidate with separate reviewed companion": "inspect_candidate",
    "Preserve original CPython notice receipt independently": "retain_notice_logs",
    "Preserve evidence in job logs only": "retain_job_logs",
    "Preserve original recording receipt independently": "retain_recording_logs",
}
for name, ident in ids.items():
    marker = "      - name: " + name + "\n"
    if modified.count(marker) != 1:
        raise SystemExit("unexpected step inventory")
    modified = modified.replace(marker, marker + "        id: " + ident + "\n")

binder = '''import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import types
root = Path(os.environ['CALLER_ROOT'])
root.mkdir()
helpers, support = root / 'helpers', root / 'support'
helpers.mkdir()
support.mkdir()
# Bounded local Git object reads; fetch itself has a workflow timeout.
def git_bytes(spec, cap):
    process = subprocess.Popen(['git', 'show', spec], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    try:
        raw = process.stdout.read(cap + 1)
        if len(raw) > cap:
            raise ValueError('Git object exceeds bound')
        if process.wait(timeout=30) != 0 or not raw:
            raise ValueError('Missing Git object')
        return raw
    finally:
        process.stdout.close()
        if process.poll() is None:
            process.kill()
            process.wait(timeout=10)
def save(path, raw):
    with path.open('xb') as out:
        out.write(raw)
for name, size, digest in HELPER_PINS:
    raw = git_bytes(os.environ['RETENTION_SHA'] + ':scripts/ci/windows-first-test/' + name, size)
    if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError('Retention helper bytes differ')
    save(helpers / name, raw)
raw = git_bytes(os.environ['EVALUATED_WORKFLOW_SHA'] + ':scripts/ci/windows-first-test/stage_plan.py', CALLER_SIZE)
if len(raw) != CALLER_SIZE or hashlib.sha256(raw).hexdigest() != os.environ['CALLER_FILE_SHA256']:
    raise ValueError('Evaluated caller bytes differ')
save(helpers / 'stage_plan.py', raw)
module = types.ModuleType('_evaluated_caller')
module.__file__ = str(helpers / 'stage_plan.py')
exec(compile(raw, module.__file__, 'exec', dont_inherit=True), module.__dict__)
h = module.helpers(helpers)
# The payload checker also comes from the actual evaluated workflow, with exact
# reviewed source bytes. No cached bytecode loader is used.
raw = git_bytes(os.environ['EVALUATED_WORKFLOW_SHA'] + ':scripts/ci/windows-first-test/check_reduced_payload.py', CHECKER_SIZE)
h.require(len(raw) == CHECKER_SIZE and hashlib.sha256(raw).hexdigest() == os.environ['PAYLOAD_CHECKER_SHA256'], 'payload-checker-pin')
save(helpers / 'check_reduced_payload.py', raw)
manifest = git_bytes(os.environ['EVALUATED_WORKFLOW_SHA'] + ':' + os.environ['SUPPORT_MANIFEST_GIT_PATH'], 65536)
h.require(hashlib.sha256(manifest).hexdigest() == os.environ['SUPPORT_MANIFEST_SHA256'], 'support-inventory-pin')
module.support_inventory(h, manifest)
save(support / 'support-manifest.json', manifest)
# The evaluated workflow itself is retained as original source evidence.
save(root / 'evaluated-workflow.yml', git_bytes(os.environ['EVALUATED_WORKFLOW_SHA'] + ':.github/workflows/host-windows.yml', 131072))
if subprocess.run(['git', 'diff', '--exit-code'], timeout=30, check=False).returncode:
    raise ValueError('Application checkout changed')
'''
binder = binder.replace('HELPER_PINS', repr([(name, *pin) for name, pin in s.HELPERS.items()])).replace('CALLER_SIZE', str(len(stage_raw))).replace('CHECKER_SIZE', str(s.PAYLOAD_CHECKER[0]))
bind_step = '''      - name: Bind reviewed caller helpers and reduced-payload checker
        id: bind_retention_caller
        timeout-minutes: 4
        run: |
          $ErrorActionPreference = 'Stop'
          if ($env:EVALUATED_WORKFLOW_SHA -notmatch '^[0-9a-f]{40}$') { throw 'Evaluated workflow source missing' }
          git fetch --no-tags --depth=1 origin $env:RETENTION_SHA $env:EVALUATED_WORKFLOW_SHA
          if ($LASTEXITCODE -ne 0) { throw 'Retention/evaluated-workflow source fetch failed' }
          $bind = @'
''' + ''.join('          ' + line + '\n' for line in binder.splitlines()) + '''          '@
          python -I -S -B -c $bind
          if ($LASTEXITCODE -ne 0) { throw 'Retention caller binding failed' }
'''
# B's actual inventory and data locations are not frozen. This explicit fail-closed
# placeholder is replaced only after that review. It imposes no Git-blob origin on
# source archive bodies: official URL + exact size/SHA data downloads are allowed.
support_step = '''      - name: Prepare externally reviewed support inventory and exact bodies
        id: prepare_required_support
        timeout-minutes: 5
        run: |
          $ErrorActionPreference = 'Stop'
          throw 'Pending B support manifest, official data locations and external source/notice disposition; materializer is not implemented in this disabled draft'
'''
bind_step += support_step
modified = modified.replace('      - name: Build and exercise unchanged host recipe\n', bind_step + '      - name: Build and exercise unchanged host recipe\n', 1)
modified = modified.replace('          No ZIP artifact retained. Synthetic PNG is encoded in logs only when present and <= 2 MiB.',
    '          This step preserves job-log evidence. The separate retention caller reports any local ZIP result.\n'
    '          Synthetic PNG is encoded in logs only when present and <= 2 MiB.')
modified = modified.replace('          Logs retain build/smoke diagnostics without Actions artifact storage; missing or oversized PNG is explicit.',
    '          This step uses no Actions artifact storage; missing or oversized PNG is explicit.')

# These inline programs load the exact caller bytes before using its bounded IO.
load_caller = s.BOOTSTRAP + """
import os
import sys
import types
from pathlib import Path
helper_root = Path(os.environ['CALLER_ROOT']) / 'helpers'
path = helper_root / 'stage_plan.py'
raw = bound_raw(path, CALLER_SIZE, os.environ['CALLER_FILE_SHA256'])
caller = types.ModuleType('_evaluated_caller')
caller.__file__ = str(path)
exec(compile(raw, str(path), 'exec', dont_inherit=True), caller.__dict__)
""".replace('CALLER_SIZE', str(len(stage_raw)))
# Exact eleven-row accompaniment: five archive bodies, five B guidance files,
# plus the existing appdcaf Windows trial instructions. No extraction/execution.
support_code = load_caller + """
import hashlib
import time
import urllib.error
import urllib.request
SUPPORT_DOWNLOADS = DOWNLOAD_LITERAL
h = caller.helpers(helper_root)
support = h.absolute(Path(os.environ['CALLER_ROOT']) / 'support')
h.require(os.environ['SUPPORT_SOURCE_SHA'] == caller.APP_COMMIT, 'support-source-pin')
reader = h.IO()
reader.read_limit, reader.write_limit = caller.MAX_SUPPORT_TOTAL, caller.MAX_SUPPORT_TOTAL
identity, manifest_raw, _ = reader.read(support / 'support-manifest.json', maximum=65536, collect=True)
h.require(identity['sha256'] == os.environ['SUPPORT_MANIFEST_SHA256'], 'support-inventory-pin')
rows = caller.support_inventory(h, manifest_raw)
by_path = {row['path']: row for row in rows}
h.require(len(rows) == 11 and all(path in by_path for path, _, _ in SUPPORT_DOWNLOADS), 'support-exact-inventory')
# Redirects are bounded and limited to the exact retained mirror URLs declared in
# the pinned source manifest. A changed mirror route needs review, not a bypass.
class ExactRedirect(urllib.request.HTTPRedirectHandler):
    max_redirections, max_repeats = 3, 1
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        h.require(newurl in self.allowed, 'support-redirect-not-pinned')
        return super().redirect_request(req, fp, code, msg, headers, newurl)
deadline = time.monotonic() + 240
for relative, url, resolved in SUPPORT_DOWNLOADS:
    row = by_path[relative]
    h.mkdirs(support, h.relative(relative)[:-1])
    target = support.joinpath(*h.relative(relative))
    h.no_alias(target.parent, target.name, absent=True)
    handler = ExactRedirect()
    handler.allowed = (url, resolved)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), handler)
    h.require(time.monotonic() < deadline, 'support-fetch-timeout')
    request = urllib.request.Request(url, headers={'Accept-Encoding': 'identity'})
    with opener.open(request, timeout=15) as response:
        h.require(response.status == 200 and response.geturl() in handler.allowed, 'support-response')
        length = response.headers.get('Content-Length')
        h.require(length is None or length == str(row['bytes']), 'support-response-length')
        h.require(response.headers.get('Content-Encoding', 'identity') == 'identity', 'support-content-encoding')
        total, digest = 0, hashlib.sha256()
        with target.open('xb') as stream:
            while True:
                h.require(time.monotonic() < deadline, 'support-fetch-timeout')
                block = response.read(min(1048576, row['bytes'] - total + 1))
                if not block:
                    break
                total += len(block)
                h.require(total <= row['bytes'], 'support-response-oversize')
                stream.write(block)
                digest.update(block)
        h.require(total == row['bytes'] and digest.hexdigest() == row['sha256'], 'support-download-identity')
    reader.read(target, {key: row[key] for key in ('bytes', 'sha256')}, 67108864)
# Guidance bytes come from the already clean, raw-Git-verified application tree.
for row in rows:
    if row['path'] in {relative for relative, _, _ in SUPPORT_DOWNLOADS}:
        continue
    h.require(row['path'].startswith('host/'), 'support-guidance-path')
    expected = {key: row[key] for key in ('bytes', 'sha256')}
    source = Path.cwd().joinpath(*h.relative(row['path']))
    reader.read(source, expected, 1048576)
    h.mkdirs(support, h.relative(row['path'])[:-1])
    target = support.joinpath(*h.relative(row['path']))
    h.new_file(target, reader, source=source, expected=expected)
    reader.read(target, expected, 1048576)
print('SUPPORT_EXACT_BYTES_ONLY', len(rows), sum(row['bytes'] for row in rows), identity['sha256'])
""".replace('DOWNLOAD_LITERAL', repr(SUPPORT_DOWNLOADS))
materializer = ("          $ErrorActionPreference = 'Stop'\n          $support = @'\n"
    + ''.join('          ' + line + '\n' for line in support_code.splitlines())
    + "          '@\n          python -I -S -B -c $support\n"
    + "          if ($LASTEXITCODE -ne 0) { throw 'Required source accompaniment is incomplete' }\n")
old = "          $ErrorActionPreference = 'Stop'\n          throw 'Pending B support manifest, official data locations and external source/notice disposition; materializer is not implemented in this disabled draft'\n"
if modified.count(old) != 1:
    raise SystemExit('Unexpected support placeholder')
modified = modified.replace(old, materializer, 1)
payload_code = load_caller + """
h = caller.helpers(helper_root)
reader = h.IO()
build = h.absolute(os.environ['BUILD_DIR'])
manifest_info, _, _ = reader.read(build / h.BUILD_MANIFEST, maximum=4194304)
archive_info, archive_raw, _ = reader.read(build / 'archive-verification.json', maximum=1048576, collect=True)
archive = h.parse_json(archive_raw)
h.require(archive.get('status') == 'PASS' and archive.get('source_sha') == caller.APP_COMMIT
          and archive.get('build_manifest_sha256') == manifest_info['sha256'], 'original-archive-join')
path = helper_root / 'check_reduced_payload.py'
raw = caller.bound_raw(path, *caller.PAYLOAD_CHECKER)
sys.argv = [str(path), '--source-root', str(Path.cwd()), '--build-root', str(build),
            '--expected-manifest-sha256', manifest_info['sha256'],
            '--expected-archive-report-sha256', archive_info['sha256'],
            '--output', os.environ['PAYLOAD_REPORT']]
exec(compile(raw, str(path), 'exec', dont_inherit=True),
     {'__name__': '__main__', '__file__': str(path), '__package__': None})
"""
notice_code = load_caller + """
caller.capture_cpython_notices(helper_root=helper_root, build_root=os.environ['BUILD_DIR'],
    reports_root=str(Path(os.environ['RUNNER_TEMP'])), run_id=os.environ['GITHUB_RUN_ID'],
    attempt=os.environ['GITHUB_RUN_ATTEMPT'], workflow_sha=os.environ['EVALUATED_WORKFLOW_SHA'])
"""
def check_step(name, ident, code):
    return ('      - name: ' + name + '\n        id: ' + ident + '\n        timeout-minutes: 3\n'
            '        run: |\n          $ErrorActionPreference = \'Stop\'\n          $check = @\'\n'
            + ''.join('          ' + line + '\n' for line in code.splitlines())
            + "          '@\n          python -I -S -B -c $check\n"
            + "          if ($LASTEXITCODE -ne 0) { throw '" + ident + " failed; retention cannot be accepted' }\n")
new_checks = check_step('Verify selected payload in final onedir and ZIP', 'verify_reduced_payload', payload_code)
new_checks += check_step('Verify and preserve original CPython notice bytes', 'verify_cpython_notices', notice_code)
modified = modified.replace('      - name: Preserve original CPython notice receipt independently\n',
                            new_checks + '      - name: Preserve original CPython notice receipt independently\n', 1)

# Context is copied from exact GitHub step outcomes, not synthesized PASS files.
context_code = '''import json
import os
from pathlib import Path
steps = json.loads(os.environ['CALLER_STEP_OUTCOMES'])
body = {'schema_version': 1, 'repository': os.environ['GITHUB_REPOSITORY'],
        'run_id': os.environ['GITHUB_RUN_ID'], 'attempt': os.environ['GITHUB_RUN_ATTEMPT'],
        'workflow_sha': os.environ['EVALUATED_WORKFLOW_SHA'], 'application_commit': os.environ['SOURCE_SHA'],
        'application_tree': os.environ['SOURCE_TREE'], 'inspector_commit': os.environ['INSPECTOR_SHA'],
        'inspector_sha256': os.environ['INSPECTOR_FILE_SHA256'],
        'payload_checker_sha256': os.environ['PAYLOAD_CHECKER_SHA256'],
        'source_notice_review': os.environ['SOURCE_NOTICE_REVIEW'],
        'steps': {key: steps[key]['outcome'] for key in REQUIRED_STEPS}}
path = Path(os.environ['CALLER_ROOT']) / CONTEXT_NAME
with path.open('x', encoding='utf-8', newline='\\n') as stream:
    json.dump(body, stream, sort_keys=True, indent=2)
    stream.write('\\n')
'''.replace('REQUIRED_STEPS', repr(s.REQUIRED_STEPS))
launch = s.LAUNCHER


def stage_step(mode):
    accepted = mode == 'accepted'
    name = 'Retain and package exact successful local kit' if accepted else 'Retain explicitly incomplete text diagnostics'
    condition = "success() && steps.bind_retention_caller.outcome == 'success'" if accepted else "always() && steps.bind_retention_caller.outcome == 'success' && steps.stage_accepted.outcome != 'success'"
    context_name = 'workflow-run-' + mode + '.json'
    body = f'''      - name: {name}
        id: stage_{mode}
        if: ${{{{ {condition} }}}}
        timeout-minutes: 8
        env:
          CALLER_STEP_OUTCOMES: ${{{{ toJSON(steps) }}}}
        run: |
          $ErrorActionPreference = 'Stop'
          $context = @'
'''
    code = context_code.replace('CONTEXT_NAME', repr(context_name))
    body += ''.join('          ' + line + '\n' for line in code.splitlines())
    body += '''          '@
          python -I -S -B -c $context
          if ($LASTEXITCODE -ne 0) { throw 'Cannot retain exact original step outcomes' }
          $launch = @'
'''
    body += ''.join('          ' + line + '\n' for line in launch.splitlines())
    body += '''          '@
'''
    output = '$env:CALLER_OUTPUT' if accepted else '$env:CALLER_DIAGNOSTICS'
    body += f'''          # These fixed workflow-generated arguments are canonical Windows paths.
          $helperRoot = [IO.Path]::GetFullPath((Join-Path -Path $env:CALLER_ROOT -ChildPath 'helpers'))
          $callerScript = [IO.Path]::GetFullPath((Join-Path -Path $helperRoot -ChildPath 'stage_plan.py'))
          $buildRoot = [IO.Path]::GetFullPath($env:BUILD_DIR)
          $reportsRoot = [IO.Path]::GetFullPath($env:RUNNER_TEMP)
          $supportRoot = [IO.Path]::GetFullPath((Join-Path -Path $env:CALLER_ROOT -ChildPath 'support'))
          $outputRoot = [IO.Path]::GetFullPath({output})
          $workflowRun = [IO.Path]::GetFullPath((Join-Path -Path $env:CALLER_ROOT -ChildPath '{context_name}'))
          python -I -S -B -c $launch "$callerScript" '{len(stage_raw)}' $env:CALLER_FILE_SHA256 --helper-root "$helperRoot" --build-root "$buildRoot" --reports-root "$reportsRoot" --support-root "$supportRoot" --output-root "$outputRoot" --workflow-run "$workflowRun" --mode {mode} --support-manifest-sha256 $env:SUPPORT_MANIFEST_SHA256 --source-notice-review $env:SOURCE_NOTICE_REVIEW
'''
    if accepted:
        body += '''          if ($LASTEXITCODE -ne 0) { throw 'Local retention/package incomplete; do not consume partial output' }
          $terminalPath = [IO.Path]::GetFullPath((Join-Path -Path $outputRoot -ChildPath 'caller-terminal.json'))
          if ((Get-Item -LiteralPath $terminalPath).Length -gt 65536) { throw 'Caller terminal exceeds bound' }
          $terminal = Get-Content -LiteralPath $terminalPath -Raw -Encoding utf8 | ConvertFrom-Json
          if ($terminal.status -cne 'LOCAL_KIT_BYTES_VERIFIED_ONLY' -or $terminal.mode -cne 'accepted' -or $terminal.retention_exit_code -ne 0 -or $terminal.zip_exit_code -ne 0) { throw 'Missing successful terminal result' }
          $zip = Get-Item -LiteralPath $env:CALLER_ZIP
          if ($zip.Length -ne $terminal.zip.bytes -or $zip.Length -gt 538968064 -or (Get-FileHash -LiteralPath $zip.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -cne $terminal.zip.sha256) { throw 'Terminal ZIP identity mismatch' }
          "Local kit bytes verified. SHA-256: $($terminal.zip.sha256). No upload/download performed; Windows 10, hardware and distribution acceptance remain separate." | Add-Content -Encoding utf8 $env:GITHUB_STEP_SUMMARY
'''
    else:
        body += '''          $diagnosticExit = $LASTEXITCODE
          # Diagnostics deliberately exits 1 even when its bounded ZIP succeeded.
          Write-Output "Diagnostic caller terminal exit: $diagnosticExit; original failure is preserved."
          throw 'INCOMPLETE_DIAGNOSTICS_ONLY; never promote diagnostic retention to build success'
'''
    return body

modified += stage_step('accepted') + stage_step('diagnostics')
(HERE / 'host-windows.local-draft.yml').write_text(modified)
patch = ''.join(difflib.unified_diff(baseline.splitlines(True), modified.splitlines(True),
                                  fromfile='a/.github/workflows/host-windows.yml',
                                  tofile='b/.github/workflows/host-windows.yml'))
(HERE / 'host-windows.local-draft.patch').write_text(patch)
# Deliberately separate transport patch; no execution or owner permission inferred.
upload = '''      - name: Publish one approved kit ZIP for one day
        if: ${{ success() && steps.stage_accepted.outcome == 'success' && env.PUBLIC_BINARY_UPLOAD_AUTHORIZED == 'true' }}
        uses: actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9 # v7; separately approved transport
        with:
          name: windows-first-test-${{ github.run_id }}-${{ github.run_attempt }}
          path: ${{ env.CALLER_ZIP }}
          archive: true
          retention-days: 1
          overwrite: false
          include-hidden-files: false
          if-no-files-found: error
'''
upload_version = modified.replace("      RETENTION_SHA:", "      PUBLIC_BINARY_UPLOAD_AUTHORIZED: 'false' # Change only after explicit owner approval.\n      RETENTION_SHA:", 1)
upload_version += upload
(HERE / 'host-windows.upload-optional.patch').write_text(''.join(difflib.unified_diff(modified.splitlines(True), upload_version.splitlines(True),
    fromfile='a/.github/workflows/host-windows.yml', tofile='b/.github/workflows/host-windows.yml')))
print('Generated disabled local draft; caller', len(stage_raw), stage_hash)
