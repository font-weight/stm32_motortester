# Original caller/checker review evidence

For PR181 d9c02be6de80aee4e8eb0550a417e489be11d662. Source/inert evidence only; not a Windows application or a physical-test kit. Original test bodies/results are included without regenerating successful outputs. MANIFEST.json hashes all inputs. Use Python3 with PyYAML and the patch utility. No native app execution is authorized or performed by these fixtures. The partial appdcaf host export is the exact source closure needed by these tests, not a full Git checkout or a new host implementation.

From the extracted root (shell):

    export CALLER_BASE_WORKFLOW="$PWD/inputs/original-workflow.yml"
    export CALLER_TEST_HELPERS="$PWD/retention-dcaf/scripts/ci/windows-first-test"
    export CALLER_TEST_APP_SOURCE="$PWD/reduced-consumer-review/appdcaf"
    export CALLER_TEST_BASELINE="$PWD/workflow-caller"
    export CALLER_TEST_OLD_RETAINER="$PWD/retention-candidate/scripts/ci/windows-first-test/retain.py"
    export CALLER_TEST_CHECKER="$PWD/payload-checker/check_reduced_payload.py"
    cd workflow-caller-dcaf
    python3 -B test_stage_plan.py
    python3 -B test_windows_paths.py
    python3 -B test_workflow_static.py
    python3 -B test_support_materializer.py

Repeat each with -O -B. Then cd ../payload-checker and run python3 -B test_check_reduced_payload.py and python3 -O -B test_check_reduced_payload.py. The historical notice files match the production notice hash but do not prove a fresh Windows run. Tests use inert payloads; historical author notice mocks are explicitly disclosed. Final independent report includes the added genuine-notice CLI positive/control cases.
