"""Inert fixtures only: no executable, DLL, PYZ or package module is run."""
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

HERE = Path(__file__).absolute().parent
sys.path.insert(0, str(HERE))
import check_reduced_payload as c

SOURCE = HERE.parent / 'reduced-consumer-review/appdcaf'
POLICY, _ = c.bind_policy(SOURCE, c.Reads())


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


class Fixture:
    def __init__(self, root):
        self.root, self.source, self.build = root, root / 'source', root / 'build'
        self.source.mkdir(); self.build.mkdir()
        for name in c.SOURCE_PINS:
            target = self.source / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / name, target)
        self.bundle = self.build / 'dist/Motortester'
        self.bundle.mkdir(parents=True)
        self.files = {'Motortester.exe': b'INERT executable placeholder; not executable',
                      'licenses/notice.txt': b'Inert fixture notice'}
        self.files.update({'_internal/' + name: ('INERT ' + name).encode()
                           for name in POLICY['REQUIRED_DESTINATIONS']})
        self.rebuild()

    def rebuild(self, zip_extra=(), zip_missing=(), zip_override=None):
        shutil.rmtree(self.bundle)
        self.bundle.mkdir(parents=True)
        for name, raw in self.files.items():
            target = self.bundle / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        manifest = {'source_commit': c.APP_COMMIT, 'status': 'candidate-not-release-approved',
                    'usb_verified': False, 'files': {name: c.digest(raw) for name, raw in self.files.items()}}
        self.manifest_raw = encoded(manifest)
        (self.bundle / c.MANIFEST).write_bytes(self.manifest_raw)
        with zipfile.ZipFile(self.build / c.CANDIDATE, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('Motortester/', b'')
            for directory in sorted(p for p in self.bundle.rglob('*') if p.is_dir()):
                archive.writestr('Motortester/' + directory.relative_to(self.bundle).as_posix() + '/', b'')
            for name, raw in {**self.files, c.MANIFEST: self.manifest_raw}.items():
                if name not in zip_missing:
                    archive.writestr('Motortester/' + name, (zip_override or {}).get(name, raw))
            for name, raw in zip_extra:
                archive.writestr(name, raw)
        for name in c.FIXED_ARTIFACTS - {c.CANDIDATE}:
            (self.build / name).write_bytes(b'INERT ' + name.encode())
        work = self.build / 'frozen-recording.json.work'
        work.mkdir(exist_ok=True)
        (work / 'recording.mtrec').write_bytes(b'INERT recording')
        (work / 'capture.mtspool').write_bytes(b'INERT spool')
        self.refresh_report()

    def refresh_report(self):
        names = c.FIXED_ARTIFACTS | {'frozen-recording.json.work/recording.mtrec',
                                   'frozen-recording.json.work/capture.mtspool'}
        raw = {name: (self.build / name).read_bytes() for name in names}
        hashes = {name: c.digest(data) for name, data in raw.items()}
        sums = ''.join(f'{hashes[name]}  {name}\n' for name in sorted(names)).encode('ascii')
        (self.build / 'SHA256SUMS.txt').write_bytes(sums)
        self.archive = {'status': 'PASS', 'scope': 'on-runner-archive-content-only', 'source_sha': c.APP_COMMIT,
                        'source_files': 306, 'binary_files': len(self.files), 'recording_required': True,
                        'recording_source_zip_hashes_verified': 23, 'hardware_verified': False,
                        'bytes_delivered': False, 'artifacts_sha256': hashes,
                        'artifact_bytes': {name: len(data) for name, data in raw.items()},
                        'checksum_file_sha256': c.digest(sums), 'build_manifest_sha256': c.digest(self.manifest_raw)}
        self.save_report()

    def save_report(self):
        self.archive_raw = encoded(self.archive)
        (self.build / 'archive-verification.json').write_bytes(self.archive_raw)

    def verify(self):
        return c.verify(self.source, self.build, c.digest(self.manifest_raw), c.digest(self.archive_raw))


class CheckerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='inert-', dir=HERE)
        self.addCleanup(self.temp.cleanup)
        self.f = Fixture(Path(self.temp.name))

    def reject(self, code=None):
        return self.assertRaisesRegex(c.Invalid, '^' + code + '$') if code else self.assertRaises(c.Invalid)

    def test_inert_pass_exact_observations_and_false_claims(self):
        result = self.f.verify()
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['application_commit'], c.APP_COMMIT)
        for key in ('onedir_policy', 'zip_policy'):
            self.assertEqual(result[key]['excluded_absent_count'], 47)
            self.assertEqual(result[key]['required_present_count'], 7)
        for key in ('authenticated_origins', 'tls_capability_verified', 'hardware_verified',
                    'physical_stop_verified', 'native_code_executed', 'candidate_python_executed',
                    'windows_10_verified', 'legal_clearance', 'source_tree_verified_by_this_checker', 'payload_modified'):
            self.assertIs(result[key], False)
        raw = (self.f.build / c.CANDIDATE).read_bytes()
        self.assertEqual(result['actual_candidate_zip'], {'bytes': len(raw), 'sha256': c.digest(raw)})
        rows = result['actual_onedir']['files']
        self.assertEqual(len(rows), len(self.f.files) + 1)
        canonical = json.dumps(rows, ensure_ascii=True, separators=(',', ':'), sort_keys=True).encode('ascii')
        self.assertEqual(result['actual_onedir']['file_inventory_sha256'], c.digest(canonical))
        self.assertFalse(list(self.f.root.rglob('*.pyc')))

    def test_every_exclusion_canonical_case_alias_and_relocated_rejected(self):
        original = set(self.f.files)
        for name in POLICY['EXCLUDED_DESTINATIONS']:
            for spelling in ('_internal/' + name, '_INTERNAL/' + name.upper(),
                             'elsewhere/' + name.rsplit('/', 1)[-1]):
                with self.subTest(spelling=spelling), self.reject('excluded_or_related_destination'):
                    c.check_policy(original | {spelling}, set(), POLICY)
        # Full manifest/ZIP-consistent payload still fails when prohibited bytes remain.
        self.f.files['_internal/ucrtbase.dll'] = b'INERT excluded'
        self.f.rebuild()
        with self.reject('excluded_or_related_destination'):
            self.f.verify()

    def test_related_variants_rejected_unrelated_accepted(self):
        for basename in ('api-ms-win-core-future.dll', 'api-ms-win-crt-future.dll', 'ucrtbased.dll',
                         'qopensslbackendd.dll', 'libcrypto-4-x64.dll', 'libssl-4-x64-debug.dll'):
            for prefix in ('_internal/', 'elsewhere/'):
                with self.subTest(name=prefix + basename), self.reject('excluded_or_related_destination'):
                    c.check_policy(set(self.f.files) | {prefix + basename}, set(), POLICY)
        for name in ('api-ms-win-security-base-l1-1-0.dll', 'my-ucrtbase.dll', 'libcrypto-4.dll'):
            c.check_policy(set(self.f.files) | {'_internal/' + name}, set(), POLICY)

    def test_each_keeper_required_as_file(self):
        for name in POLICY['REQUIRED_DESTINATIONS']:
            path = '_internal/' + name
            with self.subTest(name=name), self.reject('missing_keeper'):
                c.check_policy(set(self.f.files) - {path}, {path}, POLICY)
        del self.f.files['_internal/_ssl.pyd']
        self.f.rebuild()
        with self.reject('missing_keeper'):
            self.f.verify()

    def test_selector_and_spec_pins(self):
        for name in c.SOURCE_PINS:
            target = self.f.source / name
            raw = target.read_bytes()
            target.write_bytes(raw[:-1] + b'!')
            with self.subTest(name=name), self.reject('source_pin'):
                self.f.verify()
            target.write_bytes(raw)

    def test_candidate_module_and_pyc_never_imported(self):
        self.f.files['_internal/danger.py'] = b'raise RuntimeError("MUST NEVER EXECUTE")'
        self.f.files['_internal/__pycache__/danger.cpython-313.pyc'] = b'INVALID PYC; never imported'
        self.f.rebuild()
        with patch('subprocess.Popen', side_effect=AssertionError('No child execution')):
            self.f.verify()

    def test_directory_bytes_inventory_and_manifest_anchor(self):
        (self.f.bundle / 'Motortester.exe').write_bytes(b'changed')
        with self.reject('directory_hash'):
            self.f.verify()
        self.f.rebuild()
        (self.f.bundle / 'extra.txt').write_bytes(b'new')
        with self.reject('directory_inventory'):
            self.f.verify()
        self.f.rebuild()
        with self.reject('manifest_join'):
            c.verify(self.f.source, self.f.build, '0' * 64, c.digest(self.f.archive_raw))

    def test_archive_pass_and_exact_join_are_required(self):
        with self.reject('archive_report_pin'):
            c.verify(self.f.source, self.f.build, c.digest(self.f.manifest_raw), '0' * 64)
        for key, value in (('status', 'RUNNING'), ('source_sha', '0' * 40), ('source_files', True),
                           ('recording_required', False), ('recording_source_zip_hashes_verified', 22),
                           ('hardware_verified', True), ('scope', 'other')):
            original = self.f.archive[key]
            self.f.archive[key] = value
            self.f.save_report()
            with self.subTest(key=key), self.reject('archive_report_contract'):
                self.f.verify()
            self.f.archive[key] = original
        self.f.save_report()
        (self.f.build / 'source.zip').write_bytes(b'CHANGED source zip')
        with self.reject('archive_artifact_join'):
            self.f.verify()

    def test_zip_only_missing_changed_extra_and_duplicate(self):
        cases = ({'zip_missing': ['_internal/_ssl.pyd']},
                 {'zip_override': {'_internal/_ssl.pyd': b'changed'}},
                 {'zip_extra': [('Motortester/extra.txt', b'extra')]})
        for kwargs in cases:
            self.f.rebuild(**kwargs)
            with self.subTest(kwargs=kwargs), self.reject('zip_directory_join'):
                self.f.verify()
        with contextlib.redirect_stderr(io.StringIO()):
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                self.f.rebuild(zip_extra=[('Motortester/Motortester.exe', b'duplicate')])
        with self.reject('duplicate_name'):
            self.f.verify()

    def test_zip_unsafe_paths_aliases_and_types(self):
        names = ('Motortester/../bad', 'Motortester//bad', '/Motortester/bad', 'Motortester/C:bad',
                 'Motortester/x\\bad', 'Motortester/CON.txt', 'Motortester/dir./bad',
                 'Motortester/a ', 'Motortester/a\x7fb', 'Other/file',
                 'Motortester/_INTERNAL/new.txt', 'Motortester/Motortester.exe/child')
        for name in names:
            with self.subTest(name=name):
                self.f.rebuild(zip_extra=[(name, b'inert')])
                with self.reject():
                    self.f.verify()
        for mode in (stat.S_IFLNK | 0o777, stat.S_IFIFO | 0o600, stat.S_IFCHR | 0o600):
            zi = zipfile.ZipInfo('Motortester/unsafe')
            zi.create_system, zi.external_attr = 3, mode << 16
            self.f.rebuild(zip_extra=[(zi, b'target')])
            with self.subTest(mode=mode), self.reject('zip_entry_type'):
                self.f.verify()
        zi = zipfile.ZipInfo('Motortester/reparse')
        zi.external_attr = 0x400
        self.f.rebuild(zip_extra=[(zi, b'inert')])
        with self.reject('zip_entry_type'):
            self.f.verify()

    def test_zip_nul_encryption_and_bounds(self):
        self.f.rebuild(zip_extra=[('Motortester/extraX', b'inert')])
        raw = (self.f.build / c.CANDIDATE).read_bytes()
        with self.reject('zip_name_or_encryption'):
            c.zip_inventory(raw.replace(b'Motortester/extraX', b'Motortester/extra\x00'))
        changed = bytearray(raw)
        at = changed.find(b'PK\x01\x02')
        struct.pack_into('<H', changed, at + 8, struct.unpack_from('<H', changed, at + 8)[0] | 1)
        with self.reject('zip_name_or_encryption'):
            c.zip_inventory(changed)
        with patch.object(c, 'MAX_FILE', 1), self.reject('zip_member_limit'):
            c.zip_inventory(raw)
        with patch.object(c, 'MAX_TOTAL', 1), self.reject('zip_total_limit'):
            c.zip_inventory(raw)
        with patch.object(c, 'MAX_ENTRIES', 1), self.reject('zip_bounds'):
            c.zip_inventory(raw)

    def test_directory_budget_and_read_limit(self):
        with patch.object(c, 'MAX_ENTRIES', 1), self.reject('entry_limit'):
            c.directory_inventory(self.f.bundle)
        with patch.object(c, 'MAX_FILES', 1), self.reject('file_count'):
            c.directory_inventory(self.f.bundle)
        with patch.object(c, 'MAX_READ', 1), self.reject('read_budget'):
            self.f.verify()

    def test_cli_success_writes_report_only(self):
        output = self.f.root / 'result.json'
        before = {str(p): c.digest(p.read_bytes()) for p in self.f.root.rglob('*') if p.is_file()}
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            status = c.main(['--source-root', str(self.f.source), '--build-root', str(self.f.build),
                             '--expected-manifest-sha256', c.digest(self.f.manifest_raw),
                             '--expected-archive-report-sha256', c.digest(self.f.archive_raw), '--output', str(output)])
        self.assertEqual(status, 0)
        self.assertEqual(json.loads(output.read_text())['status'], 'PASS')
        after = {str(p): c.digest(p.read_bytes()) for p in self.f.root.rglob('*') if p.is_file() and p != output}
        self.assertEqual(before, after)

    def test_zip_metadata_limits_and_unsupported_formats(self):
        raw = (self.f.build / c.CANDIDATE).read_bytes()
        end = raw.rfind(b'PK\x05\x06')
        for offset, fmt, value in ((4, '<H', 1), (8, '<H', 65535), (10, '<H', 65535),
                                    (12, '<I', c.MAX_META + 1), (16, '<I', 0)):
            changed = bytearray(raw)
            struct.pack_into(fmt, changed, end + offset, value)
            with self.subTest(offset=offset), self.reject('zip_bounds'):
                c.zip_inventory(changed)
        with self.reject('zip_bounds'):
            c.zip_inventory(raw + b'trailing')
        with self.reject('zip_end'):
            c.zip_inventory(b'not a ZIP')

    def test_no_symlinks_hardlinks_or_reparse_points(self):
        target = self.f.bundle / 'licenses/notice.txt'
        original = target.read_bytes()
        outside = self.f.root / 'outside'
        outside.write_bytes(original)
        target.unlink()
        try:
            target.symlink_to(outside)
        except (OSError, NotImplementedError):
            self.skipTest('Symlink creation unavailable')
        with self.reject('redirected_path'):
            self.f.verify()
        target.unlink(); os.link(outside, target)
        with self.reject('file_type_or_limit'):
            self.f.verify()
        target.unlink(); target.write_bytes(original)
        info = target.stat()
        from types import SimpleNamespace
        fake = SimpleNamespace(st_mode=info.st_mode, st_file_attributes=0x400)
        with patch.object(Path, 'lstat', return_value=fake), self.reject('redirected_path'):
            c.no_redirect(target)

    def test_duplicate_json_complexity_and_nonfinite_rejected(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'[' * 17 + b']' * 17,
                    b'"' + b'a' * (c.MAX_NAME * 12 + 1) + b'"'):
            with self.subTest(prefix=raw[:20]), self.reject():
                c.decode(raw)

    def test_path_bounds_and_component_aliases(self):
        for name in ('a/' * 17 + 'b', 'x' * 1025, 'LPT².txt', 'CONOUT$.dll', 'dir/NUL .txt'):
            with self.subTest(name=name), self.reject():
                c.relative(name)
        names = c.Names(); names.add('Foo/a.txt', False)
        with self.reject('case_alias'):
            names.add('foo/b.txt', False)

    def test_output_separation_and_no_overwrite(self):
        report = self.f.verify()
        with self.reject('output_overlaps_inputs'):
            c.write_report(self.f.bundle / 'result.json', report, self.f.source, self.f.build)
        with self.reject('output_overlaps_inputs'):
            c.write_report(self.f.source / 'result.json', report, self.f.source, self.f.build)
        output = self.f.root / 'result.json'
        c.write_report(output, report, self.f.source, self.f.build)
        with self.assertRaises(FileExistsError):
            c.write_report(output, report, self.f.source, self.f.build)

    def test_cli_failure_sanitized_and_no_report(self):
        output = self.f.root / 'result.json'
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            result = c.main(['--source-root', str(self.f.source), '--build-root', str(self.f.build),
                             '--expected-manifest-sha256', '0' * 64, '--expected-archive-report-sha256',
                             c.digest(self.f.archive_raw), '--output', str(output)])
        self.assertEqual(result, 1)
        self.assertEqual(stderr.getvalue(), 'REDUCED_PAYLOAD_FAILED code=manifest_join\n')
        self.assertFalse(output.exists())

    def test_input_change_detected_before_final_report(self):
        reads = c.Reads()
        target = self.f.root / 'input'
        target.write_bytes(b'original')
        reads.read(target, 64)
        target.write_bytes(b'changed!')
        with self.reject('changed_final'):
            reads.unchanged()


if __name__ == '__main__':
    unittest.main()
