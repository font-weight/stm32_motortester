# Final reduced-payload check (local draft)

A-owned, standard-library-only supplement for application
`dcafc5638bc6c3ddef6cba25a7a55016fe8e8933`, expected tree
`61a9bd025081acec80997dff950d947eeceb3f4b`. No host source, workflow,
retention helper, package or remote state is changed by this draft.

## Run after the existing successful archive validator

Use the trusted build interpreter, isolated from the candidate. The workflow
must bind this checker's exact reviewed bytes, verify the clean application
commit/tree/raw Git blobs separately, and require the existing archive and
provenance validators. Obtain the expected manifest/report hashes from those
already validated inputs in the same guarded run; they are required anchors,
not authentication of an arbitrary supplied report.

```text
python -I -S -B check_reduced_payload.py \
  --source-root /path/to/pinned/checkout \
  --build-root /path/to/completed/build \
  --expected-manifest-sha256 <validated-build-manifest-sha256> \
  --expected-archive-report-sha256 <successful-archive-verification-json-sha256> \
  --output /separate/existing-directory/reduced-payload.json
```

The output parent must already exist; output must be new and outside both input
roots. Run after frozen smokes and archive/provenance checks, before retention.
Do not trim or modify any payload after successful smokes. Add the new report to
the explicit retention inventory; do not replace the original eight checksum
payloads, manifest, original receipts or unrelated strict gates. This check does
not implement a PyInstaller/CArchive/PYZ decoder. Keep that existing validation.
The separate historical fixed46 origin observer is not an applicable gate for
this reduced payload; the workflow must explicitly omit or replace that experiment.

## What is checked and reported

- Hashes the actual 5,686-byte selector and 1,867-byte spec against their exact
  pinned SHA-256 values. Executes only the hash-bound pure selector source bytes
  in memory, without imports or PYC resolution; the spec is only hashed.
- Uses its 47 exclusions, seven keepers and related-family rejection policy.
  Checks all final onedir and ZIP destinations, including case aliases and
  alternate directories. A keeper must be an actual nonempty ordinary file under `_internal`; each
  keeper observation includes its measured byte length and SHA-256.
- Requires the existing archive receipt's PASS, expected source, 306 source
  bodies and 23 recording-source checks. Joins its exact eight artifact hashes
  and lengths, checksum-file hash, actual checksum entries and manifest hash.
- Independently reads every onedir file and every candidate ZIP file. Requires
  identical file names, byte lengths and SHA-256 values, exact manifest file
  coverage, identical manifest bytes, and identical explicit directory sets.
- Rejects unsafe Windows names, duplicate/case-alias destinations, implicit
  file/directory collisions, symlinks, hardlinks, reparse paths, unsupported ZIP
  entry types, encryption, unsupported compression, ZIP64/multi-disk archives
  and oversized names/counts/metadata/members/totals. No extraction occurs.
- Rechecks input fingerprints/inventory and rehashes candidate/manifest/report
  anchors before returning. Limits include 200 MiB candidate ZIP, 20 MiB source
  ZIP, 256 MiB/file, 1 GiB payload, 4,096 files and 8,192 entries. Reads are bounded;
  the candidate ZIP is retained in memory up to its fixed cap.
- Emits actual checker/spec/selector/source-ZIP/candidate-ZIP/manifest/receipt/
  checksum hashes, all actual file lengths/hashes, and 47 absent / seven present
  observations for both views. The directory hash is explicitly a canonical
  file-inventory digest, not a filesystem or ZIP serialization hash.

Absence is not an observed removal count: the Analysis selection may remove
0–47 items. Preserve the actual selector logs separately. This report does not
invent native origins or TLS support. Origin authentication, hardware/Stop,
Windows 10 operation, legal clearance and delivery flags remain false. The
expected commit/tree are labelled external bindings, not locally attested Git
identities. Frozen execution, full source-ZIP/Git correspondence and original
recording-receipt semantics remain the existing validators' responsibility.
Stable input fingerprints detect ordinary mutation; this is not a sandbox
against a privileged concurrent writer.

## Inert tests and current status

```text
python -I -S -B test_check_reduced_payload.py -v
python -I -S -B -O test_check_reduced_payload.py -v
```

24 methods pass in both modes on local Linux CPython 3.12.14 (zero skips/failures).
Tests copy only the two pinned source inputs from the adjacent
`reduced-consumer-review/appdcaf` tree and create/remove tiny fixtures beneath this
directory. Fake `.exe`, DLL, PYZ-related and receipt bytes are inert; successful
fixture reports are not real archive-validation or Windows evidence. Windows
reparse rejection is structurally simulated locally, not a native Windows test.
No new Windows candidate exists in this task; no actual package success report,
hosted build, upload, release or distribution approval is claimed.

## Revision after independent review

V1 and its original author/independent logs are preserved under `history/v1/`.
Independent review found two real false-pass cases: a consistently empty keeper
and member-level ZIP64 metadata despite an ordinary EOCD. V2 rejects each of the
seven empty keepers, checks both central and bounded local ZIP member metadata
(including ZIP64 extras, extraction versions and size sentinels), and retains
the original exclusion/keeper contract. Central-only, local-only and spoofed
ordinary-version ZIP64 forms are regression-tested. No host code or external
contract was changed to accommodate either defect. The new independent verdict
is required before workflow integration.
