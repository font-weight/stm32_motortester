# Independent review: reduced-payload checker v1

Review date: 2026-10-17. Reviewer: the independently assigned A-side checker reviewer, not its author. This review changed no implementation, `host/**`, workflow, remote state, package or physical device. All review writes and inert fixture execution are confined to `payload-checker-review/`, apart from author tests' documented temporary fixture directory.

## Verdict

**REWORK, 8.025/10.** One P1 contract violation and one P2 unsupported-format/documentation mismatch remain in the exact v1 bytes. No release, Windows, TLS, origin, hardware, physical Stop, legal or delivery acceptance is given.

- **P1: all seven zero-byte required keepers are accepted.** The established consumer predicate requires nonempty ordinary files. Rebuilding each fixture's manifest, onedir, candidate ZIP and receipt consistently with one keeper emptied still returns `status: PASS` and `required_present_count: 7`.
- **P2: ZIP64 members are accepted despite the documented rejection.** Both a real `force_zip64=True` local-header fixture and a central-only ZIP64-size fixture return PASS. This does not demonstrate an unbounded allocation: parsed size limits still apply. It is a concrete mismatch with the checker’s advertised supported archive envelope.

Author suite: 20/20 methods pass in both normal and optimized Python. Independent suite: 14 methods run in each mode; nine rejection expectations fail, comprising seven isolated empty-keeper subcases and two ZIP64 forms. All other independent methods pass. Passing author tests therefore do not establish the required negative behavior.

## Exact reviewed state

These are local uncommitted draft artifacts; there is no checker commit SHA. SHA-256 identifies the exact reviewed bytes, preserved in `reviewed-inputs/`:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| check_reduced_payload.py | 21897 | 0637e5016f72cb2f8463cf51fa5d75728ec482aa2ce33153e92bf8be68529b6b |
| test_check_reduced_payload.py | 18311 | 92ca42a2ccb39e703c0505287dc941e75bba2c4422f21aa634fcb7079cc2f486 |
| README.md | 5091 | 47b9a55650d5fcfc89e661472157008949ae2483e2977ec5d08fcb053f29d012 |

Application contract: PR179, head `dcafc5638bc6c3ddef6cba25a7a55016fe8e8933`, tree `61a9bd025081acec80997dff950d947eeceb3f4b`, parent `244b0786a18fed19a9e708bb815150475ddd193f`. This review uses the retained `CONSUMER_DELTA_REVIEW.md`, `PAYLOAD_PREDICATE.json`, exact selector/spec source and current archive-validator snapshot. It does not reassert a fresh remote checkout or reconstruct the full source tree.

Both exact build inputs are correctly pinned:

- Selector: 5686 bytes, SHA-256 `f4144a5318f4607a207531559c03365d2351473b40b5431ddfb4f7c3d381712b`.
- Spec: 1867 bytes, SHA-256 `b754e84f96be7c8d8c8284a29457c83567f02c53344a99235857a60386d3e492`.

Detailed review/input/log identities are recorded in `REVIEW_V1_MANIFEST.json`.

## Findings and required corrections

### P1 — required files need a nonzero size check

Location: `check_policy` lines 239–244 and its calls at lines 368/371. `check_policy` receives only name sets; presence is enough. `Reads.read` and `zip_inventory` permit zero-length ordinary files. Hash and file-inventory correspondence correctly join an empty file with an empty ZIP member, but cannot satisfy the independently stated nonempty-keeper requirement.

Requirement: `CONSUMER_DELTA_REVIEW.md`, “Exact predicate for actual onedir and ZIP”, item 2: every keeper is present exactly once “as a nonempty ordinary file”. The old archive validator hashes member bytes but does not impose a positive size on every DLL/PYD, so delegating this condition to that validator is not justified by its source.

Reproducer: `independent_checks.py`, `test_all_7_empty_keepers_must_be_rejected`. It uses an independent fixture generator, not the implementation author’s fixtures. Each keeper is individually emptied and restored, with all hashes and lengths recomputed. Every run currently reports PASS. Fixture receipts remain synthetic and are not asserted to be genuine validator evidence.

Correction: bind keeper acceptance to observed byte lengths; reject zero for each keeper, and preserve exact file/hash/ZIP correspondence. Add all-seven regressions in normal and optimized modes. Do not weaken the existing consumer predicate.

### P2 — local and central ZIP64 member metadata is not rejected

Location: `zip_inventory` lines 249–294. The EOCD checks reject ZIP64 EOCD shapes, but never inspect version/ZIP64 member extras or local ZIP64 size sentinels. Python’s ZIP reader transparently parses these members.

Reproducers:

1. `test_zip64_local_members_must_be_rejected`: writes each file through `ZipFile.open(..., mode='w', force_zip64=True)`, confirms version 45 and local compressed/uncompressed size fields `0xffffffff`; then full verification returns PASS.
2. `test_zip64_central_member_must_be_rejected`: leaves a normal local member, rewrites its central sizes to `0xffffffff`, adds the valid 0x0001 extra containing its original 64-bit sizes and sets version 45, while updating the central-directory length. Python reads exactly the original body; full verification returns PASS.

Correction: implement the documented bounded no-ZIP64 policy for both central and local entries, including directory entries; preserve the current data-only behavior. Test local-only, central-only, sentinel/extra, malformed and unsupported metadata paths. Do not simply rely on final EOCD counts. If the intended support envelope is to change, that would need an explicit contract/doc review rather than claiming the existing rejection works.

## Positive results and boundedness assessment

- Exact 47 exclusions and seven keepers match the retained PR179 predicate. Every exclusion tested with full manifest/onedir/ZIP-consistent bytes is rejected; every relocated uppercase excluded basename is rejected. Missing each of seven keepers and changed ZIP-only keeper bytes are rejected.
- Pinned selector bytes execute in memory without package imports/PYC lookup; spec is hashed only. No candidate executable, native library, Python module, serial port or package code runs. The trusted standard-library interpreter remains an external operational requirement.
- Actual candidate/source/GUI/serial/recording artifacts are joined by exact names, byte lengths and SHA-256 to the separately anchored archive receipt. Candidate, manifest, receipt, checksum and per-file mismatches fail. The strict Boolean/integer fields reject tested type confusion.
- Safe paths, case aliases, file/dir collisions, symlink/hardlink/reparse checks, exclusive output, metadata/name/depth/file/count limits and final fingerprints are present. Real Linux FIFO, symlink and hardlink fixture substitutions reject before opening the special payload. Windows reparse checks were only simulated by author tests; no native Windows test occurred.
- Size-budget negatives used tiny patched limits instead of creating large files or decompression bombs. All relevant exercised limits reject. Source inspection found a finite compressed-byte, central-directory, file-count, decompressed-byte and read envelope; this review does not claim a stress measurement at the maximum envelope.
- JSON duplicates, nonfinite literal and excessive nesting/string cases reject; unsafe Windows names reject. CLI failure diagnostics are fixed codes and do not echo attacker-supplied argument text. Output is new, outside both input roots, and does not overwrite an existing file.
- The implementation’s disclosed concurrency scope is appropriate: ordinary fingerprint/inventory mutation detection, not a sandbox against a privileged concurrent writer. No claim is made of atomic snapshot semantics across the complete verify/write sequence.

## External gates that this checker cannot replace

The draft intentionally remains a data-only supplement. It does not authenticate arbitrary supplied PASS reports, evaluate the workflow, attest a clean Git tree, inspect COLLECT/selector logs, decode PyInstaller contents, execute frozen smoke tests, validate original receipt semantics or prove origins. The final consumer successor must bind exact checker bytes, validated report/manifest hashes, source/tree and workflow, inspector receipt, actual selector subset/count and COLLECT evidence, unchanged frozen serial/GUI/recording artifacts, notices and explicit retention inventory. The original eight checksum payloads and unrelated gates must remain.

Those integration obligations are not implemented or accepted by this isolated review. A synthetic successful receipt is useful parser input, not evidence that the complete external validators or Windows operation have succeeded.

## Commands and environment

Environment: local Linux, CPython 3.12.14. All runs use isolation, no site packages and no bytecode writes. Each subprocess was bounded by `timeout 90`; none timed out.

- `python -I -S -B payload-checker/test_check_reduced_payload.py -v`: exit 0, 20 methods, zero skips/failures; `author-normal.log`.
- `python -I -S -B -O payload-checker/test_check_reduced_payload.py -v`: exit 0, 20 methods, zero skips/failures; `author-optimized.log`.
- `PAYLOAD_CHECKER_PATH=<absolute review>/reviewed-inputs/check_reduced_payload.py python -I -S -B payload-checker-review/independent_checks.py`: exit 1, 14 methods, nine failed rejection subcases; `independent-normal.log`.
- Same independent command with `-O`: exit 1, same failures; `independent-optimized.log`.

No generated `.pyc` or leftover temporary inert fixture directories were found after runs. No remote action occurred.

## Rubric, unchanged quality-gate v1.0

- C1 correctness 7.0 × 0.30: the direct nonempty-keeper contract fails, despite correct set/hash joins.
- C2 robustness 8.0 × 0.20: broad fail-closed bounded handling, but keeper acceptance and the unsupported ZIP64 surface require correction.
- C3 evidence 8.0 × 0.25: reproducible 20-method author coverage and independent negatives; both defects were absent from author regressions.
- C4 clarity 9.5 × 0.15: focused, standard-library implementation and clear external trust boundary.
- C5 reproducibility/docs 9.0 × 0.10: strong hash/run instructions, but the stated ZIP64 rejection is false.

Weighted score: **8.025**, below 9.5. Verdict **REWORK**. Re-review the exact frozen successor and affected tests after correction. Original v1 failures must remain preserved; no score is transferred automatically to new bytes.
