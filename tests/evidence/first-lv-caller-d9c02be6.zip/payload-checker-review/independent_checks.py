"""Independent bounded inert contract checks; no candidate/native code executes."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import tempfile
import unittest
from unittest.mock import patch
import zipfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
CHECKER_PATH = Path(os.environ.get('PAYLOAD_CHECKER_PATH', str(BASE / 'payload-checker/check_reduced_payload.py')))
SPEC = importlib.util.spec_from_file_location('reviewed_payload_checker', CHECKER_PATH)
c = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(c)
PREDICATE = json.loads((BASE / 'reduced-consumer-review/PAYLOAD_PREDICATE.json').read_bytes())
EXCLUDED = PREDICATE['excluded_destinations']
KEEPERS = PREDICATE['required_destinations']
COMMIT = 'dcafc5638bc6c3ddef6cba25a7a55016fe8e8933'
CANDIDATE = 'Motortester-windows-x64-candidate.zip'
MANIFEST = 'build-manifest.json'
ARTIFACTS = [CANDIDATE, 'source.zip', 'frozen-window.png', 'frozen-window.png.smoke.json',
             'frozen-serial-import.json', 'frozen-recording.json',
             'frozen-recording.json.work/recording.mtrec', 'frozen-recording.json.work/sample.mtspool']

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii')

class InertFixture:
    def __init__(self, root):
        self.root = root
        self.source, self.build = root / 'source', root / 'build'
        self.source.mkdir(); self.build.mkdir()
        for name in ('select_windows_runtime.py', 'motortester.spec'):
            target = self.source / 'host/packaging' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(BASE / 'reduced-consumer-review/appdcaf/host/packaging' / name, target)
        self.bundle = self.build / 'dist/Motortester'
        self.payload = {'Motortester.exe': b'INERT independent EXE placeholder',
                        '_internal/notice.txt': b'INERT independent notice'}
        for name in KEEPERS:
            self.payload['_internal/' + name] = b'INERT independent keeper: ' + name.encode('ascii')
        self.refresh()

    def refresh(self, force_zip64=False, zip_only=None):
        if self.bundle.exists():
            shutil.rmtree(self.bundle)
        self.bundle.mkdir(parents=True)
        for name, body in self.payload.items():
            path = self.bundle / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
        self.manifest = {'source_commit': COMMIT, 'status': 'candidate-not-release-approved',
                         'usb_verified': False, 'files': {n: sha(v) for n, v in self.payload.items()}}
        self.manifest_raw = encoded(self.manifest)
        (self.bundle / MANIFEST).write_bytes(self.manifest_raw)
        with zipfile.ZipFile(self.build / CANDIDATE, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('Motortester/', b'')
            for path in sorted(self.bundle.rglob('*')):
                if path.is_dir():
                    z.writestr('Motortester/' + path.relative_to(self.bundle).as_posix() + '/', b'')
            for name, raw in {**self.payload, MANIFEST: self.manifest_raw}.items():
                raw = (zip_only or {}).get(name, raw)
                if force_zip64:
                    with z.open('Motortester/' + name, 'w', force_zip64=True) as writer:
                        writer.write(raw)
                else:
                    z.writestr('Motortester/' + name, raw)
        for name in ARTIFACTS[1:]:
            p = self.build / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b'INERT independent artifact: ' + name.encode('ascii'))
        self.refresh_anchors()

    def refresh_anchors(self):
        bodies = {n: (self.build / n).read_bytes() for n in ARTIFACTS}
        hashes = {n: sha(v) for n, v in bodies.items()}
        sums = ''.join(f'{hashes[n]}  {n}\n' for n in sorted(hashes)).encode('ascii')
        (self.build / 'SHA256SUMS.txt').write_bytes(sums)
        self.archive = {'status': 'PASS', 'scope': 'on-runner-archive-content-only', 'source_sha': COMMIT,
                        'source_files': 306, 'binary_files': len(self.payload), 'recording_required': True,
                        'recording_source_zip_hashes_verified': 23, 'hardware_verified': False,
                        'bytes_delivered': False, 'artifacts_sha256': hashes,
                        'artifact_bytes': {n: len(v) for n, v in bodies.items()},
                        'build_manifest_sha256': sha(self.manifest_raw), 'checksum_file_sha256': sha(sums)}
        self.save_archive()

    def save_archive(self):
        self.archive_raw = encoded(self.archive)
        (self.build / 'archive-verification.json').write_bytes(self.archive_raw)

    def verify(self):
        return c.verify(self.source, self.build, sha(self.manifest_raw), sha(self.archive_raw))


class IndependentContract(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(dir=HERE, prefix='inert-independent-')
        self.addCleanup(temp.cleanup)
        self.f = InertFixture(Path(temp.name))

    def test_positive_exact_contract_and_false_claims(self):
        r = self.f.verify()
        self.assertEqual(r['status'], 'PASS')
        self.assertEqual(r['application_commit'], PREDICATE['application_commit'])
        self.assertEqual(r['application_tree'], PREDICATE['application_tree'])
        for key in ('onedir_policy', 'zip_policy'):
            self.assertEqual(r[key]['excluded_absent'], EXCLUDED)
            self.assertEqual([x['destination'] for x in r[key]['required_present']], KEEPERS)
            self.assertEqual(r[key]['required_present_count'], 7)
        for key in ('authenticated_origins', 'tls_capability_verified', 'hardware_verified',
                    'physical_stop_verified', 'windows_10_verified', 'legal_clearance', 'bytes_delivered',
                    'native_code_executed', 'candidate_python_executed', 'payload_modified'):
            self.assertIs(r[key], False)
        self.assertEqual(r['actual_candidate_zip']['sha256'], sha((self.f.build / CANDIDATE).read_bytes()))
        self.assertFalse(list(self.f.root.rglob('*.pyc')))

    def test_all_47_exclusions_full_consistent_fixture_rejected(self):
        for name in EXCLUDED:
            with self.subTest(name=name):
                path = '_internal/' + name
                self.f.payload[path] = b'INERT forbidden'
                self.f.refresh()
                with self.assertRaisesRegex(c.Invalid, '^excluded_or_related_destination$'):
                    self.f.verify()
                del self.f.payload[path]

    def test_all_47_alternate_uppercase_destinations_rejected(self):
        for name in EXCLUDED:
            with self.subTest(name=name):
                path = 'extra/' + name.rsplit('/', 1)[-1].upper()
                self.f.payload[path] = b'INERT forbidden alternate'
                self.f.refresh()
                with self.assertRaisesRegex(c.Invalid, '^excluded_or_related_destination$'):
                    self.f.verify()
                del self.f.payload[path]

    def test_all_7_missing_keepers_rejected(self):
        for name in KEEPERS:
            with self.subTest(name=name):
                path = '_internal/' + name
                old = self.f.payload.pop(path)
                self.f.refresh()
                with self.assertRaisesRegex(c.Invalid, '^missing_keeper$'):
                    self.f.verify()
                self.f.payload[path] = old

    def test_all_7_empty_keepers_must_be_rejected(self):
        for name in KEEPERS:
            with self.subTest(name=name):
                path = '_internal/' + name
                old = self.f.payload[path]
                self.f.payload[path] = b''
                self.f.refresh()
                try:
                    with self.assertRaises(c.Invalid, msg='Consumer predicate requires a NONEMPTY ordinary keeper'):
                        self.f.verify()
                finally:
                    self.f.payload[path] = old

    def test_zip64_local_members_must_be_rejected(self):
        self.f.refresh(force_zip64=True)
        raw = (self.f.build / CANDIDATE).read_bytes()
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            z = archive.getinfo('Motortester/Motortester.exe')
            self.assertEqual(z.extract_version, 45)
            self.assertEqual(struct.unpack_from('<II', raw, z.header_offset + 18), (0xffffffff, 0xffffffff))
        with self.assertRaises(c.Invalid, msg='README promises to reject ZIP64'):
            self.f.verify()

    def test_zip64_central_member_must_be_rejected(self):
        raw = bytearray((self.f.build / CANDIDATE).read_bytes())
        end = raw.rfind(b'PK\x05\x06')
        cd_size, at = struct.unpack_from('<II', raw, end + 12)
        while at < end:
            self.assertEqual(raw[at:at+4], b'PK\x01\x02')
            n, extra, comment = struct.unpack_from('<HHH', raw, at + 28)
            name = bytes(raw[at+46:at+46+n])
            if name == b'Motortester/Motortester.exe':
                compressed, uncompressed = struct.unpack_from('<II', raw, at + 20)
                addition = struct.pack('<HHQQ', 1, 16, uncompressed, compressed)
                struct.pack_into('<H', raw, at + 6, 45)
                struct.pack_into('<II', raw, at + 20, 0xffffffff, 0xffffffff)
                struct.pack_into('<H', raw, at + 30, extra + len(addition))
                insert = at + 46 + n + extra
                raw[insert:insert] = addition
                struct.pack_into('<I', raw, end + len(addition) + 12, cd_size + len(addition))
                break
            at += 46 + n + extra + comment
        else:
            self.fail('Fixture file not found in central directory')
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            zi = archive.getinfo('Motortester/Motortester.exe')
            self.assertEqual(zi.extract_version, 45)
            self.assertEqual(archive.read(zi), self.f.payload['Motortester.exe'])
        (self.f.build / CANDIDATE).write_bytes(raw)
        self.f.refresh_anchors()
        with self.assertRaises(c.Invalid, msg='README promises to reject ZIP64 central metadata'):
            self.f.verify()

    def test_all_7_zip_changed_keeper_bytes_rejected(self):
        for name in KEEPERS:
            with self.subTest(name=name):
                self.f.refresh(zip_only={'_internal/' + name: b'INERT different'})
                with self.assertRaisesRegex(c.Invalid, '^zip_directory_join$'):
                    self.f.verify()

    def test_archives_manifest_checksums_all_bind(self):
        for name in ARTIFACTS:
            with self.subTest(name=name):
                self.f.refresh()
                path = self.f.build / name
                path.write_bytes(path.read_bytes() + b'changed')
                with self.assertRaisesRegex(c.Invalid, '^archive_artifact_join$'):
                    self.f.verify()
        self.f.refresh()
        (self.f.build / 'SHA256SUMS.txt').write_bytes(b'corrupt\n')
        with self.assertRaisesRegex(c.Invalid, '^checksum_join$'):
            self.f.verify()
        self.f.refresh()
        with self.assertRaisesRegex(c.Invalid, '^manifest_join$'):
            c.verify(self.f.source, self.f.build, '0' * 64, sha(self.f.archive_raw))
        with self.assertRaisesRegex(c.Invalid, '^archive_report_pin$'):
            c.verify(self.f.source, self.f.build, sha(self.f.manifest_raw), '0' * 64)

    def test_receipt_required_fields_reject_malformed(self):
        for key, value in [('status', 'FAIL'), ('scope', 'other'), ('source_sha', '0' * 40),
                           ('source_files', 305), ('source_files', True), ('recording_required', 1),
                           ('recording_source_zip_hashes_verified', 22), ('hardware_verified', 0),
                           ('bytes_delivered', True), ('binary_files', True)]:
            with self.subTest(key=key, value=value):
                self.f.refresh()
                self.f.archive[key] = value
                self.f.save_archive()
                with self.assertRaises(c.Invalid):
                    self.f.verify()

    def test_real_fifo_symlink_hardlink_rejected_before_read(self):
        path = self.f.bundle / '_internal/notice.txt'
        original = path.read_bytes()
        outside = self.f.root / 'outside'
        outside.write_bytes(original)
        for kind in ('fifo', 'symlink', 'hardlink'):
            with self.subTest(kind=kind):
                path.unlink()
                if kind == 'fifo':
                    os.mkfifo(path)
                elif kind == 'symlink':
                    path.symlink_to(outside)
                else:
                    os.link(outside, path)
                with self.assertRaises(c.Invalid):
                    self.f.verify()
        path.unlink()
        path.write_bytes(original)

    def test_size_limits_using_tiny_patched_limits(self):
        for key, limit in [('MAX_META', 10), ('MAX_FILE', 1), ('MAX_ZIP', 100),
                           ('MAX_READ', 1), ('MAX_ENTRIES', 1), ('MAX_FILES', 1), ('MAX_TOTAL', 1)]:
            with self.subTest(limit=key), patch.object(c, key, limit):
                with self.assertRaises(c.Invalid):
                    self.f.verify()

    def test_unsafe_json_and_paths_rejected(self):
        for body in [b'{"a":1,"a":2}', b'{"a":NaN}', b'[' * 17 + b']' * 17,
                     b'"' + b'x' * 12289 + b'"']:
            with self.subTest(kind='json'), self.assertRaises(c.Invalid):
                c.decode(body)
        for name in ['../x', '/x', 'a\\b', 'AUX.txt', 'LPT\u00b2.dll', 'a./b', 'a /b',
                     'a:b', 'a\x00b', 'a\x7fb', 'a/' * 17 + 'b']:
            with self.subTest(name=name), self.assertRaises(c.Invalid):
                c.relative(name)

    def test_report_is_exclusive_outside_inputs_and_cli_failure_sanitized(self):
        result = self.f.verify()
        for root in [self.f.source, self.f.build]:
            with self.assertRaisesRegex(c.Invalid, '^output_overlaps_inputs$'):
                c.write_report(root / 'report.json', result, self.f.source, self.f.build)
        output = self.f.root / 'report.json'
        c.write_report(output, result, self.f.source, self.f.build)
        original = output.read_bytes()
        with self.assertRaises(FileExistsError):
            c.write_report(output, result, self.f.source, self.f.build)
        self.assertEqual(output.read_bytes(), original)
        error = io.StringIO()
        with contextlib.redirect_stderr(error):
            status = c.main(['--output', 'UNTRUSTED\nSECRET'])
        self.assertEqual(status, 1)
        self.assertEqual(error.getvalue(), 'REDUCED_PAYLOAD_FAILED code=arguments\n')

if __name__ == '__main__':
    unittest.main(verbosity=2)
