# Independent review: final reduced-payload checker v2

Date: 2026-10-17. Reviewer: the independently assigned A-side checker reviewer. I did not implement or edit the checker, its author tests, `host/**`, any workflow or retention helper. Review artifacts and independent tests are confined to this review directory. No remote action occurred.

## Scoped verdict

**PASS, 10.00/10, for the exact v2 data-only reduced-payload checker, its tests and documented invocation contract.** No open P0/P1/P2 remains in this reviewed scope. The two v1 findings are closed by source corrections and independently reproduced negative checks on the frozen successor.

This accepts neither a complete A consumer/workflow successor nor a fresh Windows candidate. Windows 10 execution, frozen application behavior, physical hardware/Stop, origins, TLS, licenses, delivery, full Git attestation, COLLECT/selector evidence and evaluated-workflow integration remain separate unestablished gates. This is a local source/inert-software review only.

## Exact state and independence

The checker is a local uncommitted draft, so it has no commit SHA. Exact SHA-256 is the review binding; copies are preserved in `v2/reviewed-inputs/`:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| check_reduced_payload.py | 24424 | b6264f445d9c7abf3170e3072d25632f3bb6e9b3980c0af5bfa8e206bf0dd8e7 |
| test_check_reduced_payload.py | 24119 | f1d61c5c04de3edcc2a16f25634d19354a37df18d302ecf913d294fdd5ee348a |
| README.md | 5892 | 8310daff4614bd32f7e1bbf805807bd5e2ae8c12c44cb497214ad50ea5566185 |

Application contract: PR179 head `dcafc5638bc6c3ddef6cba25a7a55016fe8e8933`, expected tree `61a9bd025081acec80997dff950d947eeceb3f4b`, parent `244b0786a18fed19a9e708bb815150475ddd193f`. The checker pins the exact selector (5686 bytes, SHA-256 `f4144a5318f4607a207531559c03365d2351473b40b5431ddfb4f7c3d381712b`) and spec (1867 bytes, SHA-256 `b754e84f96be7c8d8c8284a29457c83567f02c53344a99235857a60386d3e492`). I read these source bodies and the retained consumer predicate, archive-validator snapshot and provenance-inspector source. No fresh remote/source-tree reconstruction is claimed here.

The implementation author received findings and corrected its own source. I preserved the original review, failures and source snapshots, read the successor diff, then independently reran both suites and added new inert cases. `REVIEW_V1.md` and `REVIEW_V1_MANIFEST.json` remain the historical REWORK record; the original 14-method independent script and v1 failure logs are unchanged.

## Resolution of the two findings

### P1: empty keepers — closed

V2 calls `bind_keeper_bytes` on the already-hashed actual onedir inventory and independently on the ZIP inventory. Every keeper must have an observed length greater than zero. Both policy observations now carry the actual byte length and SHA-256, without inventing origins.

All seven isolated consistent-empty-keeper cases that returned PASS in v1 now reject in both normal and optimized runs. Full positive fixtures and valid streaming/stored ZIPs still pass, and every keeper observation matches its actual inert bytes. Name presence, ordinary-file type, exact manifest/onedir/ZIP equality and hashes remain required.

### P2: member-level ZIP64 acceptance — closed

V2 keeps its EOCD limits and additionally inspects each entry’s central version, volume and extra-field framing. It reads each bounded local header, rejects ZIP64 versions/sentinels/extras and checks compression, flags, local/central lengths/CRC and decoded filename. Directory entries take the same local-header path. No extraction or executable decoding was added.

Independent local-only ZIP64, central-only ZIP64 and spoofed ordinary-version ZIP64 fixtures now reject. Malformed directory local signature/version/flags/method/sizes/extras/name reject. To check against over-rejection, valid non-seekable archives using data descriptors pass with both STORED and DEFLATED files. The author’s new central-only fixture and extra-field/bounds tests also pass.

## Checks actually run by this reviewer

Local Linux CPython 3.12.14. Each invocation was bounded by `timeout 90`, used `-I -S -B`, executed only inert data fixtures plus the exact pinned pure selector, and completed without timeout.

| Suite | Normal | Optimized `-O` | Evidence |
| --- | --- | --- | --- |
| Author suite | 24 methods, exit 0 | 24 methods, exit 0 | `v2/author-normal.log`, `v2/author-optimized.log` |
| Independent suite | 17 methods, exit 0 | 17 methods, exit 0 | `v2/independent-normal.log`, `v2/independent-optimized.log` |

All four runs have zero failures/errors/skips. Independent assertions use `unittest` methods and are active under `-O`. The independent fixture generator does not import the author’s test fixture.

Reproduce the author runs from the task root:

- `python -I -S -B payload-checker/test_check_reduced_payload.py -v`
- `python -I -S -B -O payload-checker/test_check_reduced_payload.py -v`

Reproduce the independent runs against the preserved exact implementation:

- `PAYLOAD_CHECKER_PATH=<absolute review>/v2/reviewed-inputs/check_reduced_payload.py python -I -S -B payload-checker-review/independent_checks_v2.py`
- Same command with `-O`.

Independent coverage includes:

- Every one of the 47 exclusions as a fully manifest/onedir/ZIP/receipt-consistent forbidden file, and every relocated uppercase excluded basename.
- Every missing keeper, every individually empty keeper, and every ZIP-only changed keeper.
- Exact 47/7 list correspondence to `PAYLOAD_PREDICATE.json`; positive report identities and false physical/release claims.
- Each of the eight artifact hash/length joins, checksum corruption, manifest/report anchor mismatches, strict receipt field/type checks and file-count consistency.
- Real Linux FIFO, symlink and hardlink substitutions; safe-path/JSON negatives; exclusive output and sanitized CLI diagnostics.
- Tiny patched metadata/member/archive/count/total/read budgets, avoiding large allocations or actual decompression bombs.
- Local and central ZIP64, version spoofing, malformed local directory metadata, valid data descriptors, STORED and DEFLATED archives.

The author suite additionally covers related-family rejection/unrelated-family preservation, source pin changes, candidate Python/PYC non-execution, directory and ZIP inventory/case collisions, encrypted/type/NUL/member metadata cases, reparse simulation, input mutation, report output and no-overwrite behavior.

## Bounded file handling and trust boundary

The checker reads ordinary single-link files with no symlink/reparse ancestors, uses fixed input/count/depth/read limits, and compares before/opened/final fingerprints. ZIP input is capped at 200 MiB; its central directory is bounded before `ZipFile` construction; file/member and total expanded sizes are bounded; all actual payload file bytes are hashed. No extraction occurs. Metadata parsing has depth/node/string limits and duplicate-key rejection. The output is exclusive and separated from input roots; diagnostics contain fixed codes.

Boundaries remain explicit:

- Positive fixture receipts are synthetic parser inputs, never genuine archive-validation or Windows evidence.
- The report’s application/tree fields are expected external bindings. The caller must separately verify clean checkout/raw Git bodies, exact checker bytes and the evaluated workflow.
- A user-supplied hash cannot authenticate a forged PASS receipt. The required manifest/report anchors must come from the already validated guarded run.
- Actual original archive/provenance validators remain mandatory; this checker does not decode PE, PyInstaller, CArchive or PYZ content or validate frozen receipt semantics itself.
- Stable-input fingerprints are not an atomic snapshot or a sandbox against a privileged concurrent writer.
- Linux inert tests and simulated reparse attributes are not native Windows tests. Maximum-sized stress behavior was not measured; boundedness was reviewed in source and with reduced-limit negative cases.

## Consumer integration remains outside this acceptance

Before an integrated consumer can claim its own PASS, it must still bind all obligations in the retained consumer review: exact source/tree/spec/selector and evaluated workflow, inspector report, original eight checksum artifacts, actual selector subset/count and COLLECT evidence, successful unchanged frozen smokes, necessary notices/accompaniment and explicit retention joins. The fixed46 historical observer must not silently remain a required reduced-payload gate, and missing DLLs must not be represented as fabricated origins. No post-smoke trimming is permitted.

The README correctly frames this checker as a supplement and preserves the external source/archive/provenance trust boundary, immutable-smoke rule and false approval flags. This review is not evidence that future caller/retention code already supplies those missing joins.

## Quality-gate v1.0 rubric

The five unchanged criteria are applied only to the declared source/inert-checker scope:

- C1 10 × 0.30: exact 47 exclusions/seven nonempty keepers, file/ZIP/manifest joins and explicit source pins satisfy the reviewed predicate; both proven v1 defects are closed.
- C2 10 × 0.20: relevant path/type/mutation/budget/metadata/ZIP failure branches reject under tested normal and optimized conditions, with finite input envelopes and honest concurrency limits.
- C3 10 × 0.25: independently reproduced defects, retained failure history, exact frozen hashes, 24+24 author and 17+17 independent methods, no silent skips, and explicit unperformed stages.
- C4 10 × 0.15: additions are limited to nonempty byte binding and bounded member metadata checks; standard-library/data-only design and responsibilities remain clear.
- C5 10 × 0.10: README reflects the corrected contract, reproducible commands and historical v1 failures; exact code, tests, report and log hashes are retained.

Weighted score **10.00**. This is not a probability of correctness, physical safety guarantee or release score. New source bytes or consumer integration require their own current review.
