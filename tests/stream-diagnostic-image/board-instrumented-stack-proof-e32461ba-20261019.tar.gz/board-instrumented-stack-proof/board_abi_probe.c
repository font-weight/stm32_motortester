#include "mt_board_inputs.h"
#include "mt_stream_timing.h"
#include <stddef.h>
#define SIZE(n,t) const unsigned char n[sizeof(t)]={0}
#define OFF(n,t,m) const unsigned char n[offsetof(t,m)+1]={0}
SIZE(size_board,mt_board_inputs);SIZE(size_identity,mt_usb_identity);SIZE(size_timing,mt_stream_timing_inputs);
OFF(off_board_usb,mt_board_inputs,usb);OFF(off_board_mode,mt_board_inputs,hse_mode);OFF(off_board_dtr,mt_board_inputs,require_dtr);OFF(off_board_pullup,mt_board_inputs,verified_fixed_pullup);OFF(off_identity_manufacturer,mt_usb_identity,manufacturer);OFF(off_identity_product,mt_usb_identity,product);OFF(off_identity_serial,mt_usb_identity,serial);
