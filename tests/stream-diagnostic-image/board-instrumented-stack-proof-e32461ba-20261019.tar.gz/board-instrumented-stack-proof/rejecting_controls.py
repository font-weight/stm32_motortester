#!/usr/bin/env python3
"""Mutations affect review copies only, never the image or repository."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,json,subprocess,shutil,hashlib,sys
O=pathlib.Path(__file__).resolve().parent;D=O/'controls';D.mkdir(exist_ok=False)
results=[]
files=['check_sp.py','inventory.json','callback-analysis.json','final.dis']
def case(name,change):
 p=D/name;p.mkdir(exist_ok=False)
 for f in files:shutil.copyfile(O/f,p/f)
 change(p)
 r=subprocess.run([sys.executable,'-I','-B',str(p/'check_sp.py')],capture_output=True,text=True)
 (p/'stdout').write_text(r.stdout);(p/'stderr').write_text(r.stderr)
 issues=json.loads((p/'sp-cfg-analysis.json').read_text())['issues'] if (p/'sp-cfg-analysis.json').exists() else []
 rejected=bool(r.returncode or issues)
 results.append({'name':name,'rejected':rejected,'returncode':r.returncode,'issues':issues})
def replace(p,old,new):
 f=p/'final.dis';s=f.read_text();assert old in s;s=s.replace(old,new,1);f.write_text(s)
def editjson(p,file,fn):
 f=p/file;x=json.loads(f.read_text());fn(x);f.write_text(json.dumps(x,indent=2)+'\n')
case('misaligned_stable_frame',lambda p:replace(p,'sub\tsp, #52','sub\tsp, #48'))
case('missing_tail_lr_restore',lambda p:replace(p,'ldr.w\tlr, [sp], #4','mov.w\tlr, r0'))
case('dynamic_stack_write',lambda p:replace(p,'sub\tsp, #52','mov\tsp, r0'))
case('return_past_entry',lambda p:replace(p,'add\tsp, #52','add\tsp, #56'))
case('call_inside_literal_data',lambda p:replace(p,'bl\t8001ba0 <mt_usb_bridge_snapshot>','bl\t8008224 <_usbd_driver>'))
case('unknown_indirect_site',lambda p:replace(p,'bl\t8001ba0 <mt_usb_bridge_snapshot>','blx\tr3'))
case('wrong_su',lambda p:editjson(p,'inventory.json',lambda x:x['frames']['0x800625c'].__setitem__('bytes',128)))
case('switch_leaves_owner',lambda p:editjson(p,'callback-analysis.json',lambda x:x['switch_tables'][0]['targets'].__setitem__(0,'0x8008294')))
case('callback_target_not_function',lambda p:editjson(p,'callback-analysis.json',lambda x:next(q for q in x['callback_sites']if q['site']=='0x8006a36')['targets'][0].__setitem__('address','0x8008224')))
assert all(x['rejected']for x in results),results
(O/'rejecting-controls.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
