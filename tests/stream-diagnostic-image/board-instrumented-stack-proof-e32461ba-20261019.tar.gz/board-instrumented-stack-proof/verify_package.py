#!/usr/bin/env python3
"""Replay only this frozen instrumented static proof; preserve every attempt.
No compile, link, target execution, flash, network, or repository mutation.
"""
import sys
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,argparse,json,hashlib,subprocess,re,tarfile,shutil,datetime,uuid,traceback
O=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--objdump',required=True,type=pathlib.Path);args=p.parse_args()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,reason):
    if not ok:raise RuntimeError(reason)
# Each attempt keeps a new evidence directory, including failures. Never replace
# an earlier failure with a later successful run or rewrite frozen inputs.
log=O/'replays'/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:12]);log.mkdir(parents=True,exist_ok=False)
commands=[]
try:
    manifest=json.loads((O/'manifest.json').read_text())
    require(manifest['elf_sha256']=='e32461ba94ce8d105ced09dd56ee82689f4fbdc4b8c8bdb15419e74a94b807f2','wrong image identity')
    for rel,h in manifest['files'].items():
        require(not pathlib.PurePosixPath(rel).is_absolute() and '..' not in pathlib.PurePosixPath(rel).parts,('unsafe manifest entry',rel))
        require(sha(O/rel)==h,('package hash changed',rel))
    tool=args.objdump.resolve(strict=True)
    r=json.loads((O/'image/receipt.json').read_text());inv=json.loads((O/'inventory.json').read_text())
    expected_tool=next(h for f,h in r['inputs_before'].items()if f.endswith('/bin/arm-none-eabi-objdump'))
    require(sha(tool)==expected_tool,'wrong objdump bytes')
    for x in r['objects']:require(sha(O/'image/objects'/pathlib.Path(x['path']).name)==x['sha256'],('object drift',x['path']))
    require(len(r['objects'])==30,'object count')
    # Every dependency is checked from source.tar or its frozen external snapshot.
    external=json.loads((O/'dependency-snapshot.json').read_text());counts={'source':0,'external_or_generated':0}
    with tarfile.open(O/'image/source.tar')as t:
        entries=[m for m in t.getmembers()if m.isfile()];members={m.name:m for m in entries};require(len(entries)==len(members),'duplicate source archive entries')
        for f,h in r['dependencies'].items():
            if '/source/' in f:
                name=f.split('/source/',1)[1];require(name in members,('missing source dependency',name))
                require(hashlib.sha256(t.extractfile(members[name]).read()).hexdigest()==h,('source dependency drift',name));counts['source']+=1
            else:
                require(f in external,('unsnapshotted dependency',f));require(sha(O/external[f])==h,('external dependency drift',f));counts['external_or_generated']+=1
    require(sum(counts.values())==100,'dependency count')
    def canonical(s):return re.sub(r'^.*:     file format elf32-littlearm$', 'EXACT_ELF:     file format elf32-littlearm',s,flags=re.M)
    cmd=[str(tool),'-drwC',str(O/'image/DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf')]
    z=subprocess.run(cmd,text=True,capture_output=True);commands.append({'stage':'disassemble','argv':cmd,'exit':z.returncode});(log/'objdump.stdout').write_text(z.stdout);(log/'objdump.stderr').write_text(z.stderr)
    require(z.returncode==0,('objdump exit',z.returncode));require(canonical(z.stdout)==canonical((O/'final.dis').read_text()),'disassembly differs')
    frames={}
    for f in (O/'image/objects').glob('*.su'):
        rows={}
        for l in f.read_text().splitlines():
            head,n,kind=l.split('\t');rows[head.rsplit(':',1)[1]]=(int(n),kind)
        for a,x in inv['code_ranges'].items():
            if pathlib.Path(x['object']).name!=f.with_suffix('.o').name:continue
            name=x['section'][6:];keys=[name,name.removeprefix('startup.'),re.sub(r'\.(isra|constprop)\.\d+',r'.\1',name)]
            found=next((rows[k]for k in keys if k in rows),None);require(found,(a,name))
            require(found==(inv['frames'][a]['bytes'],'static'),('frame drift',a));frames[a]=found
    require(len(frames)==344,'frame count')
    # Analyses execute in a fresh private copy. Their outputs cannot overwrite
    # the reviewed values or earlier attempt evidence, even on partial failure.
    work=log/'work';work.mkdir()
    for rel in manifest['files']:
        src=O/rel;dst=work/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    shutil.copyfile(O/'manifest.json',work/'manifest.json')
    for script in ['verify_board.py','trace_callbacks.py','check_sp.py','rejecting_controls.py','derive_bound.py','test_interpreter_policy.py']:
        argv=[sys.executable,'-I','-B',str(work/script)];rr=subprocess.run(argv,capture_output=True,text=True)
        commands.append({'stage':script,'argv':argv,'exit':rr.returncode});(log/(script+'.stdout')).write_text(rr.stdout);(log/(script+'.stderr')).write_text(rr.stderr)
        require(rr.returncode==0,('analysis rejected',script,rr.returncode))
    for rel in ['board-binding.json','callback-analysis.json','sp-cfg-analysis.json','rejecting-controls.json','static-bound.json','interpreter-policy-controls.json']:
        require(sha(work/rel)==manifest['files'][rel],('replay drift',rel))
    result={'status':'FROZEN_CONDITIONAL_INSTRUMENTED_STATIC_PROOF_REPLAY_PASS','elf_sha256':sha(O/'image/DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf'),'tool_sha256':sha(tool),'dependencies_verified':counts,'objects_verified':len(r['objects']),'su_frames_verified':len(frames),'analysis_exits':[{'script':x['stage'],'exit':x['exit']}for x in commands if x['stage']!='disassemble'],'scope':'Exact conditional static stack/ABI/callback evidence only; no aggregate/hardware/WCET/flash acceptance'}
    (log/'result.json').write_text(json.dumps(result,indent=2)+'\n');(log/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(result,indent=2))
except Exception as exc:
    result={'status':'REPLAY_REJECTED','error':str(exc),'evidence_directory':str(log),'commands':commands}
    (log/'failure.json').write_text(json.dumps(result,indent=2)+'\n');(log/'traceback.txt').write_text(traceback.format_exc());sys.stderr.write(json.dumps(result,indent=2)+'\n');raise SystemExit(1)
