# Независимое ревью board-specific instrumented STREAM ELF e32461ba

## Область и вывод

PASS 9.60/10 только для условной статической верхней границы стека, замыкания callback и ARM ABI точного образа, указанного ниже. Это отдельное новое вычисление после исправления first-START binding, не перенос исторического числа2801bbd8 или uninstrumented1480750b. Функциональное source/native-ревью телеметрии ведётся отдельно; этот отчёт не принимает firmware/прибор в целом и не является разрешением прошивки.

- Реализация: font-weight/stm32_motortester, сборочный и проверяемый commit 31b93659164dec376bea5b973b597196c6a4a0ad. Его firmware bytes совпадают с production8c51c78024a2e1bcd1e5575ef9189737a3ddce88; последующий evidence-only commit не меняет production.
- Образ: image/DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf, SHA256 e32461ba94ce8d105ced09dd56ee82689f4fbdc4b8c8bdb15419e74a94b807f2. Профиль foreground-dwt-v1, CFG_MT_STREAM_DIAGNOSTICS=1 и CFG_MT_USB_CTR_FAIRNESS=1.
- text=33500, data=128, bss=9108 байт. Caller-board draft input сохранён из исторической декларации с новым build0x53545231; новых физических проверок/attestations нет. Provisional1ms не является временным свидетельством.
- Критик: независимый агент verify_instrumented_stack, не автор production-реализации. Независимый audit_diagnostic_roots проверил дополнительные диагностические roots, lifetime, object/source binding и DWT-условия.
- Применимые основания: CON-08/12, PERF-03, DOC-01/02, MVP-F01 в узкой части статической геометрии; docs/quality-gate.md редакции1.0. Общий software-ready или физический уровень этой работой не принимается.

Новая, отдельно выведенная верхняя оценка: foreground 2856 B + USB software 264 B + 3×36 B аппаратных кадров = 3228 B. Минимальный резерв, округлённый до8 B, равен3232 B. Заявленный линкеру резерв8192 B превышает его на4960 B. Это арифметическая разница в условной модели, не измеренный high-water mark, не оценка вероятности отказа, не квалификация timing и не допуск прошивки.

## Точные условия

1. Только закреплённые ELF, исходная инициализация, code/data bytes, callback registrations и root set. Не произвольное изменённое firmware.
2. Настоящий system/core reset в privileged Thread/MSP, без bootloader handoff. Reset устанавливает VTOR и STKALIGN; CPU admission проверяет ожидаемые PRIMASK/BASEPRI/FAULTMASK/IPSR/CONTROL.
3. Из конфигурируемых IRQ допускаются только USB HP19/LP20 с одинаковым hardware priority; DCD dispatch окружён настоящим PRIMASK save/restore. Нет RTOS, SysTick, DMA/timer ISR, второго владельца ADC/USB/TIME, изменения векторов или priorities извне.
4. Нет внешней debug/trace/DebugMonitor конфигурации, чужого instrumentation и concurrent diagnostic writer. Это отдельное условие, не следствие одного лишь system-reset факта: diagnostic init сохраняет остальные DEMCR/DWT_CTRL bits и не квалифицирует чужие comparator/trace state. Сам код не включает DebugMonitor или comparator events.
5. NMI/HardFault терминальны в Default_Handler без software frame. Предполагаются успешные архитектурные stacking/unstacking, исправная доступная SRAM и отсутствие произвольной порчи кода/данных/MSP, ошибочного DMA за границей буфера. Ошибка самого stacking не объявляется успешно созданным кадром.
6. Проверенные callback ownership и отсутствие повторного входа сохраняются. DWT наблюдения не вводят новый actor или асинхронный producer.

## Лично повторённые проверки и provenance

В live-provenance-audit.json лично повторно сверены все425 input pins,100 dependency pins,253 generated pins и30 object SHA исходной квитанции; mismatch нет. Независимый дополнительный аудит подтвердил source.tar против точного production commit, а не против moving HEAD. Из100 compiler dependencies74 лежат в source.tar; остальные26, включая фактически patched usbd.c/DCD, board/timing и внешние compiler headers, сохранены в image/dependencies и сверяются при replay. Source archive содержит248 regular files.

Образ имеет30 object inputs:27 C translation units, Reset, board и timing. Все344 C code input sections сопоставлены с конкретным объектом и static .su, включая clones и3 оставшихся anonymous weak stub bodies. Reset_Handler и Default_Handler дают ещё2 тела, всего346. Нет неразрешённых символов, libgcc/libc archive fallback или скрытого CRT. Собственные memcpy/memmove/memset/memcmp учтены как обычные функции графа.

Сохранены полные compiler/linker argv и SHA toolchain, версии/выбор cc1 и as. GCC14.2.1 20241119, Cortex-M3 Thumb soft-float, -Os, freestanding, no-short-enums, function/data sections, stack-usage, strict warnings. Использованные gcc/cc1/as/ld закреплены hash в исходном receipt; objdump для replay дополнительно обязан иметь точный SHA bcf47eb777c4ac452c765af3e61b4e7b19ad62060a226b74eb189fd9547910e0. Это прослеживаемость фактически сохранённых команд/байтов, не заявление о полностью герметичной пересборке всех30 translation units или формально доказанной корректности компилятора/host.

Независимый ARM ABI probe повторно скомпилирован лично теми же flags/headers. Получены байт-в-байт прежние ABI object bytes, SHA256 14c89ba927d5e35746d2861bd756b4c9bffffed757e22b9c6df4804280002dd3. Probe не линковался в production ELF. Generic BOOT input/ELF audit ранее выполнен и его сохранённый результат/pins проверен; он не подменяет stack proof. Full production rebuild, target execution, экспорт BIN/HEX и прошивка в этой работе не выполнялись.

## Callback, switch, DWT и ABI

В машинном коде109 register-indirect transfers:94 BLX и15 tail BX. callback-spec.json перечисляет каждую точку с actual owner/op/register и допустимыми target entry. Все ранее существующие регистрации повторно привязаны к новым адресам точного образа.10 новых диагностических точек в mt_stream_diag_cycle/init имеют единственные targets mt_clock_mmio_read32/write32. Main передаёт именно эти функции, NULL MMIO context; globals живут постоянно, указатель на временный initializer не сохраняется.

ADC→runtime MMIO/TIME, guard→USB/IRQ guard, live IO→единственные live callbacks, queue/spin→usbd_int_set, CDC class driver→единственная36-byte table. Реальные preprocess macros подтверждают OS_NONE, DEVICE/full-speed, host=0, CDC=1, остальные классы=0, bridge/fairness enabled, task event opportunity1 и queue16. Три исключённые callback точки имеют конкретные основания: .sof=0, .xfer_isr=0 и недостижимый USBD_EVENT_FUNC_CALL с единственным uncalled/unreferenced producer. App-driver getter остаётся weak count0/NULL. Все6 computed-switch таблиц декодированы и имеют targets внутри соответствующего owner; они не отброшены как неизвестные вызовы.

Новые diag вызовы только foreground: init до runtime/USB/admission; cycle/poll/copy/TX/observe/note/begin/replaced вызываются из существующей последовательной цепи. Ни один diag body недостижим из HP/LP/Default roots. Нет регистрации ISR, задачи, timer callback, CDC writer, deferred function или рекурсивного runtime entry. DWT доступ не обещается физически поддержанным; если он fault-ит, применяется терминальная fault-модель. Работа CYCCNT, modulo/full wrap, debugger halt и measured-span accuracy не квалифицируются stack proof.

ARM EABI5, ARMv7-M/Thumb-2, soft-float,32-bit enums,8-byte public-call alignment. Probe подтверждает record136, runtime7760, ADC904, device6104, acquisition584, live_clock32, live_io32, USB epoch48 и live snapshot568 байт. Runtime offsets: adc0/device904/acquisition7008/clock64=7592/clock7624/mmio7628/carry7688. Live IO offsets0/4/8/12/16/20/24/28; ADC ring0, snapshot512, IO768; guard12 и stop_scratch32.

runtime=[0x20000488,0x200022d8), DMA ring=[0x20000488,0x20000688), ADC snapshot=[0x20000688,0x20000788). Diagnostic record=[0x2000238c,0x20002414), static end=0x20002414, static allocation9236 B. Stack reserve=[0x20003000,0x20005000), gap от static end до stack limit3052 B. Эти интервалы не пересекаются в nominal20 KiB SRAM; идентичность и объём физического чипа не измерены.

Проверен48-byte sret snapshot: stable использует SP+0..47 при saves сSP+52; synchronize_loss SP+0..47 при saves сSP+48; instrumented runtime_step SP+48..95 при saves сSP+100. Ключи IRQ guard в saved registers, snapshot не перекрывает их. Runtime_step выделяет100 B local плюс36 B saved registers, всего136 B. В r3 live_stop имеет16 B own frame около BEGIN, но восстанавливает его перед tail-переходом в quiesce. Поэтому максимизирующая цепочка использует tail depth0; этот результат получен по новым инструкциям, не принят из r2. uint64 возвращается в r0/r1, выровненные аргументы r2/r3 и stack argument slots учтены actual .su/CFG. Diagnostic init local record136+24 saved=160 B, вызываемая cycle24 даёт184 B; пути init не доминируют основной bound.

## Машинный стек и арифметика

check_sp.py проходит346 тел по CFG, обоим исходам условий, loops и всем6 switch targets. Он проверяет постоянные изменения SP, одинаковую глубину в joins,8-byte alignment каждого вызова, restore на returns/tails и post-index ldr.w lr,[sp],#4. Все344 C maximum frames совпали с .su; dynamic stack, positive-depth cycles и рекурсия замкнутого1062-edge call/tail graph не найдены. При вычислении child maximum берётся SP depth конкретной call site; последовательные вызовы не складываются, tail depth после восстановления равна0. Некоторые несовместимые по данным ветви намеренно разрешены, поэтому оценка консервативна и не заявлена достижимой.

Максимизирующая foreground цепочка, включая persistent main frame:

main104 → runtime_step136 → receive48 → accept_frame1168 → terminate648 → live-device now16 → recover16 → raw_barrier584 → live_stop0 → live_adc_quiesce32 → stop_snapshot24 → adc_stop8 → driver quiesce24 → wait_clear24 → driver now0 → adc_time0 → timebase_now_us8 → timebase_update16 =2856 B.

HP и LP имеют одинаковую software bound264 B: IRQ tail0 → dispatch8 → DCD72 → event_handler48 → queue_event48 → FIFO write64 → hwfifo read16 → memcpy8. Conservative graph допускает и неиспользуемый здесь queue access mode path, что не уменьшает верхнюю оценку.

59 vector words закреплены в ELF: MSP0x20005000, Reset0x08008191, HP0x080057c9, LP0x080057cd,50 ссылок на Default_Handler0x080081fd и5 нулей. Default_Handler выполняет cpsid i и вечный branch, software frame0. Равноприоритетные USB IRQ не вкладываются друг в друга; внешний PRIMASK guard дополнительно исключает reentry dispatch. Максимально учтены USB→HardFault→NMI, то есть3 аппаратных входа по32 B base frame+4 B conservative alignment allowance. Tail-chaining не накапливает бесконечные кадры.

Архитектурное основание проверено по [ST PM0056 Rev7, §§2.3.5–2.3.7,2.4.2–2.4.4](https://www.st.com/resource/en/programming_manual/pm0056-stm32f10xxx20xxx21xxxl1xxxx-cortexm3-programming-manual-stmicroelectronics.pdf), pp.35–41. Не утверждается гарантия successful stacking при повреждённой SRAM/MSP.

## Исправление lexer и история неудачного свидетельства

Дополнительный аудит обнаружил reviewer-tool defect: regex4..8 hex characters проглатывал all-hex mnemonic addcc на0x08002a80 как machine bytes и пропускал uxth на0x08002a82. Старые parser/analysis evidence сохранены отдельно; они не переписаны. Исправление принимает только поля ровно4 либо8 hex characters. Явная regression проверяет addcc как2-byte instruction и посещение обеих точек. Новый полный walk имеет10 вместо9 instructions в tu_fifo_correct_read_pointer; call/tail edges и все frames не меняются. Исторический1480750b отдельно пересчитан неизменным по числу3164/3168B, но это не его перенос на данный образ. В этом r3 пакете audit_image/trace_callbacks/check_sp уже используют исправленный lexer.

## Воспроизведение и отрицательные проверки

Требуются Python3.9+ и pinned ARM objdump. Запуск из каталога пакета:

python3 -I -B verify_package.py --objdump /полный/путь/arm-none-eabi-objdump

Replay сверяет manifest и exact tool hash,30 объектов,100 dependencies,344 .su frame bindings, заново дизассемблирует ELF и выполняет6 analyses. Новые JSON результаты обязаны byte-for-byte совпасть с замороженными. Допускается нормализация только location-specific file header objdump. Каждый запуск создаёт новый каталог replays/<unique-id>, сохраняет команды, stdout/stderr, failure.json/traceback при отказе. Фиксированные входы и предыдущие попытки не перезаписываются. Рабочие analysis копии отделены от frozen evidence. Изменённый ELF нельзя принять простой автоматической заменой expected SHA: нужен новый аудит.

9 адресных analysis-only мутаций действительно отвергнуты: misalignment/frame, утрата LR post-index restore, dynamic SP write, restore beyond entry, call into literal table, unknown indirect site, wrong .su, switch outside owner и callback target outside function entry. Отдельно отвергнуты recursive edge и резерв3224 B, принят3232 B. Это проверки инструмента на копиях analysis inputs, не firmware mutants/target tests.

Все8 executable review/proof scripts до файловых операций явно отвергают -O/-OO, отсутствие -I и/или -B.42 реальных запуска, включая исторический false-PASS сценарий --objdump /usr/bin/true под -O/-OO, завершились exit2 с REJECTED_INTERPRETER_POLICY, пустым stdout и без изменения любых bytes/mtime/списка файлов. Четыре normal-interpreter negative controls (wrong tool true, missing tool, altered ELF и altered .su) завершились отказом, без PASS/stdout, и сохранили индивидуальные failure evidence. Ошибки не удаляются последующим успехом. Предыдущий uninstrumented Python -O defect не наследуется; старый отчёт и3164 B не используются как доказательство этого образа.

## Рубрика и оставшиеся ворота

C1=9.6: новая exact-image граница, owners и ABI подтверждены; условия reset/debug/stacking явно ограничивают результат.
C2=9.6: error/cleanup/terminal fault paths и diagnostic additions включены; произвольная corruption исключена открыто.
C3=9.6:346-body CFG, object .su, ABI recompile, source/tool pins, actual replay и negative controls; это не formal proof assistant и не MCU execution.
C4=9.6: конкретный source-backed callback graph, отдельные replay attempts и понятный conservative bound; новый код требует нового анализа.
C5=9.6: frozen source/dependencies/object/tool provenance и portable replay; полностью герметичный host/toolchain rebuild не заявлен.

0.30×9.6+0.20×9.6+0.25×9.6+0.15×9.6+0.10×9.6=9.60. В узкой static stack/callback/ABI области незакрытого P0/P1 не обнаружено: conditional PASS только для ELFe32461ba. Прежний first-START gap исправлен в production8c51c78024a2e1bcd1e5575ef9189737a3ddce88: BEGIN расположен в live_stop при STOPPED&&want_start до первого ADC quiesce; это не добавило root или callback registration. Функциональная приёмка исправления требует отдельного source/native заключения. Общая приёмка STREAM/прибора, qualified transaction bound, IRQ/ADC WCET/aggregate scheduling, physical memory/clock identity и flash approval остаются BLOCKED_EVIDENCE. Поля receipt stack_bound_qualified/runtime_profile_accepted/hardware_verified/flash_approved этим отчётом не изменены.

## Дополнительная независимая сверка

Дополнительный независимый board/data/descriptor/root аудит сохранён в supplemental-source-audit. Его численная оценка не использовалась: отдельный проверяющий её не выводил. Локальные absolute-path audit recipes не включены как переносимые исполняемые checkers.

## Отдельная привязка caller-board данных

Это новый exact-image proof настоящего board-specific DRAFT, а не переименование synthetic ELF. Из30 объектов только board.o отличается от r3; все29 остальных, включая runtime/diag/reset/USB/timing, одинаковы. Тем не менее заново сверены новый ELF, карта, raw disassembly, CFG, callback/switch таблицы, ABI и bound; численная одинаковость установлена повтором. Байт-идентичность firmware между31b9365 и production8c51c780 проверяется отдельно от board input.

verify_board.py при каждом portable replay читает actual PT_LOAD: mt_board48B по0x08008268 и три pointed ASCII строки, timing12B по0x080082d0. Независимый ARM board ABI probe подтверждает board48, identity20, timing12, usb offset28, enum16, DTR20, pullup24 и identity pointers8/12/16. Actual values: HSE8000000Hz/crystal, poll_budget1000000, USBpriority0, build0x53545231, require_dtr1, fixed_pullup1; VID0x1209/PID1/bcd0x0100/100mA. Строки font-weight / Motortester private LV test / AH20261017001 имеют11/27/13 printable ASCII chars, каждая≤31; serial alphanumeric. Ожидаемые USB string sizes24/56/28B укладываются в32-word persistent string buffers; power descriptor byte после успешного source-defined init равен50. Это расчёт/проверка source и initial ELF bytes, не наблюдение USB enumeration.

От diagnostic-build-evidence-20261019/board.json изменён ровноfirmware_build. Исторические6 caller_attestations=true сохранены как прежние заявления; новые подтверждения физической MCU/SRAM, HSE, pullup, USB ID authorization/power/serial не получены. Эти факты остаются внешними caller obligations. Прежние limitations и поля receipt false сохранены.1e6 poll iterations не означают дополнительный стек за итерацию и не являются WCET proof. DTR1 ограничивает разрешение app I/O, не регистрирует новый callback/root. Source-defined startup копирует bounded строки в persistent descriptors до USB init; input pointers flash-readable и не временные.

В полном bound учтены все допустимые graph branches, включая error/cleanup после выбранных board checks. Code/root/ABI модель остаётся той же по новому расчёту, только при выполнении перечисленных reset/debug/ownership/stacking условий. Никакого physical, host identity admission, flash или operator kit acceptance этот отчёт не даёт.

## Дополнительные отрицательные data checks и независимый board audit

После первичного replay лично выполнены ещё3 изолированные проверки verify_board.py: несовпадающий declared build, неверный board ABI size и изменённая historical attestation. Все отвергнуты, board-binding output не создан, stdout/stderr сохранены. Первоначальный синтаксический сбой вспомогательного ABI-рецепта произошёл до компиляции и сохранён отдельно; исправлен только reviewer helper, затем настоящий ARM probe успешно собран. У дополнительного независимого reviewer также сохранён начальный variable-shadowing failure analysis script; после исправления повтор прошёл. Эти неудачи не скрыты и не называются firmware defects.

Независимый board audit подтверждает все425/100/253 pins/30 objects/248 archive files и actual board data/строки/timing. Только board.o изменился;346code ranges,12036instructions,109indirect sites, vectors иclass table совпали сr3. Два изменившихся embedded data words отдельно объяснены: main literal0x08005938→timing0x080082d0 иReset literal0x080081e8→data LMA0x080082dc. Они не приняты за инструкции или дополнительные ветви. Отдельный reviewer не выводил численную границу; итог3228/3232 получен настоящим новым графовым расчётом здесь.
