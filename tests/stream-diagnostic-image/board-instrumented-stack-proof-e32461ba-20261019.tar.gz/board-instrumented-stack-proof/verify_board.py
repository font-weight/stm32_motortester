#!/usr/bin/env python3
"""Bind this draft caller-board declaration to exact ELF data, not hardware."""
import sys
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
 sys.stderr.write('REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n');raise SystemExit(2)
import pathlib,json,struct,hashlib
O=pathlib.Path(__file__).resolve().parent;B=O/'image';E=B/'DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf';b=E.read_bytes()
assert hashlib.sha256(b).hexdigest()=='e32461ba94ce8d105ced09dd56ee82689f4fbdc4b8c8bdb15419e74a94b807f2'
r=json.load(open(B/'receipt.json'));decl=json.load(open(B/'board-input.json'));historical=json.load(open(B/'historical-board-input.json'));expected=json.loads(json.dumps(historical));expected['board']['firmware_build']=0x53545231
assert decl==expected and decl['input_kind']=='caller_board'
assert r['board_input_kind']=='caller_board' and r['source_commit']=='31b93659164dec376bea5b973b597196c6a4a0ad'
assert all(r[k]is False for k in ['transaction_bound_qualified','stack_bound_qualified','runtime_profile_accepted','hardware_verified','flash_approved'])
assert json.load(open(O/'board-abi.json'))['abi']=={'off_identity_manufacturer':8,'size_timing':12,'off_identity_product':12,'off_board_mode':16,'off_identity_serial':16,'size_identity':20,'off_board_dtr':20,'off_board_pullup':24,'off_board_usb':28,'size_board':48}
off=struct.unpack_from('<I',b,28)[0];ent,num=struct.unpack_from('<HH',b,42);ph=[struct.unpack_from('<8I',b,off+i*ent)for i in range(num)]
def read(a,n):
 for typ,fo,v,pa,sz,mem,flags,align in ph:
  if typ==1 and v<=a and a+n<=v+sz:return b[fo+a-v:fo+a-v+n]
 raise ValueError(hex(a))
w=struct.unpack('<7I4H3I',read(0x08008268,48));assert w[:11]==(8000000,1000000,0,0x53545231,0,1,1,0x1209,1,0x0100,100)
strings={}
for key,a in zip(['manufacturer','product','serial'],w[11:]):
 s=bytearray()
 for i in range(32):
  v=read(a+i,1)[0]
  if v==0:break
  assert 32<=v<=126;s.append(v)
 else:raise AssertionError('descriptor lacks bounded terminator')
 value=s.decode('ascii');assert 0<len(value)<=31 and value==decl['board']['usb'][key]
 if key=='serial':assert value.isalnum()
 strings[key]={'address':hex(a),'value':value,'characters':len(value),'usb_string_descriptor_bytes':2+2*len(value)}
assert struct.unpack('<3I',read(0x080082d0,12))==(1,1,1)
assert decl['board']['usb']['bus_power_ma']%2==0 and 2<=decl['board']['usb']['bus_power_ma']<=500
result={'status':'EXACT_DRAFT_BOARD_DATA_BINDING_PASS','elf_sha256':hashlib.sha256(b).hexdigest(),'source_commit':r['source_commit'],'board_address':'0x8008268','board_bytes':48,'hse_hz':w[0],'clock_poll_budget':w[1],'usb_irq_priority':w[2],'firmware_build':w[3],'firmware_build_hex':hex(w[3]),'hse_mode':'crystal','require_dtr':w[5],'fixed_pullup':w[6],'vid':w[7],'pid':w[8],'bcd_device':w[9],'bus_power_ma':w[10],'strings':strings,'timing_schema_provisional_bound':[1,1,1],'descriptor_power_byte_expected_after_successful_init':50,'historical_board_difference':['board.firmware_build'],'attestations':'Historical caller declarations only; no new physical verification or authorization inferred','receipt_qualification_flags_all_false':True,'limits':['Expected descriptor fields after source-defined successful initialization, not observed physical USB enumeration','HSE/pullup/VID authorization/power/serial/MCU/SRAM remain external caller obligations','Provisional1ms declaration, not timing/WCET qualification','No target execution/export/flash approval']}
(O/'board-binding.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
