#!/usr/bin/env python3
"""Read-only exact-image inventory; NOT a whole-program stack-proof checker."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import hashlib,json,pathlib,re,subprocess,shlex,struct
O=pathlib.Path(__file__).resolve().parent
B=pathlib.Path('/tmp/stream-board-diagnostic-r1')
T=pathlib.Path('/workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/bin')
p=json.loads((B/'receipt.json').read_text())
commands=[]
def run(label,args):
 r=subprocess.run([str(x) for x in args],text=True,capture_output=True)
 commands.append({'label':label,'argv':[str(x) for x in args],'exit':r.returncode})
 (O/(label+'.stdout')).write_text(r.stdout);(O/(label+'.stderr')).write_text(r.stderr)
 if r.returncode: raise RuntimeError(label)
 return r.stdout
def sha(f):return hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
checks={}
for group in ['inputs_before','dependencies','generated']:
 mismatches=[]
 for f,h in p[group].items():
  if not pathlib.Path(f).is_file(): mismatches.append([f,'MISSING'])
  elif sha(f)!=h:mismatches.append([f,sha(f),h])
 checks[group]={'count':len(p[group]),'mismatches':mismatches}
checks['objects']={'count':len(p['objects']),'mismatches':[x for x in p['objects'] if sha(x['path'])!=x['sha256']]}
checks['elf']={'sha256':sha(B/'DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf'),'matches_receipt':sha(B/'DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf')==p['elf_audit']['elf_sha256']}
# Extract true function symbol ranges and object identities from exact linker map.
maptext=(B/'image.map').read_text(); ranges={}; pending=None
for l in maptext.splitlines():
 m=re.match(r'^ (\.text(?:\.\S+)?)\s*$',l)
 if m:pending=m.group(1);continue
 m=re.match(r'^ (\.text(?:\.\S+)?)\s+(0x[0-9a-f]+)\s+(0x[0-9a-f]+)\s+(\S+\.o)$',l)
 if m:sec,addr,size,obj=m.groups()
 else:
  m=re.match(r'^\s+(0x[0-9a-f]+)\s+(0x[0-9a-f]+)\s+(\S+\.o)$',l)
  if not (m and pending):continue
  addr,size,obj=m.groups();sec=pending
 pending=None
 if int(size,16):ranges[int(addr,16)]={'section':sec,'size':int(size,16),'object':obj}
frames={}; unmapped=[]
for f in (B/'objects').glob('*.su'):
 rows={}
 for l in f.read_text().splitlines():
  head,n,kind=l.split('\t');name=head.rsplit(':',1)[1];rows[name]=(int(n),kind,head)
 obj=str(f.with_suffix('.o'))
 for addr,x in ranges.items():
  if x['object']!=obj:continue
  name=x['section'][6:]
  candidates=[name,name.removeprefix('startup.'),re.sub(r'\.(isra|constprop)\.\d+',r'.\1',name)]
  matched=next((rows[z] for z in candidates if z in rows),None)
  if matched:frames[addr]={'name':name,'bytes':matched[0],'kind':matched[1],'source':matched[2],'object':obj}
  else:unmapped.append([hex(addr),name,obj])
dis=(O/'final.dis').read_text(); funcs={}; fn=None
for l in dis.splitlines():
 m=re.match(r'^([0-9a-f]+) <([^>]+)>:$',l)
 if m:fn=int(m[1],16);funcs[fn]={'name':m[2],'instructions':[]};continue
 m=re.match(r'^\s*([0-9a-f]+):\s+(?:(?:[0-9a-f]{4}|[0-9a-f]{8})\s+)+\s*([^\s]+)\s*(.*)$',l)
 if m and fn is not None and not m[2].startswith('.'):funcs[fn]['instructions'].append((int(m[1],16),m[2],m[3]))
indirect=[];jumps=[];edges=[];returns=[]
for a,f in funcs.items():
 for addr,op,args in f['instructions']:
  if op=='blx' or op=='bx' and args.strip() not in ('lr','r14'):
   indirect.append({'site':hex(addr),'function':f['name'],'owner':hex(a),'op':op,'args':args})
  if op in ('tbb','tbh') or op in ('ldr','ldr.w','mov','mov.w') and args.startswith('pc,'):
   dest=returns if '[sp]' in args else jumps
   dest.append({'site':hex(addr),'function':f['name'],'op':op,'args':args})
  if op=='bl' or re.fullmatch(r'b(?:\.[nw])?',op):
   m=re.match(r'([0-9a-f]+) <',args)
   if m and int(m[1],16) in funcs and int(m[1],16)!=a:
    edges.append({'from':hex(a),'from_name':f['name'],'site':hex(addr),'to':hex(int(m[1],16)),'to_name':funcs[int(m[1],16)]['name'],'kind':'call' if op=='bl' else 'tail'})
# Independent ABI probe, exact runtime compiler flags and headers, never linked.
probe='''#include "mt_live_runtime.h"\n#include "mt_stream_diag.h"\n#include "mt_board_inputs.h"\n#include <stddef.h>\n#define SIZE(n,t) const unsigned char n[sizeof(t)]={0}\n#define OFF(n,t,m) const unsigned char n[offsetof(t,m)+1]={0}\nSIZE(size_diag_record,mt_stream_diag_record);SIZE(size_runtime,mt_live_runtime);SIZE(size_device,mt_live_device);SIZE(size_adc,mt_adc_dma_t);SIZE(size_acquisition,mt_live_adc);SIZE(size_live_clock,mt_live_clock);SIZE(size_live_io,mt_live_io);SIZE(size_epoch,mt_usb_epoch);SIZE(size_snapshot,mt_live_snapshot);SIZE(size_guard,mt_adc_dma_start_guard);\nOFF(off_runtime_adc,mt_live_runtime,adc);OFF(off_runtime_device,mt_live_runtime,device);OFF(off_runtime_acquisition,mt_live_runtime,acquisition);OFF(off_runtime_clock64,mt_live_runtime,clock64);OFF(off_runtime_clock,mt_live_runtime,clock);OFF(off_runtime_mmio,mt_live_runtime,mmio);OFF(off_runtime_carry,mt_live_runtime,carry);\nOFF(off_live_context,mt_live_io,context);OFF(off_live_clock,mt_live_io,clock_ms);OFF(off_live_start,mt_live_io,start);OFF(off_live_quiesce,mt_live_io,quiesce);OFF(off_live_write,mt_live_io,write);OFF(off_live_isolate,mt_live_io,isolate_tx);OFF(off_live_bound,mt_live_io,transaction_bound_ms);OFF(off_live_build,mt_live_io,firmware_build);\nOFF(off_dma_samples,mt_adc_dma_t,dma_samples);OFF(off_dma_snapshot,mt_adc_dma_t,snapshot);OFF(off_dma_io,mt_adc_dma_t,io);OFF(off_acquisition_guard,mt_live_adc,guard);OFF(off_stop_scratch,mt_live_adc,stop_scratch);\n'''
# Name follows actual header, not an assumed storage field.
h=(B/'source/firmware/platform/adc_timer_dma.h').read_text()
# ABI offsets derive from this source snapshot
(O/'abi_probe.c').write_text(probe)
a=next(x['argv'] for x in p['commands'] if x['label']=='compile-21-mt_live_runtime')[:]
a=a[:a.index('-MD')]+['-c',str(O/'abi_probe.c'),'-o',str(O/'abi_probe.o')]
run('compile-abi-probe',a)
ns=run('abi-probe-nm',[T/'arm-none-eabi-nm','-S','--size-sort',O/'abi_probe.o'])
abi={}
for l in ns.splitlines():
 m=re.match(r'\S+\s+([0-9a-f]+)\s+\S\s+(\S+)',l)
 if m:abi[m[2]]=int(m[1],16)-(1 if m[2].startswith('off_') else 0)
# Recover compiled macros rather than trusting header alone.
a=next(x['argv'] for x in p['commands'] if x['label']=='compile-12-usbd')[:]
a=a[:a.index('-MD')]+['-dM','-E',str(B/'patched/usbd.c')]
run('usbd-compiled-macros',a)
for x in p['commands']:
 if x['label'] in ['input-audit','elf-audit']:
  run('repeat-'+x['label'],x['argv'])
result={'scope':'Inventory and ABI probe only; no qualified total stack bound','pins':checks,'function_ranges':len(ranges),'code_ranges':{hex(a):v for a,v in ranges.items()},'frames':{hex(a):v for a,v in frames.items()},'frame_mapping_missing':unmapped,'nonstatic_frames':[x for x in frames.values() if x['kind']!='static'],'indirect_calls_and_tails':indirect,'computed_switch_sites':jumps,'stack_pop_returns':returns,'direct_edges':edges,'abi':abi}
(O/'inventory.json').write_text(json.dumps(result,indent=2)+'\n');(O/'audit-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'pins':checks,'mapped_frames':len(frames),'missing':unmapped,'indirect_sites':len(indirect),'switch_sites':len(jumps),'direct_edges':len(edges),'abi':abi},indent=2))
