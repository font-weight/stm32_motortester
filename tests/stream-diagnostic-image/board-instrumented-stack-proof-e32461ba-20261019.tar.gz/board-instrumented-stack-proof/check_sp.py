#!/usr/bin/env python3
"""Supplemental constant-SP CFG checks. Does not issue a total-stack certificate."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,json,re,collections
O=pathlib.Path(__file__).resolve().parent
inv=json.loads((O/'inventory.json').read_text());cb=json.loads((O/'callback-analysis.json').read_text())
F={int(a,16):dict(v,name=v['section'][6:].removeprefix('startup.'),ins={}) for a,v in inv['code_ranges'].items()}
for l in (O/'final.dis').read_text().splitlines():
 m=re.match(r'^\s*([0-9a-f]+):\s+((?:(?:[0-9a-f]{4}|[0-9a-f]{8})\s+)+)\s*([^\s]+)\s*(.*)$',l)
 if not m or m[3].startswith('.'):continue
 a=int(m[1],16);o=next((k for k,v in F.items()if k<=a<k+v['size']),None)
 if o is not None:F[o]['ins'][a]=(m[3],m[4],len(''.join(m[2].split()))//2)
switches={int(q['site'],16):[int(t,16)for t in q['targets']]for q in cb['switch_tables']}
indirect={int(q['site'],16):q for q in cb['callback_sites']}
issues=[];results=[];call_sites=[]
def issue(fn,a,why):issues.append({'function':F[fn]['name'],'site':hex(a),'reason':why})
def regcount(args):return len(re.search(r'\{([^}]+)\}',args)[1].split(','))
for start,f in F.items():
 queue=[(start,0)];seen={};maxdepth=0;returns=0
 while queue:
  a,d=queue.pop()
  if a in seen:
   if d!=seen[a]:issue(start,a,f'inconsistent SP depths {d} and {seen[a]}')
   continue
  seen[a]=d
  if a not in f['ins']:issue(start,a,'control reaches data/non-instruction/outside section');continue
  op,args,sz=f['ins'][a];n=a+sz;d2=d;returning=False;succ=[]
  if op=='push' or op=='stmdb' and args.startswith('sp!'):d2+=4*regcount(args)
  elif op=='pop' or op=='ldmia.w' and args.startswith('sp!'):
   d2-=4*regcount(args);returning=bool(re.search(r'\bpc\b',args))
  elif op in ['sub','sub.w','subw','add','add.w','addw'] and args.startswith('sp,'):
   m=re.search(r'#(\d+)',args)
   if not m:issue(start,a,'nonconstant SP change');continue
   d2+=int(m[1])*(1 if op.startswith('sub')else -1)
  elif op in ['ldr','ldr.w'] and re.match(r'\w+, \[sp\], #\d+',args):
   d2-=int(re.search(r'#(\d+)',args)[1]);returning=args.startswith('pc,')
  elif re.search(r'\[sp[^]]*\]!|\[sp\],',args):issue(start,a,'unsupported SP writeback')
  elif args.startswith('sp,')or args.startswith('sp!'):
   if op!='stmia.w':issue(start,a,'unsupported SP write')
  if d2<0:issue(start,a,'SP restored beyond entry')
  maxdepth=max(maxdepth,d2)
  if op in ['bl','blx']:
   if d%8:issue(start,a,f'call SP is not 8-byte aligned (depth {d})')
   if op=='bl':targets=[int(re.match(r'([0-9a-f]+)',args)[1],16)]
   else:targets=[int(t['address'],16)for t in indirect[a]['targets']]
   for t in targets:
    if t not in F:issue(start,a,f'call target not code entry {hex(t)}')
    call_sites.append({'owner':hex(start),'site':hex(a),'depth':d,'target':hex(t),'kind':'call'})
   succ=[n]
  elif op=='bx':
   if d2!=0:issue(start,a,f'BX exit keeps stack depth {d2}')
   if args.strip()=='lr':returns+=1
   else:
    for t in indirect[a]['targets']:call_sites.append({'owner':hex(start),'site':hex(a),'depth':d2,'target':t['address'],'kind':'tail'})
  elif returning:
   if d2!=0:issue(start,a,f'return keeps stack depth {d2}')
   returns+=1
  elif a in switches:succ=switches[a]
  elif re.fullmatch(r'b(?:eq|ne|cs|cc|hs|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le)?(?:\.[nw])?',op) or op in ['cbz','cbnz']:
   t=int(re.search(r'([0-9a-f]+) <',args)[1],16)
   if t in f['ins']:succ.append(t)
   elif t in F:
    if d2!=0:issue(start,a,f'tail branch retains stack depth {d2}')
    call_sites.append({'owner':hex(start),'site':hex(a),'depth':d2,'target':hex(t),'kind':'tail'})
   else:issue(start,a,'branch not to instruction or function entry')
   if op not in ['b','b.n','b.w']:succ.append(n)
  else:
   # Other pc uses are ordinary PC-relative data/ADR. Reject unclassified PC writes.
   if args.startswith('pc,')or re.search(r'\bpc\}',args):issue(start,a,'unclassified PC write')
   succ=[n]
  for nxt in succ:queue.append((nxt,d2))
 # Regression: exact halfword/word fields must not consume all-hex mnemonics.
 if 0x8002a80 in f['ins']:
  assert f['ins'][0x8002a80]==('addcc','r3, r3, r2',2)
  assert 0x8002a80 in seen and 0x8002a82 in seen
 expected=inv['frames'].get(hex(start),{}).get('bytes',0)
 if maxdepth!=expected:issue(start,start,f'CFG frame maximum {maxdepth} differs from .su/ASM {expected}')
 results.append({'address':hex(start),'name':f['name'],'max_frame':maxdepth,'expected':expected,'instructions_visited':len(seen),'returns':returns})
out={'status':'SUPPLEMENTAL_SP_CFG_CHECK_ONLY','issues':issues,'functions':results,'call_sites':call_sites,'numeric_stack_bound':None,'limits':['No independently reviewed checker/mutation qualification','Callback/excluded-path assumptions are inherited from explicit registration inventory','Exception/preemption composition and margin not certified by this checker']}
(O/'sp-cfg-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'functions':len(results),'call_sites':len(call_sites),'issues':issues,'numeric_stack_bound':None},indent=2))

if issues: raise SystemExit(1)
