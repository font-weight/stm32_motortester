#include "mt_live_runtime.h"
#include "mt_stream_diag.h"
#include "mt_board_inputs.h"
#include <stddef.h>
#define SIZE(n,t) const unsigned char n[sizeof(t)]={0}
#define OFF(n,t,m) const unsigned char n[offsetof(t,m)+1]={0}
SIZE(size_diag_record,mt_stream_diag_record);SIZE(size_runtime,mt_live_runtime);SIZE(size_device,mt_live_device);SIZE(size_adc,mt_adc_dma_t);SIZE(size_acquisition,mt_live_adc);SIZE(size_live_clock,mt_live_clock);SIZE(size_live_io,mt_live_io);SIZE(size_epoch,mt_usb_epoch);SIZE(size_snapshot,mt_live_snapshot);SIZE(size_guard,mt_adc_dma_start_guard);
OFF(off_runtime_adc,mt_live_runtime,adc);OFF(off_runtime_device,mt_live_runtime,device);OFF(off_runtime_acquisition,mt_live_runtime,acquisition);OFF(off_runtime_clock64,mt_live_runtime,clock64);OFF(off_runtime_clock,mt_live_runtime,clock);OFF(off_runtime_mmio,mt_live_runtime,mmio);OFF(off_runtime_carry,mt_live_runtime,carry);
OFF(off_live_context,mt_live_io,context);OFF(off_live_clock,mt_live_io,clock_ms);OFF(off_live_start,mt_live_io,start);OFF(off_live_quiesce,mt_live_io,quiesce);OFF(off_live_write,mt_live_io,write);OFF(off_live_isolate,mt_live_io,isolate_tx);OFF(off_live_bound,mt_live_io,transaction_bound_ms);OFF(off_live_build,mt_live_io,firmware_build);
OFF(off_dma_samples,mt_adc_dma_t,dma_samples);OFF(off_dma_snapshot,mt_adc_dma_t,snapshot);OFF(off_dma_io,mt_adc_dma_t,io);OFF(off_acquisition_guard,mt_live_adc,guard);OFF(off_stop_scratch,mt_live_adc,stop_scratch);
