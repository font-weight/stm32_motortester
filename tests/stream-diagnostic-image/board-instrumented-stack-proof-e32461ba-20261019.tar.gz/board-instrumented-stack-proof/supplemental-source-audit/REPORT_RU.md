# Exact caller-board DRAFT: независимый source/data/root аудит r1

## Результат и граница

**PASS для узкой подготовки exact caller-board DRAFT:** source/object provenance, реальное linked board data, descriptor inputs, callback initialization, root/preemption delta и времена жизни проверены. Это самостоятельный board-specific image, а не переименованный synthetic ELF. Численную границу стека родитель проверяет отдельно; здесь она не вычислялась.

**Новых физических attestations, проверки платы, разрешения на flash/export или operator kit нет.** Флаги caller JSON перенесены из исторического ввода и не считаются новым аппаратным свидетельством. Общая аппаратная/STREAM/timing приёмка не закрыта. Проверяющий production не реализовывал и не изменял. Production compile/link, MCU execution, BIN/HEX, публикация и flash не выполнялись; собран только независимый ABI-only probe без линковки.

## Точная привязка

Source receipt: `31b93659164dec376bea5b973b597196c6a4a0ad`; firmware байт-в-байт идентично production commit `8c51c78024a2e1bcd1e5575ef9189737a3ddce88`.

ELF: `/tmp/stream-board-diagnostic-r1/DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf`.
SHA256: `e32461ba94ce8d105ced09dd56ee82689f4fbdc4b8c8bdb15419e74a94b807f2`.

Лично проверены425 input pins,100 dependencies,253 generated pins,30 ordered object SHA. Source.tar SHA256 `ce41c092c2ed84e6c023bc5c00a157d060db8ba7beee04b87ab59386e2fa7aa8`: все248 regular files совпадают с immutable compiled git archive,74 source dependencies совпадают с их hashes. Результат не зависит от текущего editable checkout.

От synthetic r3 изменился только `board.o`: SHA256 `6d73acfda06e45385317ce14a8203714b6a03d82068cbd9c0d72a2ea9df37096`. Остальные29 объектов, включая весь код, reset/CPU/IRQ, runtime/ADC/TIME/USB/DCD/diag и timing.o, тождественны r3. Source/compile flags/config не менялись.

## Происхождение и точные board values

Исторический input: `diagnostic-build-evidence-20261019/board.json`, SHA256 `2e3bc800eadd9475c21b43c499c8abbb62c24e7a37b362ed49c502e2e7e361bb`. Скопированный `stream-board-diagnostic-draft-20261019/board-input.json` и фактический build input совпадают; единственное изменение исторического JSON — firmware_build=`0x53545231` (1398034993). Caller attestations неизменны. PROVENANCE.md прямо не заявляет повторной физической проверки.

Независимый ARM probe подтвердил48-byte board ABI,20-byte USB identity и каждый field offset. Финальный ELF прочитан по actual PT_LOAD/symbol address; `mt_board` расположен по0x08008268 и содержит ровно:

- HSE8000000Hz, crystal; clock_poll_budget1000000
- USB IRQ priority0, require_dtr1, fixed_pullup1
- firmware_build0x53545231
- VID0x1209/PID0x0001, bcdDevice0x0100, declared bus power100mA
- manufacturer `font-weight`, product `Motortester private LV test`, serial `AH20261017001`

Три pointers разрешились в Flash: manufacturer0x080082c2, product0x080082a6, serial0x08008298; строки NUL-terminated,11/27/13 printable ASCII characters, serial alphanumeric, граница31 не превышена. Числовые данные и строки сверены с input, а не только с source generator text.

От synthetic изменились HSE4.5→8MHz, poll budget1→1000000, DTR0→1, build/USB identity/power/strings. Priority0, crystal, fixed pullup1, STREAM profile, instrumentation и8192-byte reservation сохранились. Эти declared values сами не удостоверяют фактические HSE, pullup, MCU/memory, power, VID/PID rights или физическую уникальность serial.

## Дескрипторы и lifetime

Проверены unchanged `firmware/transport/mt_usb_descriptors.c/.h` и main initialization order. Identity валидируется целиком до публикации; VID допустим, bcdDevice имеет BCD digits, power чётное2..500mA. Main вызывает descriptor init до tusb_init и IRQ admission. Строки копируются в отдельные persistent static UTF-16 buffers; callback pointers на device/configuration/strings не заимствуют временный initializer и не инвалидируются следующим descriptor callback. Повторная live initialization запрещена.

В `board-source-audit.json` сохранены вычисленные из linked inputs и unchanged source ожидаемые device/configuration/string bytes. Это **source-derived prediction, не enumeration/target execution**. Device descriptor18B, configuration75B,1 configuration/2 interfaces/1 CDC; control endpoint64B, notification0x81/8B, bulk OUT0x02/64B и IN0x82/64B. Declared100mA дают bMaxPower50 в2mA units. Число не является измерением потребления.

Новые board fields не содержат function pointers. Struct хранит только scalar configuration и pointers на const strings. Callback constructors/runtime IO, class driver и lock/ADC callbacks не изменились. DTR1 включает существующую проверку connected; дополнительного callback owner, ISR или background writer нет. Больший poll budget меняет допустимое число boot polls, но не добавляет recursion/dynamic allocation; timing гарантией он не объявляется.

## Machine/root delta

Лично получены свежие objdump/nm/readelf. Независимый exact4|8 parser, не поглощающий all-hex mnemonics, проверил346 code ranges и12036 instructions. Layout каждого code range и все instruction bytes/opcodes/operands совпали с r3. Все109 indirect sites совпали с source-backed registrations; fresh board-r1 callback-spec также точно совпал. Единственная CDC class table36B, её9 pointer words и все59 vector words совпали с r3.

Внутри code input sections изменились ровно два embedded literal words, не инструкции:

- main по0x08005938: timing pointer0x080082c8→0x080082d0
- Reset по0x080081e8: data load address0x080082d4→0x080082dc

Оба лично сверены с новым linked timing symbol и actual .data PT_LOAD physical address. Рост readonly board strings на8B сдвинул timing/data load; сброс не оставлен со старым source address. Других raw byte changes внутри code ranges нет.

Из USB HP/LP и Default roots diagnostic bodies недостижимы; все10 diagnostic bodies остаются foreground Reset/main paths. Runtime/ADC/snapshot/record storage и sret/frame instructions не менялись. В частности: live_stop сохраняет snapshot вr5, восстанавливает16-byte frame перед quiesce tail; runtime_step epoch sret SP+48..95, saved registers с100; diag record136B не содержит pointers и остаётся[0x2000238c,0x20002414).

## Предпосылки preemption и открытые ворота

Настоящий reset, privileged Thread/MSP, VTOR/STKALIGN и CPU admission checks сохраняются. HP19 и LP20 имеют одинаковый priority0; main/boot конечные проверки ISER и priorities неизменны. Полный USB dispatcher окружён настоящим PRIMASK save/restore. Configurable IRQ не добавлены. Terminal Default handler по-прежнему не имеет software frame.

Применимость условной stack/root модели требует отсутствия RTOS, SysTick/DMA/timer/debug-monitor ISR, посторонних peripheral owners, внешнего debug/instrumentation/изменений priorities/vectors и произвольного memory corruption. Требуются успешный architectural stacking и фактически доступная SRAM. DWT debug-state предпосылки и debugger/modulo timing limits не отменены caller_board input. Копирование historical attestations не доказывает эти условия на железе.

Receipt остаётся DIAGNOSTIC_LINK_ONLY_NOT_QUALIFIED, input_kind=caller_board, foreground-dwt-v1; provisional transaction1ms и reserve8192B. transaction_bound_qualified, stack_bound_qualified, runtime_profile_accepted, hardware_verified, flash_approved — всеfalse. Target TX/IRQ WCET, aggregate scheduling, ADC deadlines/physical stream, board identity/safety и физическая приёмка остаются отдельно открыты. Новый image всё равно требует собственного exact graph/stack review, независимо от тождества instruction graph.

## Проверки verifier и артефакты

`audit_board.py` имеет pre-filesystem optimize/isolation/no-bytecode guard. Нормальный-I-B запуск прошёл. Пять реальных denied modes (-I-B-O, -I-B-OO, только-B, только-I, без flags) далиexit2, пустой stdout и точный REJECTED_INTERPRETER_POLICY stderr.567 file/directory entries audit иexact build directories неизменны до/после каждого denied call по paths/mode/mtime/size/hash.

Первый вспомогательный запуск встретил локальную ошибку checker variable naming, затенявшую builtin ord. Она исправлена только в analysis script; исходный traceback/stdout сохранены в audit-first.stderr/stdout. Ошибка не была представлена как PASS и production не затрагивала. Затем нормальная полная проверка прошла дважды.

Замораживаемые результаты: `board-source-audit.json`, `board-abi.json`, `interpreter-policy-controls.json`, этот отчёт. Локальный recipe/probe/stdout/disassembly сохраняются для трассировки, не выдаются за portable replay. До отдельно завершённого родительского stack proof и общей приёмки вывод ограничен source/data/root подготовкой этого точного DRAFT.
