#!/usr/bin/env python3
"""Exact-image conditional static upper bound. No target/WCET/flash certificate."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,json,hashlib,struct,collections,copy
O=pathlib.Path(__file__).resolve().parent;B=O/'image'
EXPECTED_ELF='e32461ba94ce8d105ced09dd56ee82689f4fbdc4b8c8bdb15419e74a94b807f2'
EXPECTED_DIS='f14413654c0f96f4f16efe0295716fb7e99c5b48f37c9d1789a9b3ff96ee7367'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf')==EXPECTED_ELF
assert sha(O/'final.dis')==EXPECTED_DIS
assert sha(B/'image.map')=='d92045bc6b9cb98a11f2fa4b965506140510ef54bd67642eab787ecc6e0f7c11'
assert sha(B/'original_builder.py')=='eabfdfaf38a09ae260955be9252d9212d62bff321801b5c4c729196ae9909a41'
x=json.loads((O/'sp-cfg-analysis.json').read_text());cb=json.loads((O/'callback-analysis.json').read_text());inv=json.loads((O/'inventory.json').read_text());controls=json.loads((O/'rejecting-controls.json').read_text())
assert not x['issues'] and not cb['dag_cycles'] and not inv['frame_mapping_missing'] and not inv['nonstatic_frames']
assert len(x['functions'])==346 and len(x['call_sites'])==1062 and len(cb['callback_sites'])==109 and len(cb['switch_tables'])==6
assert json.loads((O/'board-binding.json').read_text())['elf_sha256']==EXPECTED_ELF
assert len(controls)==9 and all(c['rejected']for c in controls)
assert all(not inv['pins'][k]['mismatches']for k in ['objects','dependencies','generated'])
# Whole image is pinned, plus explicit salient constructor and vector words.
b=(B/'DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf').read_bytes();off=struct.unpack_from('<I',b,28)[0];ent,num=struct.unpack_from('<HH',b,42);ph=[struct.unpack_from('<8I',b,off+i*ent)for i in range(num)]
def read(a,n):
 for typ,fo,v,pa,sz,mem,flags,align in ph:
  if typ==1 and v<=a and a+n<=v+sz:return b[fo+a-v:fo+a-v+n]
 raise ValueError(hex(a))
assert struct.unpack_from('<I',b,36)[0]==0x5000200
vectors=list(struct.unpack('<59I',read(0x8000000,236)))
assert vectors[0:4]==[0x20005000,0x8008191,0x80081fd,0x80081fd]
assert vectors[35:37]==[0x80057c9,0x80057cd]
assert collections.Counter(vectors)==collections.Counter({0x20005000:1,0x8008191:1,0x80081fd:50,0:5,0x80057c9:1,0x80057cd:1})
assert list(struct.unpack('<9I',read(0x8008224,36)))==[0,0x8002cc1,0x8002d19,0x8002d1d,0x8002d45,0x8002e5d,0x8002f05,0,0]
assert list(struct.unpack('<12I',read(0x800622c,48)))==[0x8005cb9,0x8005cc7,0x8005d41,0x8005cf7,0x8005e23,0x8005cfb,0x8005e73,0x8005d37,0x8005e49,0x8005d01,0x8005ea9,0x8005e03]
assert struct.unpack('<I',read(0x20000060,4))[0]==0x8003091
assert struct.unpack('<I',read(0x20000074,4))[0]==0x8003091
F={f['address']:f for f in x['functions']}
def maxima(sites):
 edges=collections.defaultdict(list)
 for e in sites:
  assert e['owner']in F and e['target']in F
  edges[e['owner']].append(e)
 cache={}
 def walk(a,trail=()):
  assert a not in trail,('recursion',trail+(a,))
  if a in cache:return cache[a]
  best={'bytes':F[a]['max_frame'],'path':[{'function':F[a]['name'],'address':a,'own_depth':F[a]['max_frame']}]}
  for e in edges[a]:
   child=walk(e['target'],trail+(a,));n=e['depth']+child['bytes']
   if n>best['bytes']:best={'bytes':n,'path':[{'function':F[a]['name'],'address':a,'site':e['site'],'own_depth':e['depth'],'kind':e['kind']}]+child['path']}
  cache[a]=best;return best
 for a in F:walk(a)
 return {f['name']:cache[a]for a,f in F.items()if f['name']in ['main','Reset_Handler','USB_HP_CAN1_TX_IRQHandler','USB_LP_CAN1_RX0_IRQHandler','Default_Handler','mt_live_runtime_step'] or f['name'].startswith('mt_stream_diag_')}
m=maxima(x['call_sites']);fg=m['Reset_Handler']['bytes'];irq=max(m['USB_HP_CAN1_TX_IRQHandler']['bytes'],m['USB_LP_CAN1_RX0_IRQHandler']['bytes'])
assert m['Default_Handler']['bytes']==0
exception_allowance=3*(8*4+4);bound=fg+irq+exception_allowance;rounded=(bound+7)//8*8
assert (fg,irq,bound,rounded)==(2856,264,3228,3232)
def reserve_ok(n):return n%8==0 and n>=rounded
assert reserve_ok(8192)and not reserve_ok(3224)and reserve_ok(3232)
# DAG rejecting control, separate from binary pins.
mut=copy.deepcopy(x['call_sites']);mut.append({'owner':'0x80057d8','target':'0x80057d8','site':'0x8005c16','depth':104,'kind':'call'})
try:maxima(mut)
except AssertionError:cycle_rejected=True
else:raise AssertionError('recursion control was not rejected')
result={'status':'CONDITIONAL_EXACT_IMAGE_STATIC_STACK_BOUND','elf_sha256':EXPECTED_ELF,'source_commit':'31b93659164dec376bea5b973b597196c6a4a0ad','reviewed_head':'31b93659164dec376bea5b973b597196c6a4a0ad','instrumentation_profile':'foreground-dwt-v1','foreground_bytes':fg,'usb_software_bytes':irq,'exception_levels':3,'exception_bytes_each_conservative':36,'total_upper_bound_bytes':bound,'eight_byte_reservation_minimum':rounded,'existing_reserve_bytes':8192,'arithmetic_headroom_vs_rounded_bound':8192-rounded,'roots':m,'recursion_control_rejected':cycle_rejected,'insufficient_reserve_control_rejected':not reserve_ok(3224),'assumptions':['Exact code/data/initialization/callback registration and root set reviewed here','Real system reset, privileged Thread/MSP, no bootloader handoff, STKALIGN enabled','Only USB HP/LP configurable IRQ roots, same hardware priority, actual outer PRIMASK guard','NMI and HardFault terminate in zero-software-frame Default_Handler','Architecturally successful exception stacking/unstacking and valid SRAM; no stack corruption, erroneous DMA or arbitrary control/data corruption','No external debugger/trace/DebugMonitor configuration, RTOS, foreign ISR, concurrent diagnostic writer or runtime code/priority changes; reviewed foreground DWT instrumentation only'],'not_established':['Attained physical high-water mark','Target execution or hardware verification','TX/IRQ/ADC WCET and aggregate traffic/service bounds','Physical memory identity or device/stream acceptance','Engineering sufficiency of arbitrary future margin or flash approval']}
(O/'static-bound.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='roots'},indent=2))
