#!/usr/bin/env python3
"""Explicit source/registration-backed graph inventory. Not an accepted proof."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import json,pathlib,re,struct,collections
O=pathlib.Path(__file__).resolve().parent; x=json.loads((O/'inventory.json').read_text()); dis=(O/'final.dis').read_text()
# Partition by linker input code ranges, not objdump labels: discarded weak
# symbol names leave three retained anonymous function bodies; rodata lives in
# output .text too and must never be mistaken for executable functions.
F={int(a,16):{'name':v['section'][6:].removeprefix('startup.'),'size':v['size'],'ins':[]} for a,v in x['code_ranges'].items()}
byname={}
for l in (O/'final.nm').read_text().splitlines():
 m=re.match(r'([0-9a-f]+)\s+([0-9a-f]+)\s+[tTwW]\s+(\S+)',l)
 if m:byname.setdefault(m[3],[]).append(int(m[1],16))
for l in dis.splitlines():
 m=re.match(r'^\s*([0-9a-f]+):\s+(?:(?:[0-9a-f]{4}|[0-9a-f]{8})\s+)+\s*([^\s]+)\s*(.*)$',l)
 if m and not m[2].startswith('.'):
  a=int(m[1],16)
  owners=[st for st,f in F.items() if st<=a<st+f['size']]
  if owners:F[owners[0]]['ins'].append((a,m[2],m[3]))
def target(n):
 assert len(byname[n])==1,(n,byname[n]);return hex(byname[n][0])
spec=json.loads((O/'callback-spec.json').read_text())
assert set(spec)==set(q['site']for q in x['indirect_calls_and_tails']), 'incomplete callback site census'
for q in x['indirect_calls_and_tails']:
 rule=spec[q['site']]
 assert all(q[k]==rule[k]for k in ['function','owner','op','args']),q
 q['targets']=[{'address':target(n),'name':n}for n in rule['target_names']]
 q['excluded_reason']=rule['excluded_reason']
 assert bool(q['targets']) != bool(q['excluded_reason']),q
# All direct external conditional/unconditional branches must also be edges.
E=[]
for a,f in F.items():
 for site,op,arg in f['ins']:
  if not re.fullmatch(r'(?:bl|b(?:eq|ne|cs|cc|hs|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le)?)(?:\.[nw])?',op):continue
  m=re.match(r'([0-9a-f]+) <',arg)
  if m:
   t=int(m[1],16)
   if t!=a and t in F:E.append((a,t,site,'call'if op=='bl'else'tail'))
for q in x['indirect_calls_and_tails']:
 for t in q['targets']:E.append((int(q['owner'],16),int(t['address'],16),int(q['site'],16),'indirect_'+q['op']))
# Check static data bytes directly from PT_LOAD.
b=(O/'image/DIAGNOSTIC_INSTRUMENTED_NEVER_FLASH.elf').read_bytes();off=struct.unpack_from('<I',b,28)[0];ent,num=struct.unpack_from('<HH',b,42);ph=[struct.unpack_from('<8I',b,off+i*ent)for i in range(num)]
def read(a,n):
 for typ,fo,v,pa,sz,mem,flags,align in ph:
  if typ==1 and v<=a and a+n<=v+sz:return b[fo+a-v:fo+a-v+n]
 raise ValueError(hex(a))
tables=[]
for site,base,count,size,owner in [(0x8001b02,0x8001b06,7,1,0x8001af4),(0x8002ee4,0x8002ee8,4,4,0x8002e5c),(0x8003410,0x8003414,6,1,0x80033ec),(0x800399e,0x80039a2,8,2,0x80038d8),(0x8003a96,0x8003a9c,10,4,0x80038d8),(0x8003c62,0x8003c68,15,4,0x80038d8)]:
 vals=struct.unpack('<'+{1:'B',2:'H',4:'I'}[size]*count,read(base,count*size));targets=[v&~1 if size==4 else site+4+v*2 for v in vals];valid=set(i[0]for i in F[owner]['ins']);assert all(t in valid for t in targets),(hex(site),targets)
 tables.append({'site':hex(site),'base':hex(base),'count':count,'width':size,'targets':[hex(t)for t in targets],'all_targets_inside_owner':True})
# Exact object/linked symbol frame matching, and constant stack-decrement census.
frame_checks=[]
for a,f in F.items():
 if hex(a) not in x['frames']:continue
 negatives=[]
 for site,op,args in f['ins']:
  if op=='push' or op=='stmdb' and args.startswith('sp!'):
   regs=re.search(r'\{([^}]+)\}',args)[1].split(',');negatives.append((site,4*len(regs)))
  elif op in ['sub','sub.w','subw'] and args.startswith('sp,'):
   m=re.search(r'#(\d+)',args);assert m,(hex(site),args);negatives.append((site,int(m[1])))
  elif op in ['str','str.w'] and re.match(r'\w+, \[sp, #-\d+\]!',args):negatives.append((site,int(re.search(r'#-(\d+)',args)[1])))
 total=sum(n for site,n in negatives);expected=x['frames'][hex(a)]['bytes']
 frame_checks.append({'function':f['name'],'address':hex(a),'su':expected,'sum_static_decrements':total,'agree':expected==total,'decrement_sites':[hex(s)for s,n in negatives]})
# Structural DAG check. The maximum remains intentionally unreported: this is not
# an exhaustive SP-state/return/call-alignment and path-feasibility proof.
adj=collections.defaultdict(set)
for a,t,s,k in E:adj[a].add(t)
cycles=[];active=[];done=set()
def visit(a):
 if a in active:cycles.append([hex(t)for t in active[active.index(a):]+[a]]);return
 if a in done:return
 active.append(a)
 for t in adj[a]:visit(t)
 active.pop();done.add(a)
for a in F:visit(a)
roots=[byname[n][0]for n in ['Reset_Handler','USB_HP_CAN1_TX_IRQHandler','USB_LP_CAN1_RX0_IRQHandler','Default_Handler']];reach=set()
def reachwalk(a):
 if a in reach:return
 reach.add(a)
 for t in adj[a]:reachwalk(t)
for a in roots:reachwalk(a)
output={'status':'SUPPLEMENTAL_STATIC_INVENTORY_NOT_STACK_QUALIFICATION','callback_sites':x['indirect_calls_and_tails'],'switch_tables':tables,'frame_checks':frame_checks,'dag_cycles':cycles,'reachable_functions':len(reach),'all_functions':len(F),'edges':len(E),'root_names':[F[a]['name']for a in roots],'unreachable_linked_functions':[{'address':hex(a),'name':f['name']}for a,f in F.items()if a not in reach],'class_driver_words':[hex(v)for v in struct.unpack('<9I',read(0x8008224,36))],'queue_mutex':hex(struct.unpack('<I',read(0x20000060,4))[0]),'spin_mutex':hex(struct.unpack('<I',read(0x20000074,4))[0]),'numeric_stack_bound':None}
(O/'callback-analysis.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'callback_sites':len(x['indirect_calls_and_tails']),'excluded_sites':sum(bool(q['excluded_reason'])for q in x['indirect_calls_and_tails']),'switch_tables':len(tables),'frame_checks':len(frame_checks),'frame_mismatches':[q for q in frame_checks if not q['agree']],'cycles':cycles,'reachable_functions':len(reach),'all_functions':len(F),'edges':len(E),'numeric_stack_bound':None},indent=2))
