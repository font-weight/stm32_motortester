/* CALLER-ASSERTED BOARD DATA: NOT HARDWARE VERIFICATION OR FLASH APPROVAL. */
#include "mt_board_inputs.h"
static const char board_manufacturer[] = {102, 111, 110, 116, 45, 119, 101, 105, 103, 104, 116, 0};
static const char board_product[] = {77, 111, 116, 111, 114, 116, 101, 115, 116, 101, 114, 32, 112, 114, 105, 118, 97, 116, 101, 32, 76, 86, 32, 116, 101, 115, 116, 0};
static const char board_serial[] = {65, 72, 50, 48, 50, 54, 49, 48, 49, 55, 48, 48, 49, 0};
const mt_board_inputs mt_board = {
    .verified_hse_hz = 8000000u,
    .clock_poll_budget = 1000000u,
    .usb_irq_priority = 0u,
    .firmware_build = 1398034993u,
    .hse_mode = MT_CLOCK_CRYSTAL,
    .require_dtr = 1u,
    .verified_fixed_pullup = 1u,
    .usb = {
        .vid = 4617u,
        .pid = 1u,
        .bcd_device = 256u,
        .bus_power_ma = 100u,
        .manufacturer = board_manufacturer,
        .product = board_product,
        .serial = board_serial,
    }
};
