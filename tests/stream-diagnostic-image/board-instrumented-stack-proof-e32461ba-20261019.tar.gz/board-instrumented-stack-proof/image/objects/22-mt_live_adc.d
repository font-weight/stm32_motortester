/tmp/stream-board-diagnostic-r1/objects/22-mt_live_adc.o: \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/mt_live_adc.c \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/mt_live_adc.h \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/../platform/adc_timer_dma.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/lib/gcc/arm-none-eabi/14.2.1/include/stdbool.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/stdint.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/machine/_default_types.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/features.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/_newlib_version.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_intsup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_stdint.h \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/../platform/mt_timebase.h \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/../protocol/mt_live_device.h \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/../protocol/mt_wire.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/lib/gcc/arm-none-eabi/14.2.1/include/stddef.h \
 /tmp/stream-board-diagnostic-r1/source/firmware/app/../protocol/../acquisition/mt_sample_queue.h
