/tmp/stream-board-diagnostic-r1/objects/0-mt_boot_cpu.o: \
 /tmp/stream-board-diagnostic-r1/source/firmware/boot/mt_boot_cpu.c \
 /tmp/stream-board-diagnostic-r1/source/firmware/boot/mt_boot_cpu.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/stdint.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/machine/_default_types.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/features.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/_newlib_version.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_intsup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_stdint.h
