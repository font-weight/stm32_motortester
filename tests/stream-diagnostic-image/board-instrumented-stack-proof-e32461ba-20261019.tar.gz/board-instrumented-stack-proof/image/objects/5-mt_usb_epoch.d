/tmp/stream-board-diagnostic-r1/objects/5-mt_usb_epoch.o: \
 /tmp/stream-board-diagnostic-r1/source/firmware/transport/mt_usb_epoch.c \
 /tmp/stream-board-diagnostic-r1/source/firmware/transport/mt_usb_epoch.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/stdint.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/machine/_default_types.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/features.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/_newlib_version.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_intsup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_stdint.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/lib/gcc/arm-none-eabi/14.2.1/include/stddef.h
