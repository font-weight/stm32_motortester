#!/usr/bin/env python3
"""Exact-image conditional static upper bound. No target/WCET/flash certificate."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,json,hashlib,struct,collections,copy
O=pathlib.Path(__file__).resolve().parent;B=O/'image'
EXPECTED_ELF='1480750bf9802e90a543369f03922ff060dd61c42fde7bfaf1b8eca19bd60bb2'
EXPECTED_DIS='4c364230b2b1312f97826da8c021d2a3cf78559b9f6efbf3de1ff133fdf5a20b'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'DIAGNOSTIC_UNQUALIFIED_NEVER_FLASH.elf')==EXPECTED_ELF
assert sha(O/'final.dis')==EXPECTED_DIS
assert sha(B/'image.map')=='f5c8bc949fddcb2c196b335e11533ac90062333f0a7dc86aab41ba3b01cddd31'
assert sha(B/'original_builder.py')=='a56ebaecae5ebbae6afafa3083e8055feafa273a1bd2643bd3eda6308fc52d30'
x=json.loads((O/'sp-cfg-analysis.json').read_text());cb=json.loads((O/'callback-analysis.json').read_text());inv=json.loads((O/'inventory.json').read_text());controls=json.loads((O/'rejecting-controls.json').read_text())
assert not x['issues'] and not cb['dag_cycles'] and not inv['frame_mapping_missing'] and not inv['nonstatic_frames']
assert len(x['functions'])==335 and len(x['call_sites'])==1022 and len(cb['callback_sites'])==99 and len(cb['switch_tables'])==6
assert len(controls)==9 and all(c['rejected']for c in controls)
assert all(not inv['pins'][k]['mismatches']for k in ['objects','dependencies','generated'])
# Whole image is pinned, plus explicit salient constructor and vector words.
b=(B/'DIAGNOSTIC_UNQUALIFIED_NEVER_FLASH.elf').read_bytes();off=struct.unpack_from('<I',b,28)[0];ent,num=struct.unpack_from('<HH',b,42);ph=[struct.unpack_from('<8I',b,off+i*ent)for i in range(num)]
def read(a,n):
 for typ,fo,v,pa,sz,mem,flags,align in ph:
  if typ==1 and v<=a and a+n<=v+sz:return b[fo+a-v:fo+a-v+n]
 raise ValueError(hex(a))
assert struct.unpack_from('<I',b,36)[0]==0x5000200
vectors=list(struct.unpack('<59I',read(0x8000000,236)))
assert vectors[0:4]==[0x20005000,0x8007cbd,0x8007d29,0x8007d29]
assert vectors[35:37]==[0x80057b1,0x80057b5]
assert collections.Counter(vectors)==collections.Counter({0x20005000:1,0x8007cbd:1,0x8007d29:50,0:5,0x80057b1:1,0x80057b5:1})
assert list(struct.unpack('<9I',read(0x8007d50,36)))==[0,0x8002ca9,0x8002d01,0x8002d05,0x8002d2d,0x8002e45,0x8002eed,0,0]
assert list(struct.unpack('<12I',read(0x80061b8,48)))==[0x8005c85,0x8005c93,0x8005cbd,0x8005ca1,0x8005d9f,0x8005ca5,0x8005def,0x8005cb3,0x8005dc5,0x8005cab,0x8005e25,0x8005d7f]
assert struct.unpack('<I',read(0x20000060,4))[0]==0x8003079
assert struct.unpack('<I',read(0x20000074,4))[0]==0x8003079
F={f['address']:f for f in x['functions']}
def maxima(sites):
 edges=collections.defaultdict(list)
 for e in sites:
  assert e['owner']in F and e['target']in F
  edges[e['owner']].append(e)
 cache={}
 def walk(a,trail=()):
  assert a not in trail,('recursion',trail+(a,))
  if a in cache:return cache[a]
  best={'bytes':F[a]['max_frame'],'path':[{'function':F[a]['name'],'address':a,'own_depth':F[a]['max_frame']}]}
  for e in edges[a]:
   child=walk(e['target'],trail+(a,));n=e['depth']+child['bytes']
   if n>best['bytes']:best={'bytes':n,'path':[{'function':F[a]['name'],'address':a,'site':e['site'],'own_depth':e['depth'],'kind':e['kind']}]+child['path']}
  cache[a]=best;return best
 for a in F:walk(a)
 return {f['name']:cache[a]for a,f in F.items()if f['name']in ['main','Reset_Handler','USB_HP_CAN1_TX_IRQHandler','USB_LP_CAN1_RX0_IRQHandler','Default_Handler','mt_live_runtime_step']}
m=maxima(x['call_sites']);fg=m['Reset_Handler']['bytes'];irq=max(m['USB_HP_CAN1_TX_IRQHandler']['bytes'],m['USB_LP_CAN1_RX0_IRQHandler']['bytes'])
assert m['Default_Handler']['bytes']==0
exception_allowance=3*(8*4+4);bound=fg+irq+exception_allowance;rounded=(bound+7)//8*8
assert (fg,irq,bound,rounded)==(2792,264,3164,3168)
def reserve_ok(n):return n%8==0 and n>=rounded
assert reserve_ok(8192)and not reserve_ok(3160)and reserve_ok(3168)
# DAG rejecting control, separate from binary pins.
mut=copy.deepcopy(x['call_sites']);mut.append({'owner':'0x80057c0','target':'0x80057c0','site':'0x8005bde','depth':104,'kind':'call'})
try:maxima(mut)
except AssertionError:cycle_rejected=True
else:raise AssertionError('recursion control was not rejected')
result={'status':'CONDITIONAL_EXACT_IMAGE_STATIC_STACK_BOUND','elf_sha256':EXPECTED_ELF,'foreground_bytes':fg,'usb_software_bytes':irq,'exception_levels':3,'exception_bytes_each_conservative':36,'total_upper_bound_bytes':bound,'eight_byte_reservation_minimum':rounded,'existing_reserve_bytes':8192,'arithmetic_headroom_vs_rounded_bound':8192-rounded,'roots':m,'recursion_control_rejected':cycle_rejected,'insufficient_reserve_control_rejected':not reserve_ok(3160),'assumptions':['Exact code/data/initialization/callback registration and root set reviewed here','Real system reset, privileged Thread/MSP, no bootloader handoff, STKALIGN enabled','Only USB HP/LP configurable IRQ roots, same hardware priority, actual outer PRIMASK guard','NMI and HardFault terminate in zero-software-frame Default_Handler','Architecturally successful exception stacking/unstacking and valid SRAM; no stack corruption, erroneous DMA or arbitrary control/data corruption','No external debugger/instrumentation/RTOS/foreign ISR or runtime code/priority changes'],'not_established':['Attained physical high-water mark','Target execution or hardware verification','TX/IRQ/ADC WCET and aggregate traffic/service bounds','Physical memory identity or device/stream acceptance','Engineering sufficiency of arbitrary future margin or flash approval']}
(O/'static-bound.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='roots'},indent=2))
