#!/usr/bin/env python3
"""Replay this frozen static review using Python and the pinned ARM objdump.
No compile, link, target execution, export, flash, network, or repo mutation.
"""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,argparse,json,hashlib,subprocess,re,tarfile,sys
O=pathlib.Path(__file__).resolve().parent;B=O/'image'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--objdump',required=True,type=pathlib.Path);args=p.parse_args();tool=args.objdump.resolve(strict=True)
manifest=json.loads((O/'manifest.json').read_text())
for rel,h in manifest['files'].items():assert sha(O/rel)==h,('package hash changed',rel)
r=json.loads((B/'receipt.json').read_text());inv=json.loads((O/'inventory.json').read_text())
expected_tool=next(h for f,h in r['inputs_before'].items()if f.endswith('/bin/arm-none-eabi-objdump'))
assert sha(tool)==expected_tool,'wrong objdump bytes'
for x in r['objects']:assert sha(B/'objects'/pathlib.Path(x['path']).name)==x['sha256']
# Prove copied source archive contains dependency bytes; patched sources and
# compiler headers remain distinctly accounted for in the original receipt.
with tarfile.open(B/'source.tar')as t:
 members={m.name:m for m in t.getmembers()if m.isfile()}
 count=0
 for f,h in r['dependencies'].items():
  marker='/source/'
  if marker in f:
   name=f.split(marker,1)[1];assert name in members
   assert hashlib.sha256(t.extractfile(members[name]).read()).hexdigest()==h;count+=1
# Recompute the disassembly, allowing only the location-specific file header.
def canonical(s):return re.sub(r'^.*:     file format elf32-littlearm$', 'EXACT_ELF:     file format elf32-littlearm',s,flags=re.M)
cmd=[str(tool),'-drwC',str(B/'DIAGNOSTIC_UNQUALIFIED_NEVER_FLASH.elf')]
z=subprocess.run(cmd,text=True,capture_output=True,check=True)
assert canonical(z.stdout)==canonical((O/'final.dis').read_text()),'disassembly differs'
# Independently rematch all .su sizes to code sections, including clones and
# the three retained weak stub bodies that no longer have final symbol names.
frames={}
for f in (B/'objects').glob('*.su'):
 rows={}
 for l in f.read_text().splitlines():
  head,n,kind=l.split('\t');rows[head.rsplit(':',1)[1]]=(int(n),kind)
 for a,x in inv['code_ranges'].items():
  if pathlib.Path(x['object']).name!=f.with_suffix('.o').name:continue
  name=x['section'][6:];keys=[name,name.removeprefix('startup.'),re.sub(r'\.(isra|constprop)\.\d+',r'.\1',name)]
  found=next((rows[k]for k in keys if k in rows),None);assert found,(a,name)
  assert found==(inv['frames'][a]['bytes'],'static');frames[a]=found
assert len(frames)==333
logs=[]
for script in ['trace_callbacks.py','check_sp.py','rejecting_controls.py','derive_bound.py','test_interpreter_policy.py']:
 rr=subprocess.run([sys.executable,'-I','-B',str(O/script)],capture_output=True,text=True)
 logs.append({'script':script,'exit':rr.returncode});(O/(script+'.replay.stdout')).write_text(rr.stdout);(O/(script+'.replay.stderr')).write_text(rr.stderr)
 assert rr.returncode==0,(script,rr.stderr)
# Every newly generated result must be byte-identical to the reviewed outputs.
for rel in ['callback-analysis.json','sp-cfg-analysis.json','rejecting-controls.json','static-bound.json','interpreter-policy-controls.json']:
 assert sha(O/rel)==manifest['files'][rel],('replay drift',rel)
result={'status':'FROZEN_CONDITIONAL_STATIC_PROOF_REPLAY_PASS','elf_sha256':sha(B/'DIAGNOSTIC_UNQUALIFIED_NEVER_FLASH.elf'),'tool_sha256':sha(tool),'source_dependencies_checked_in_archive':count,'objects_verified':len(r['objects']),'su_frames_verified':len(frames),'commands':logs,'scope':'Exact static stack/ABI/callback evidence only; no aggregate/hardware/WCET/flash acceptance'}
(O/'replay-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
