/* SYNTHETIC TEST FIXTURE: NEVER FLASH. */
#include "mt_board_inputs.h"
static const char board_manufacturer[] = {84, 69, 83, 84, 32, 79, 78, 76, 89, 32, 34, 32, 92, 0};
static const char board_product[] = {83, 89, 78, 84, 72, 69, 84, 73, 67, 32, 68, 79, 32, 78, 79, 84, 32, 70, 76, 65, 83, 72, 0};
static const char board_serial[] = {84, 69, 83, 84, 79, 78, 76, 89, 48, 0};
const mt_board_inputs mt_board = {
    .verified_hse_hz = 4500000u,
    .clock_poll_budget = 1u,
    .usb_irq_priority = 0u,
    .firmware_build = 0u,
    .hse_mode = MT_CLOCK_CRYSTAL,
    .require_dtr = 0u,
    .verified_fixed_pullup = 1u,
    .usb = {
        .vid = 1u,
        .pid = 0u,
        .bcd_device = 0u,
        .bus_power_ma = 2u,
        .manufacturer = board_manufacturer,
        .product = board_product,
        .serial = board_serial,
    }
};
