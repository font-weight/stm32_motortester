/* PROVISIONAL DIAGNOSTIC INPUT: NOT TIMING PROOF OR FLASH APPROVAL. */
#include "mt_stream_timing.h"
const mt_stream_timing_inputs mt_stream_timing = {
    .schema_version = 1u,
    .diagnostic_provisional = 1u,
    .declared_transaction_bound_ms = 1u
};
