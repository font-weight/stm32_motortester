/tmp/stream-draft-image-r1/objects/16-mt_boot_time.o: \
 /tmp/stream-draft-image-r1/source/firmware/boot/mt_boot_time.c \
 /tmp/stream-draft-image-r1/source/firmware/boot/mt_boot_time.h \
 /tmp/stream-draft-image-r1/source/firmware/platform/mt_clock_startup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/stdint.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/machine/_default_types.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/features.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/_newlib_version.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_intsup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_stdint.h \
 /tmp/stream-draft-image-r1/source/firmware/platform/mt_timebase.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/lib/gcc/arm-none-eabi/14.2.1/include/stddef.h
