/tmp/stream-draft-image-r1/objects/board.o: \
 /tmp/stream-draft-image-r1/board.c \
 /tmp/stream-draft-image-r1/source/firmware/boot/mt_board_inputs.h \
 /tmp/stream-draft-image-r1/source/firmware/platform/mt_clock_startup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/stdint.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/machine/_default_types.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/features.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/_newlib_version.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_intsup.h \
 /workspace/scratch/8004c8bb11f3/arm-tools-20261019/root/usr/include/newlib/sys/_stdint.h \
 /tmp/stream-draft-image-r1/source/firmware/transport/mt_usb_descriptors.h
