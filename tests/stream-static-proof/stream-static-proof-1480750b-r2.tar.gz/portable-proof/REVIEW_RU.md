# Независимое ревью точного STREAM ELF: callback, ABI и стек

## Итог и узкая область приёмки

**PASS, 9.615/10 только для условной статической границы стека и проверенной callback/ABI-композиции указанного ELF.** Общая приёмка STREAM, физического прибора и временных гарантий остаётся **BLOCKED_EVIDENCE**. Этот отчёт не меняет поля квалификации исходной сборочной квитанции, не разрешает прошивку и не является выпуском firmware.

Установлена консервативная верхняя граница **3164 байта**, или **3168 байт при округлении резерва до 8 байт**. Это не измеренный и не обязательно достижимый максимум. Текущий резерв 8192 байта превышает округлённую границу на 5024 байта в рамках перечисленных ниже условий. Выбор достаточного инженерного запаса для других профилей этим не утверждается.

Репозиторий: font-weight/stm32_motortester. Исходная точка машинного ревью: 3caaa9106a3b6356e471c5e03ae0594e20472f7a. ELF SHA256:

1480750bf9802e90a543369f03922ff060dd61c42fde7bfaf1b8eca19bd60bb2

Затем лично проверена идентичность всех 29 упорядоченных object SHA и ELF итоговой сборки 01824efd2571d5b2af8ab8fb4360cda8eb6c372d. Квитанция итоговой сборки SHA256 84064263ff309fe542d7f23aab9598041210b5f05cd05dead6477adface68c46. Её 422 исходных pin, 98 dependency pin и 246 generated pin совпали с фактическими файлами. Полная запись — final-cross-binding.json; исходная итоговая квитанция сохранена как image/final-receipt.json.

Критик не участвовал в реализации проверяемой прошивки. Работа была read-only относительно репозитория и сборок: только анализ, независимый ABI-probe, собственные проверяющие программы и копии доказательств в отдельном каталоге. Production-правок, публикации, BIN/HEX, запуска на MCU и прошивки не выполнялось. Перед решениями прочитаны AGENTS.md и docs/quality-gate.md, учитывались текущие требования и исторический отчёт подготовки STREAM. Старые границы 3064/3120 байт не использовались.

## Условия, без которых число неприменимо

1. Именно закреплённые ELF, code/data bytes, callbacks, исходная конфигурация и набор корней; никакого внешнего владельца АЦП, USB или TIME.
2. Настоящий системный reset, privileged Thread mode и MSP; вход через bootloader не рассматривается. Reset устанавливает VTOR и STKALIGN, main проверяет PRIMASK=1, BASEPRI=FAULTMASK=IPSR=0 и CONTROL[1:0]=0.
3. Из конфигурируемых IRQ допускаются только USB HP19 и LP20 с одинаковым аппаратным приоритетом. Полный DCD dispatch находится внутри настоящего PRIMASK save/restore. Нет RTOS, SysTick, DMA/timer ISR, debug-monitor, стороннего instrumentation или изменения приоритетов/векторов извне.
4. NMI и HardFault завершаются в Default_Handler, который не выделяет программный стек. Исключения рассматриваются с успешным архитектурным stacking/unstacking и исправной доступной SRAM. Произвольная порча памяти, DMA за пределами буфера, повреждённый MSP, ошибочная загрузка кода и сбой самой процедуры stacking не покрываются.
5. Сохраняются проверенные контракты владения и отсутствия повторного входа в live callback. Не предполагается отсутствие обычных USB IRQ или терминальных NMI/HardFault.

Это обычные явно ограниченные предпосылки статического анализа, а не свидетельства физической исправности платы.

## Воспроизведение

Пакет переносим: требуется Python 3 и тот же ARM objdump, SHA256 bcf47eb777c4ac452c765af3e61b4e7b19ad62060a226b74eb189fd9547910e0. Путь к инструменту задаётся явно. Каталог пакета может содержать пробелы.

python3 -I -B verify_package.py --objdump /полный/путь/arm-none-eabi-objdump

Проверка сверяет manifest, заново дизассемблирует сохранённый ELF, сверяет 29 объектов, повторно сопоставляет все .su с секциями кода, проверяет байты 72 source dependencies внутри сохранённого source.tar, затем выполняет trace_callbacks.py, check_sp.py, rejecting_controls.py, derive_bound.py и test_interpreter_policy.py. Результаты обязаны совпасть с замороженными byte hashes. Допустимо нормализуется только строка имени входного ELF в заголовке objdump. Никакой загрузки из сети, сборки production, link/export, target execution или записи в исходный репозиторий этот replay не делает.

Исходные команды полного readelf/nm/objdump, независимого ARM ABI probe и повторного generic boot ELF/input audit сохранены рядом с отчётом и в audit-commands.json. Generic boot-аудиты повторно прошли, но сами по себе не являются stack proof.

manifest.json закрепляет все входные файлы и программы пакета. Это проверяющий рецепт для одного точного образа, а не универсальный автоматический допуск изменённого firmware. Новые bytes или иные callbacks требуют нового ревью, а не замены ожидаемого SHA без анализа.

## Замыкание владельцев и callback

В image.map фактически 29 object inputs: 26 C units, reset, board и timing. Единственный application entry — mt_stream_main; он инициализирует mt_live_runtime один раз и далее вызывает только mt_live_runtime_step. Legacy mt_runtime, mt_device_main, mt_usb_cdc, оконные control/TX owners отсутствуют в объектном наборе и итоговом code graph.

Не найдено неразрешённых символов, libgcc/libc archive inputs, malloc/free, скрытого CRT или helper-library fallback. memcpy/memmove/memset/memcmp разрешены в собственный mt_memory.o. Сохранённые неиспользуемые weak DCD stubs отделены от сильных реализаций и не объявлены библиотечным fallback: после strong resolution их три анонимных нулевых тела остаются в no-GC image, но из корней не вызываются.

В машинном коде **99 register-indirect transfer sites: 84 BLX и 15 tail BX**. Полный список адресов и целей находится в callback-analysis.json.

- ADC read/write/now → adc_read/adc_write/adc_time → единственный runtime MMIO triple и тот же TIME. MMIO functions — mt_clock_mmio_read32/write32, context=NULL.
- Clock-startup копирует main clock IO; boot-time копирует тот же IO в TIME. Boot/USB wrappers используют те же MMIO leaf functions.
- ADC guard → commit_enter/allowed/leave/timed → настоящий USB bridge и mt_irq_guard_enter/leave. Guard и контексты скопированы в persistent runtime, указателя на временный initializer не остаётся.
- live IO → live_time/live_start/live_stop/live_write/live_isolate, context=&runtime. Конструкторные literal pointers и реальные ARM offsets проверены. Live callbacks не возвращаются рекурсивно в receive/step/offer.
- USB queue/spin callbacks → usbd_int_set. Единственная 36-byte class table → cdcd_init/deinit/reset/open/control_xfer_cb/xfer_cb. Control completion может указывать только на cdcd_control_xfer_cb либо weak tud_vendor_control_xfer_cb; CFG_TUD_TEST_MODE=0.
- Три машинные точки исключены по конкретным регистрациям: CDC .sof=0, .xfer_isr=0 и USBD_EVENT_FUNC_CALL. Сильного app-driver getter нет; фактический weak getter записывает count=0 и возвращает NULL. Единственный deferred producer usbd_defer_func не вызывается и не имеет входящего function-address relocation; доступные DCD producers строят другие event kinds. Исключения не основаны только на ненулевом указателе или тестовом happy path.
- tud_cdc_tx_complete_cb и остальные CDC пользовательские hooks остаются нулевыми weak stubs. Единственный application writer — live_write; отложенного второго TX writer не обнаружено.

Все **6 switch/computed-jump tables** имеют проверенные bounds и фактические targets внутри соответствующей функции. Они не приняты за callback и не отброшены как неизвестные переходы. Конфигурация дополнительно проверена через действительный preprocess output: OS_NONE, DEVICE/full-speed, host=0, CDC=1, bridge=1, CTR fairness=1, nonpersistent/non-overwritable CDC, queue16, task event opportunity1, остальные классы выключены.

## ABI и время жизни

Final attributes: ARMv7-M Thumb-2, EABI5 soft-float, 32-bit enum, 8-byte ABI alignment requirement. Независимый ARM probe, собранный теми же флагами и headers, подтверждает:

- runtime7760, ADC904, device6104, acquisition584, live_clock32, live_io32, USB epoch48, live snapshot568 байт
- runtime offsets: adc0, device904, acquisition7008, clock64=7592, clock7624, mmio7628, carry7688
- live_io: context0, clock4, start8, quiesce12, write16, isolate20, bound24, build28
- ADC ring offset0/512 bytes, snapshot offset512/256 bytes; ADC IO offset768; acquisition guard offset12 и persistent stop_scratch offset32

runtime занимает [0x20000488,0x200022d8); DMA ring [0x20000488,0x20000688), snapshot [0x20000688,0x20000788). Всё находится внутри nominal20KiB SRAM и не пересекает зарезервированный стек [0x20003000,0x20005000). Static end=0x2000236c, static allocation9068B. Эти факты геометрии не подтверждают маркировку фактического чипа.

48-byte sret mt_usb_bridge_snapshot проверен по инструкциям: stable использует SP+0..47, сохраняемые регистры начинаются с SP+52; synchronize_loss — SP+0..47, регистры с SP+48; runtime_step — SP+0..47, регистры с SP+48. Key хранится в сохранённом регистре, sret его не перекрывает. В mt_usb_bridge_snapshot три 16-byte копии, без записи за48 bytes. Для uint64 подтверждены возвращаемая пара r0/r1 и выравнивание аргументов, например n/first_index в r2/r3 с остальными аргументами в выделенной области стека. Неразрешённых 64-bit ABI helpers нет.

## Машинный стек и вывод числа

335 code bodies =333 C input sections +Reset_Handler +Default_Handler. Анализ использует linker code ranges, а не только labels objdump, поэтому не принимает .rodata в общей output .text за исполняемый код и не пропускает три anonymous weak bodies.

Для каждого тела сделан CFG walk по всем прямым ветвям, обоим исходам условий и всем decoded switch targets. Проверены постоянные SP изменения, единая глубина во всех joins, 8-byte alignment каждого вызова, восстановление SP на return и tail branch. Учтён ldr lr,[sp],#4 в эпилоге dcd_set_address. Все335 тела прошли;333 C frame maxima совпали с .su. Dynamic allocation stack, положительных по глубине циклов и рекурсии замкнутого call/tail graph нет. Всего1022 transfer edges после подстановки targets.

Верхняя граница foreground, уже включая постоянный main frame, —2792B. Максимизирующая цепочка в консервативном графе:

main104 → runtime_step72 → receive48 → accept_frame1168 → terminate648 → live-device now16 → recover16 → raw_barrier584 → live_stop0 → live_adc_quiesce32 → stop_snapshot24 → adc_stop8 → driver quiesce24 → wait_clear24 → driver now0 → adc_time0 → timebase_now_us8 → timebase_update16.

Каждый вклад взят в конкретной call site; хвостовые переходы имеют уже восстановленную глубину0. Последовательные вызовы не суммируются. В графе намеренно разрешены некоторые несовместимые по данным ветви, что делает результат верхней оценкой, а не заявлением достижимости.

USB HP и LP имеют одинаковую software bound264B: IRQ tail0 → dispatcher8 → DCD72 → event_handler48 → queue_event48 → FIFO write64 → hwfifo read16 → memcpy8. Наличие в этой консервативной цепочке неиспользуемого данным queue access mode пути не уменьшает верхнюю оценку.

Фактические59 vector words: MSP0x20005000, Reset0x08007cbd, HP0x080057b1, LP0x080057b5,50 ссылок на Default_Handler0x08007d29 и5 нулей. Default_Handler — cpsid i и вечный branch, без software frame. Равноприоритетные USB IRQ друг друга не вкладывают; PRIMASK дополнительно защищает dispatcher. Максимально учитывается USB → HardFault → NMI, т.е. три аппаратных входа. На каждый консервативно выделено32B базового кадра +4B возможного выравнивания. Tail-chaining не создаёт бесконечного накопления кадров; терминальный обработчик не возвращается.

Архитектурное основание: [ST PM0056 Rev7, §§2.3.5–2.3.7 и2.4.2–2.4.4](https://www.st.com/resource/en/programming_manual/pm0056-stm32f10xxx20xxx21xxxl1xxxx-cortexm3-programming-manual-stmicroelectronics.pdf), pp.35–41. Документ подтверждает состав кадра, выравнивание, правила приоритета/вложения, tail-chaining и lockup. Ошибка stacking не подменяется успешным кадром.

Следовательно2792+264+3×36=3164B; округление до8B даёт3168B. Это новая оценка точного STREAM image, независимо от старых3064/3120B.

## Отрицательные проверки и границы инструмента

После первого замораживания пакета интегратор обнаружил существенный дефект fail-closed режима verifier: Python -O/-OO отключал assert. Отдельный критик подтвердил старый контрпример: verify_package.py под -I -B -O с --objdump /usr/bin/true ошибочно завершался с PASS. Первый архив с SHA256 00fd0841b4d35cedae79255fafdd1ef90b9c6b77f7e8b0a90a78043b48ca78ee отозван как окончательное свидетельство verifier; его численный граф сам по себе не изменился.

Дефект исправлен только в инструментах ревью: каждый из шести исполняемых proof scripts до любых файловых операций явно проверяет sys.flags.optimize == 0, isolated и dont_write_bytecode, без assert. Нарушение завершает процесс кодом 2 и единственной диагностикой REJECTED_INTERPRETER_POLICY. Добавлены 32 настоящих запуска -O, -OO, без -I и без -B, включая точное воспроизведение контрпримера с /usr/bin/true. Все отвергаются; stdout пуст, hashes, размеры, mtime и набор файлов/каталогов пакета не изменяются. Те же guards добавлены в пять исходных локальных audit scripts; отдельно прошли ещё 25 отрицательных запусков. P1 неверного PASS в оптимизированном интерпретаторе устранён; исправленные tools и настоящий replay требуют повторной независимой проверки. Graph/math, машинные инструкции, callbacks и ELF не менялись.


На копиях analysis inputs отвергнуты9 адресных мутаций: неверный SP frame/alignment, потеря post-index восстановления LR, динамическая запись SP, избыточное восстановление на return, вызов literal data, незарегистрированный indirect site, ложная .su, switch вне owner, callback target вне function entry. Отдельно калькулятор отверг рекурсивную call edge и резерв3160B. Эти проверки не называются аппаратными тестами или исполняемыми мутантами firmware. Полный ELF, map, constructor words и vectors закреплены независимо от них.

Сам replay требует неизменный manifest и точный objdump SHA. Он не обеспечивает формальную верификацию всего C memory safety и не предназначен для автоматического принятия нового изменённого ELF. Нативные функциональные регрессии относятся к отдельному ревью реализации; здесь не выдаются повторёнными.

## Рубрика и открытые ворота

C1=9.7: точный образ, владельцы, ABI и условный bound подтверждены; вывод ограничен reset/stacking моделью.
C2=9.6: учтены cleanup/error/Stop/HELLO, IRQ и terminal faults; произвольная memory corruption отдельно исключена.
C3=9.6: полный machine CFG/SP walk, callback registrations, независимый ABI probe, точный replay, rejecting controls и fail-closed interpreter-policy controls; это не формальный proof assistant и не target execution.
C4=9.5: конкретный замороженный граф и объяснимый portable verifier; ручные source-backed target предпосылки перечислены явно.
C5=9.6: переносимый pinned пакет, commands, exact-object/ELF identity и source archive; compiler host/toolchain не заявлены полностью герметичными.

0.30×9.7+0.20×9.6+0.25×9.6+0.15×9.5+0.10×9.6=**9.615**. Незакрытого P0/P1 в этой узкой статической области не найдено. **PASS только для указанного условного static stack/callback/ABI результата.** Любой новый code/config/vector/callback/root change требует нового анализа.

Открыты: квалификация provisional1ms TX bound, target IRQ/WCET и aggregate traffic/fault scheduling, ADC strict service/start timing и реальный USB/ADC поток, физическая SRAM/MCU/clock identity и общая независимая приёмка профиля. Ни резерв8192, ни число3164 не закрывают эти ворота. Нельзя автоматически менять receipt hardware_verified, runtime_profile_accepted или flash_approved на true.
