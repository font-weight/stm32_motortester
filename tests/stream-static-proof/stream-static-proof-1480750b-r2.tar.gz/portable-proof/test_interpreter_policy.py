#!/usr/bin/env python3
"""Real fail-closed Python-mode controls; never invoke an unguarded payload."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import pathlib,hashlib,subprocess,json
O=pathlib.Path(__file__).resolve().parent
SCRIPTS=['verify_package.py','trace_callbacks.py','check_sp.py','rejecting_controls.py','derive_bound.py','test_interpreter_policy.py']
MODES=[['-I','-B','-O'],['-I','-B','-OO'],['-B'],['-I'],[]]
EXPECTED='REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n'
def snapshot():
    state={}
    for p in [O]+sorted(O.rglob('*')):
        st=p.stat()
        state[str(p.relative_to(O))]={'mode':st.st_mode,'size':st.st_size,'mtime_ns':st.st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None}
    return state
rows=[]
CASES=[(script,mode,[]) for script in SCRIPTS for mode in MODES]
CASES += [('verify_package.py',['-I','-B',flag],['--objdump','/usr/bin/true']) for flag in ['-O','-OO']]
for script,mode,extra in CASES:
    before=snapshot()
    argv=[sys.executable]+mode+[str(O/script)]+extra
    proc=subprocess.run(argv,text=True,capture_output=True)
    after=snapshot()
    if proc.returncode != 2 or proc.stdout != '' or proc.stderr != EXPECTED or before != after:
        raise RuntimeError(('interpreter guard failed',script,mode,proc.returncode,proc.stdout,proc.stderr,before==after))
    rows.append({'script':script,'python_flags':mode,'script_arguments':extra,'exit':proc.returncode,'stdout_empty':True,'guard_rejected':True,'package_files_unchanged':True})
result={'status':'REAL_INTERPRETER_POLICY_CONTROLS_PASS','cases':rows,'test_count':len(rows),'scope':'Real -O/-OO/missing -I/missing -B invocations reject before analysis file I/O; no claim of general sandboxing'}
(O/'interpreter-policy-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'test_count':len(rows)},indent=2))
