#!/usr/bin/env python3
"""Explicit source/registration-backed graph inventory. Not an accepted proof."""
import sys
# This must remain before filesystem reads/writes and must not use assert.
if sys.flags.optimize != 0 or not sys.flags.isolated or not sys.flags.dont_write_bytecode:
    sys.stderr.write("REJECTED_INTERPRETER_POLICY: require python3 -I -B with assertions enabled; -O/-OO are forbidden\n")
    raise SystemExit(2)
import json,pathlib,re,struct,collections
O=pathlib.Path(__file__).resolve().parent; x=json.loads((O/'inventory.json').read_text()); dis=(O/'final.dis').read_text()
# Partition by linker input code ranges, not objdump labels: discarded weak
# symbol names leave three retained anonymous function bodies; rodata lives in
# output .text too and must never be mistaken for executable functions.
F={int(a,16):{'name':v['section'][6:].removeprefix('startup.'),'size':v['size'],'ins':[]} for a,v in x['code_ranges'].items()}
byname={}
for l in (O/'final.nm').read_text().splitlines():
 m=re.match(r'([0-9a-f]+)\s+([0-9a-f]+)\s+[tTwW]\s+(\S+)',l)
 if m:byname.setdefault(m[3],[]).append(int(m[1],16))
for l in dis.splitlines():
 m=re.match(r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{4,8}\s+)+\s*([^\s]+)\s*(.*)$',l)
 if m and not m[2].startswith('.'):
  a=int(m[1],16)
  owners=[st for st,f in F.items() if st<=a<st+f['size']]
  if owners:F[owners[0]]['ins'].append((a,m[2],m[3]))
def target(n):
 assert len(byname[n])==1,(n,byname[n]);return hex(byname[n][0])
fixed={0x8000142:'adc_read',0x800014c:'adc_write',0x8000152:'adc_time',0x800096c:'commit_enter',0x800097e:'commit_allowed',0x800098a:'commit_leave',0x80009e4:'commit_timed',0x8000a1c:'commit_timed',0x8000a36:'commit_allowed',0x8000fd8:'mt_clock_mmio_write32',0x8001ac2:'mt_irq_guard_enter',0x8001ad2:'mt_irq_guard_leave',0x8003056:'cdcd_reset',0x8003094:'cdcd_control_xfer_cb',0x8003294:'cdcd_init',0x800336a:'cdcd_deinit',0x8003bf2:'cdcd_open',0x8003f04:'cdcd_xfer_cb',0x8004c0e:'mt_clock_mmio_read32',0x8004c30:'mt_clock_mmio_write32',0x80050fc:'mt_clock_mmio_read32',0x80052e8:'mt_clock_mmio_read32',0x80052ee:'mt_clock_mmio_write32',0x8005c90:'mt_clock_mmio_read32',0x8005c9e:'mt_clock_mmio_write32',0x80068ca:'live_stop',0x800698c:'live_time',0x8006a84:'live_stop',0x8006e8a:'live_isolate',0x8007048:'live_stop',0x800707e:'live_start',0x8007688:'live_write'}
null={0x80034ca:'CDC .sof field is zero in the only 36-byte driver; application-driver count is zero',0x8003534:'CDC .xfer_isr field is zero in the only driver; application-driver count is zero',0x8003f3e:'USBD_EVENT_FUNC_CALL: sole producer usbd_defer_func is not called or address-referenced by this image; reachable DCD producers construct other event kinds'}
for q in x['indirect_calls_and_tails']:
 a=int(q['site'],16);n=q['function'];names=[];reason=''
 if a in fixed:names=[fixed[a]]
 elif a in null:reason=null[a]
 elif n in ['mt_timebase_update','mt_timebase_init','mt_timebase_stop']:names=['mt_clock_mmio_read32']
 elif n=='mt_boot_time_start':names=['mt_clock_mmio_write32']
 elif n in ['queue_event_epoch.isra.0','usbd_spin_lock','usbd_spin_unlock'] or a in [0x80038f6,0x800390c]:names=['usbd_int_set']
 elif a in [0x8003e58,0x8003ed0]:names=['cdcd_control_xfer_cb','tud_vendor_control_xfer_cb']
 else:raise RuntimeError(q)
 q['targets']=[{'address':target(n),'name':n}for n in names];q['excluded_reason']=reason
# All direct external conditional/unconditional branches must also be edges.
E=[]
for a,f in F.items():
 for site,op,arg in f['ins']:
  if not re.fullmatch(r'(?:bl|b(?:eq|ne|cs|cc|hs|lo|mi|pl|vs|vc|hi|ls|ge|lt|gt|le)?)(?:\.[nw])?',op):continue
  m=re.match(r'([0-9a-f]+) <',arg)
  if m:
   t=int(m[1],16)
   if t!=a and t in F:E.append((a,t,site,'call'if op=='bl'else'tail'))
for q in x['indirect_calls_and_tails']:
 for t in q['targets']:E.append((int(q['owner'],16),int(t['address'],16),int(q['site'],16),'indirect_'+q['op']))
# Check static data bytes directly from PT_LOAD.
b=(O/'image/DIAGNOSTIC_UNQUALIFIED_NEVER_FLASH.elf').read_bytes();off=struct.unpack_from('<I',b,28)[0];ent,num=struct.unpack_from('<HH',b,42);ph=[struct.unpack_from('<8I',b,off+i*ent)for i in range(num)]
def read(a,n):
 for typ,fo,v,pa,sz,mem,flags,align in ph:
  if typ==1 and v<=a and a+n<=v+sz:return b[fo+a-v:fo+a-v+n]
 raise ValueError(hex(a))
tables=[]
for site,base,count,size,owner in [(0x8001aea,0x8001aee,7,1,0x8001adc),(0x8002ecc,0x8002ed0,4,4,0x8002e44),(0x80033f8,0x80033fc,6,1,0x80033d4),(0x8003986,0x800398a,8,2,0x80038c0),(0x8003a7e,0x8003a84,10,4,0x80038c0),(0x8003c4a,0x8003c50,15,4,0x80038c0)]:
 vals=struct.unpack('<'+{1:'B',2:'H',4:'I'}[size]*count,read(base,count*size));targets=[v&~1 if size==4 else site+4+v*2 for v in vals];valid=set(i[0]for i in F[owner]['ins']);assert all(t in valid for t in targets),(hex(site),targets)
 tables.append({'site':hex(site),'base':hex(base),'count':count,'width':size,'targets':[hex(t)for t in targets],'all_targets_inside_owner':True})
# Exact object/linked symbol frame matching, and constant stack-decrement census.
frame_checks=[]
for a,f in F.items():
 if hex(a) not in x['frames']:continue
 negatives=[]
 for site,op,args in f['ins']:
  if op=='push' or op=='stmdb' and args.startswith('sp!'):
   regs=re.search(r'\{([^}]+)\}',args)[1].split(',');negatives.append((site,4*len(regs)))
  elif op in ['sub','sub.w','subw'] and args.startswith('sp,'):
   m=re.search(r'#(\d+)',args);assert m,(hex(site),args);negatives.append((site,int(m[1])))
  elif op in ['str','str.w'] and re.match(r'\w+, \[sp, #-\d+\]!',args):negatives.append((site,int(re.search(r'#-(\d+)',args)[1])))
 total=sum(n for site,n in negatives);expected=x['frames'][hex(a)]['bytes']
 frame_checks.append({'function':f['name'],'address':hex(a),'su':expected,'sum_static_decrements':total,'agree':expected==total,'decrement_sites':[hex(s)for s,n in negatives]})
# Structural DAG check. The maximum remains intentionally unreported: this is not
# an exhaustive SP-state/return/call-alignment and path-feasibility proof.
adj=collections.defaultdict(set)
for a,t,s,k in E:adj[a].add(t)
cycles=[];active=[];done=set()
def visit(a):
 if a in active:cycles.append([hex(t)for t in active[active.index(a):]+[a]]);return
 if a in done:return
 active.append(a)
 for t in adj[a]:visit(t)
 active.pop();done.add(a)
for a in F:visit(a)
roots=[byname[n][0]for n in ['Reset_Handler','USB_HP_CAN1_TX_IRQHandler','USB_LP_CAN1_RX0_IRQHandler','Default_Handler']];reach=set()
def reachwalk(a):
 if a in reach:return
 reach.add(a)
 for t in adj[a]:reachwalk(t)
for a in roots:reachwalk(a)
output={'status':'SUPPLEMENTAL_STATIC_INVENTORY_NOT_STACK_QUALIFICATION','callback_sites':x['indirect_calls_and_tails'],'switch_tables':tables,'frame_checks':frame_checks,'dag_cycles':cycles,'reachable_functions':len(reach),'all_functions':len(F),'edges':len(E),'root_names':[F[a]['name']for a in roots],'unreachable_linked_functions':[{'address':hex(a),'name':f['name']}for a,f in F.items()if a not in reach],'class_driver_words':[hex(v)for v in struct.unpack('<9I',read(0x8007d50,36))],'queue_mutex':hex(struct.unpack('<I',read(0x20000060,4))[0]),'spin_mutex':hex(struct.unpack('<I',read(0x20000074,4))[0]),'numeric_stack_bound':None}
(O/'callback-analysis.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'callback_sites':len(x['indirect_calls_and_tails']),'excluded_sites':sum(bool(q['excluded_reason'])for q in x['indirect_calls_and_tails']),'switch_tables':len(tables),'frame_checks':len(frame_checks),'frame_mismatches':[q for q in frame_checks if not q['agree']],'cycles':cycles,'reachable_functions':len(reach),'all_functions':len(F),'edges':len(E),'numeric_stack_bound':None},indent=2))
